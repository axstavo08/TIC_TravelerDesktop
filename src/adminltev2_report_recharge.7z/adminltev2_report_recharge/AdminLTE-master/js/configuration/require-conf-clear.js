/**
 * Project Name : smartflex-client
 * Created: 17/11/2017
 * @author John Portella <C16915>
 * @version 1.0
 */

requirejs.config({
    //baseUrl: '/smartflex',
    locale: 'es',
    paths: {
        //Conf
        'i18n': 'js/library/i18n/i18n',
        //Profile
        //'user-settings': 'js/profile/user/settings',
        //Global
        'global-images': 'js/resource/images',
        'global-colors': 'js/resource/colors',
        'global-config': 'js/global/config',
        'global-template': 'js/global/template',
        'global-messages': 'js/global/messages',
        'global-string': 'js/general/strings',
        'global-object': 'js/general/object',
        //Sidebar resource
        'sidebar-configuration': 'js/resource/sidebarConfiguration',
        //Chart Resource
        'chart-labels': 'js/resource/chartLabels',
        'chart-dimensions': 'js/resource/chartDimensions',
		//Select2 Resource
		'select2-configuration': 'js/resource/select2Configuration',
        //Util
        'objUtil': 'js/util/object',
        'sidebarMenu': 'js/util/sidebarMenu',
        'dataview': 'js/util/dataview',
        'pageLoad': 'js/util/pageLoad-2.0',
        'daterangepickerResponsive': 'js/util/daterangepickerResp',
        'chart': 'js/util/chart',
        'datatable': 'js/util/datatable',
		'datepickerMonth': 'js/util/datepickerMonth',
		'stringsUtil': 'js/util/strings',
		'progressBar': 'js/util/progressBar',
        //Modules
        'recharge': 'js/module/mobile/report/recharge',
		'layers': 'js/module/global/layers',
        //Template
        'template': 'js/global/template-new',
        'conflicts': 'template/js/conflicts',
        'adminlte': 'template/js/adminlte',
        'bootstrap': 'js/library/bootstrap/dist/js/bootstrap.min',
        'jquery': 'js/library/jquery/dist/jquery.min',
        'jquery-ui': 'js/library/jquery-ui/jquery-ui.min',
        'slimscroll': "js/library/jquery-slimscroll/jquery.slimscroll.min",
        'fastclick': "js/library/fastclick/lib/fastclick",
        'select2': 'js/library/select2/dist/js/select2.full.min',
        'select2-library': 'js/library/select2/src/js/select2',
        'select2-es': 'js/library/select2/dist/js/i18n/es',
        'select2-cascade': 'js/util/select2-cascade',
        'moment': 'js/library/moment/min/moment.min',
        'icheck': 'js/library/iCheck/icheck.min',
        'daterangepicker': 'js/library/bootstrap-daterangepicker/daterangepicker',
        //librerias
        'highcharts-common': 'js/library/highcharts/highcharts',
        'highcharts-no-data-to-display': 'js/library/highcharts/modules/no-data-to-display',
        'highcharts-theme-smartflex': 'js/library/highcharts/themes/smartflex-theme',
        'highcharts-more': 'js/library/highcharts/highcharts-more',
        'highcharts-solid-gauge': 'js/library/highcharts/modules/solid-gauge',
        'highcharts-exporting': 'js/library/highcharts/modules/exporting',
        'highcharts-offline-exporting': 'js/library/highcharts/modules/offline-exporting',
        'highcharts-export-csv': 'js/library/highcharts/modules/export-csv',
        //'highcharts-adapt-chart-to-legend': 'js/library/adapt-chart-to-legend-master/adapt-chart-to-legend',
        'datatables.net': 'js/library/datatables-1.10.16/js/jquery.dataTables.min',
        'datatables.net-buttons': 'js/library/datatables-1.10.16/extensions/Buttons-1.4.2/js/dataTables.buttons.min',
        'datatables-buttons-html5': 'js/library/datatables-1.10.16/extensions/Buttons-1.4.2/js/buttons.html5.min',
        'datatables-common': 'js/library/datatables-1.10.16/util/datatables',
        'datatables-plugins-dataRender-ellipsis': 'js/library/datatables-1.10.16/plugins/dataRender/ellipsis',
        'jszip': 'js/library/datatables-1.10.16/extensions/JSZip-2.5.0/jszip.min',
        'jszip-def': 'js/library/datatables-1.10.16/extensions/JSZip-2.5.0/util/jszip-def',
        'pdfmake': 'js/library/datatables-1.10.16/extensions/pdfmake-0.1.32/pdfmake.min',
        'vfs_fonts': 'js/library/datatables-1.10.16/extensions/pdfmake-0.1.32/vfs_fonts',
        'jquery-circle-progress': 'js/library/jquery-circle-progress/1.2.2/circle-progress',
        'bootbox': 'js/library/bootbox/4.4.0/bootbox.min',
        'bootbox-def': 'js/library/bootbox/4.4.0/bootbox-def',
        'handlebars': 'js/library/handlebars/handlebars-v4.0.11',
		'jquery.validate': 'js/library/jquery-validation-1.17.0/dist/jquery.validate.min',
        'jquery-messages_es_PE': 'js/library/jquery-validation-1.17.0/src/localization/messages_es_PE',
		'jquery.validate-additional': 'js/library/jquery-validation-1.17.0/dist/additional-methods',
		'moment-with-locales': 'js/library/moment/min/moment-with-locales.min',
		'datepicker': 'js/library/bootstrap-datepicker/js/bootstrap-datepicker.min',
		'datepicker-with-locales': 'js/library/bootstrap-datepicker/locales/bootstrap-datepicker.es.min',
        'progressbar': 'js/library/progressbarjs/dist/progressbar.min',
		'openlayers': 'js/library/openlayers/build/ol'
        //'datatables-checkboxes': 'js/library/jquery-datatables-checkboxes/js/dataTables.checkboxes.min',
        //'datatables-select': 'js/library/datatables-1.10.16/extensions/Select-1.2.3/js/dataTables.select.min'
    },
    shim: {
        "global-template": {
            "deps": ['dataview']
        },
        "jquery-ui": {
            deps: ["jquery"]
        },
        "conflicts": {
            deps: ["jquery", "jquery-ui"]
        },
        "bootstrap": {
            deps: ["jquery", "jquery-ui", "conflicts"]
        },
        "adminlte": {
            deps: ["jquery", "jquery-ui", "conflicts", "bootstrap", "slimscroll", "fastclick"]
        },
        "template": {
            deps: ["adminlte", "dataview"/*, "global-string"*/]
        },
        "slimscroll": {
            deps: ["jquery"]
        },
        "dataview": {
            "deps": ['jquery']
        },
        "sidebarMenu": {
            "deps": ['jquery']
        },
        "daterangepicker": {
            "deps": ['moment']
        },
        "highcharts-common": {
            "exports": "Highcharts"
        },
        "highcharts-no-data-to-display": {
            "deps": ['highcharts-common']
        },
        "highcharts-theme-smartflex": {
            "deps": ['highcharts-offline-exporting']
        },
        "highcharts-more": {
            "deps": ['highcharts-common']
        },
        "highcharts-solid-gauge": {
            "deps": ['highcharts-more']
        },
        "highcharts-exporting": {
            "deps": ['highcharts-common']
        },
        "highcharts-offline-exporting": {
            "deps": ['highcharts-exporting']
        },
        "highcharts-export-csv": {
            "deps": ['highcharts-offline-exporting']
        },
        "datatables-common": {
            "deps": ['jquery', 'dataTables.bootstrap']
        },
        "dataTables.bootstrap": {
            "deps": ['datatables.net']
        },
        "datatables.net": {
            "deps": ['jquery']
        },
        "datatables.net-buttons": {
            "deps": ['datatables.net', 'jszip-def', 'pdfmake', 'vfs_fonts']
        },
        "datatables-buttons-html5": {
            "deps": ['datatables.net-buttons']
        },
        "datatables-plugins-dataRender-ellipsis": {
            "deps": ['datatables-common']
        },
        "jquery-circle-progress": {
            "deps": ['jquery']
        },
        "icheck": {
            "deps": ['jquery']
        },
        "bootbox": {
            "deps": ['jquery', 'bootstrap'],
            exports: 'bootbox'
        },
        "highcharts-adapt-chart-to-legend": {
            "deps": ['highcharts-common']
        },
        "select2-library": {
            "deps": ['select2']
        },
        "datatables-checkboxes": {
            "deps": ['datatables-common']
        },
        "datatables-select": {
            "deps": ['datatables-common']
       },
       "select2": {
          'deps': ['jquery']
       },
       "select2-es": {
          'deps': ['select2']
       },
       "select2-cascade": {
          'deps': ['jquery', 'select2', 'select2-es']
       },
		"jquery.validate": {
			"deps": ['jquery']
		},
		"jquery-messages_es_PE": {
			"deps": ['jquery.validate']
		},
		"jquery.validate-additional": {
			"deps": ['jquery']
		},
		"moment-with-locales": {
			"deps": ['moment']
		},
		"datepicker": {
			"deps": ['bootstrap']
		},
		"datepicker-with-locales": {
			"deps": ['datepicker']
		}
    }
});
