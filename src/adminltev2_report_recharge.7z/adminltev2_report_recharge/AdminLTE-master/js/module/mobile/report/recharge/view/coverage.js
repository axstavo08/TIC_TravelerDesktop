/**
 * Project Name : smartflex-client 
 * Created: 07/03/2018
 * @author Gustavo Ramos <C24363>
 */

define([
    //'pageLoad',
    'sidebarMenu'
], function(/*PageLoad, */sidebarMenu) {

    //Variables utiles
    var s;

    /*metodo publico*/
    function init(config) {
        console.log(config);
        //Llama a metodo para activar componentes de sidebar segun parametros de configuracion
        sidebarMenu.activeSidebar(config.root, config.main, config.subMain, config.section);
        //configuracion
        s = this.settings;
        //pageLoad
        //new PageLoad(s.pageLoad);
    }

    return {
        init: init,
        settings: {
            pageLoad: 1
        }
    };
}
);
