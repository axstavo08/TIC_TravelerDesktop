/**
 * Project Name : smartflex-client
 * Created: 21/03/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

/**  Obtener informacion de filtros para module reportes recargas
 *
 */
define(['jquery'], function($) {
     //Inicializando variables con url rest para obtener valor de filtros
    /*var REST_REG_URI = "/rest/filters/geographic/regions",
            REST_SUBREG_URI = "/rest/filters/geographic/subregions",
            REST_YEARSWEEKS_URI = "/rest/movil/acceso/filter/yearsweeks",
            REST_TECHNOLOGIES_URI = "/rest/movil/acceso/filter/technologies";*/
     var REST_GEOGRAPHYC_LEVELS_URI = "data/module/mobile/report/recharge/filter/geographic_levels.json",
		REST_NETWORK_REGIONS_URI = "data/module/mobile/report/recharge/filter/network_regions.json",
		REST_NETWORK_SUBREGIONS_URI = "data/module/mobile/report/recharge/filter/subregions.json",
		REST_SALES_REGIONS_URI = "data/module/mobile/report/recharge/filter/sales_regions.json",
		REST_DEPARTMENTS_URI = "data/module/mobile/report/recharge/filter/departments.json",
		REST_PROVINCES_URI = "data/module/mobile/report/recharge/filter/provinces.json",
		REST_DISTRICTS_URI = "data/module/mobile/report/recharge/filter/districts.json";

     //Obtener niveles de geografia
     function getGeographicLevels() {
          return $.ajax({
              //url: getURIComplete(REST_GEOGRAPHYC_LEVELS_URI),
              url: REST_GEOGRAPHYC_LEVELS_URI,
			  contentType: "application/json",
              dataType: "json",
              type: "GET",
              cache: true,
              async: true
          });
     }

    //Obtener regiones de red
    function getNetworkRegions() {
        return $.ajax({
            //url: getURIComplete(REST_NETWORK_REGIONS_URI),
            url: REST_NETWORK_REGIONS_URI,
			contentType: "application/json",
            dataType: "json",
            type: "GET",
            cache: true,
            async: true
        });
    }

    //Obtener subregions de red
    function getNetworkSubRegions() {
        return $.ajax({
            //url: getURIComplete(REST_NETWORK_SUBREGIONS_URI),
            url: REST_NETWORK_SUBREGIONS_URI,
			contentType: "application/json",
            dataType: "json",
            type: "GET",
            cache: true,
            async: true
        });
    }

    //Obtener regiones de ventas
    function getSalesRegions() {
        return $.ajax({
            //url: getURIComplete(REST_SALES_REGIONS_URI),
            url: REST_SALES_REGIONS_URI,
			contentType: "application/json",
            dataType: "json",
            type: "GET",
            cache: true,
            async: true
        });
    }

    //Obtener departamentos
    function getDepartments() {
        return $.ajax({
            //url: getURIComplete(REST_DEPARTMENTS_URI),
            url: REST_DEPARTMENTS_URI,
			contentType: "application/json",
            dataType: "json",
            type: "GET",
            cache: true,
            async: true
        });
    }

    //Obtener provincias
    function getProvinces() {
        return $.ajax({
            //url: getURIComplete(REST_PROVINCES_URI),
            url: REST_PROVINCES_URI,
			contentType: "application/json",
            dataType: "json",
            type: "GET",
            cache: true,
            async: true
        });
    }

    //Obtener distritos
    function getDistricts() {
        return $.ajax({
            //url: getURIComplete(REST_DISTRICTS_URI),
            url: REST_DISTRICTS_URI,
			contentType: "application/json",
            dataType: "json",
            type: "GET",
            cache: true,
            async: true
        });
    }

    return {
          getGeographicLevels: getGeographicLevels,
          getNetworkRegions: getNetworkRegions,
          getNetworkSubRegions: getNetworkSubRegions,
          getSalesRegions: getSalesRegions,
          getDepartments: getDepartments,
          getProvinces: getProvinces,
          getDistricts: getDistricts
    };
});
