/**
 * Project Name : smartflex-client
 * Created: 23/03/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

define([
	'recharge/util/resourceRechargeDashboard',
    'chart/chart'
], function(dashboardResource, Chart) {

    var listCharts = {};

    /*Renderiza charts*/
    function renderCharts(globalView, data){
		var typeRequest;
        //Crea nueva instancia de objeto chart
        listCharts.incremental = new Chart(dashboardResource.CHART.incremental.id, data);
        //Construye y crea chart para la vista
        listCharts.incremental.buildAndCreate();
        //Une listado de componentes con listado general de dashboard
        $.extend(globalView.view.components.charts, listCharts);
		//Actualiza validacion de creacion de charts para acciones publicas
		globalView.view.validation.chart = true;
		//Valida estado de peticion
		if(data.series.length > 0){
			typeRequest = dashboardResource.REQUEST.STATUS.SUCCESS;
		} else {
			typeRequest = dashboardResource.REQUEST.STATUS.NO_DATA;
		}
		//Agrega contador de peticiones
		globalView.request.counter[typeRequest]++;
    }

	/*Reanima y encaja graficas*/
	function reAnmateAndFitCharts(validation, charts){
		//Valida parametro validacion
		if(validation){
			Chart.reflowAndReanimateCharts(charts);
		}
	}

	//Inicia construccion de charts
	function initialize(globalView, data){
		renderCharts(globalView, data);
	}

    return {
        initialize: initialize,
		reAnmateAndFit: reAnmateAndFitCharts
    };
});
