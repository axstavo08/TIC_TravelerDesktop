/**
 * Project Name : smartflex-client
 * Created: 22/03/2018
 * @author Gustavo Ramos <C24363>
 */

define([
	'i18n!js/nls/imessages', 'recharge/ajax/DashboardAjax',
	'layers/ajax/LayersAjax', 'recharge/util/resourceRechargeDashboard',
	'objUtil', 'recharge/builder/dashboard/buildChart', 'recharge/builder/dashboard/buildBar',
	'recharge/builder/dashboard/buildMap', 'recharge/builder/buildMessage'
], function(imessages, dashboardAjax, layersAjax, dashboardResource, objUtil, ChartBuilder,
			BarBuilder, MapBuilder, MessageBuilder) {

	var globalView;

	/*Carga data*/
	function loadData() {
		//Inicializa contador de peticiones con parametro de total de peticiones
		globalView.request.counter = initializeRequestCounter(2);
		globalView.request.validation = true;
		//Obtiene objetos ajax de peticion y ejecuta
		$.when(dashboardAjax.getDashboardChart(transformFilterSelectedForView(globalView.filters.handleSelected())),
			   dashboardAjax.getDashboardData(transformFilterSelectedForView(globalView.filters.handleSelected())))
		.done(function(dataChart, data) {
            //Valida estado de retorno de peticion para chart
			if(dataChart[1] === dashboardResource.REQUEST.STATUS.SUCCESS) {
				ChartBuilder.initialize(globalView, dataChart[0]);
			} else {
				globalView.request.counter.error++;
			}
            //Valida estado de retorno de peticion para data
            if(data[1] === dashboardResource.REQUEST.STATUS.SUCCESS) {
				BarBuilder.initialize(globalView, data[0]);
				MapBuilder.initialize(globalView, 
						getLayersAjaxRequestByGeographycLevel(globalView.filters.handleSelected()).url, 
						data[0]);
			} else {
				globalView.request.counter.error++;
			}
			//Activa validacion de carga de data
			globalView.view.validation.loadData = true;
			//Muestra mensaje con parametro tipo de estado de mensaje
			MessageBuilder.showMessage(globalView.message.validation, validateStatusTypeMessage());
		});
	}

	/*Inicializa objeto contador de peticiones*/
	function initializeRequestCounter(total){
		return {
			'total': total,
			'success': 0,
			'error': 0,
			'no_data': 0
		};
	}

	/*Valida contador de peticiones para retornar tipo de estado de mensaje*/
	function validateStatusTypeMessage(){
		var counterRequest = globalView.request.counter,
			messages = dashboardResource.MESSAGES;
		//Valida contador de peticiones
		if(counterRequest.total === counterRequest.success){
			return messages.TYPE.SUCCESS;
		} else if(counterRequest.error > 0){
			return messages.TYPE.DANGER;
		} else {
			return messages.TYPE.WARNING;
		}
	}

	/*Retorna ajax para layers por nivel geografico*/
	function getLayersAjaxRequestByGeographycLevel(filters){
		var geoLevel = dashboardResource.UTIL.FILTERS.LAYERS[filters.level],
			filtersRequest = {};
		//Agrega parametros de filtros de vista a filtros de peticion
		filtersRequest.children = filters.children;
		//Valida nivel geografico por valor de filtro
		if(geoLevel === dashboardResource.UTIL.FILTERS.LEVELS.NETWORK) {
			filtersRequest.region = filters.subLevel;
			return layersAjax.getNetworkRegionLayers(filtersRequest);
		} else if (geoLevel === dashboardResource.UTIL.FILTERS.LEVELS.SALES) {
			filtersRequest.region = filters.subLevel;
			return layersAjax.getSalesRegionLayers(filtersRequest);
		} else if (geoLevel === dashboardResource.UTIL.FILTERS.LEVELS.DEPARTMENT) {
			filtersRequest.department = filters.subLevel;
			return layersAjax.getDepartmentLayers(filtersRequest);
		}
	}

	/*Transforma parametros de filtros a formato valido de peticion*/
	function transformFilterSelectedForView(filters){
		var filtersLayers = objUtil.clone(filters);
		//Remueve parametro children de filtros
		delete filtersLayers.children;
		return filtersLayers;
	}

	/*Metodo que contiene metodo reanimacion y encaje de bars para objeto publico*/
	function activeReAnimateAndFitBarMethod(validation, children, width, typeView){
		BarBuilder.reAnimateProgressBars(validation, typeView);
		BarBuilder.fitGroupBars(validation, children, width, typeView);
	}

	/*Metodo que contiene metodo de encaje de charts para objeto publico*/
	function activeReAnimateAndFitChartMethod(validation, charts){
		ChartBuilder.reAnmateAndFit(validation, charts);
	}
	
	/*Metodo que contiene metodo de encaje de bars*/
	function activeFitBarMethod(validation, children, width, typeView){
		BarBuilder.fitGroupBars(validation, children, width, typeView);
	}
	
	/*Metodo que contiene metodo de reanimacion de bars*/
	function activeReAnimateBarMethod(validation, typeView){
		BarBuilder.reAnimateProgressBars(validation, typeView);
	}
	
	/*Metodo que contiene metodo de encaje para grupo de bars de modal*/
	function activeFitGroupBarsModalMethod(validation, width){
		BarBuilder.fitGroupBarsModal(validation, width);
	}
	
	/*Metodo publico*/
	function initialize(publicView) {
		globalView =  publicView;
		console.log(globalView);
		dashboardAjax.initialize(globalView.view.wsUri);
		layersAjax.initialize(globalView.view.wsLayersUri);
	}

	return {
		initialize: initialize,
        loadData: loadData,
		activeReAnimateAndFitBar: activeReAnimateAndFitBarMethod,
		activeReAnimateAndFitChart: activeReAnimateAndFitChartMethod,
		activeFitGroupBarsModal: activeFitGroupBarsModalMethod,
		activeFitBar: activeFitBarMethod,
		activeReAnimateBar: activeReAnimateBarMethod
	};
});
