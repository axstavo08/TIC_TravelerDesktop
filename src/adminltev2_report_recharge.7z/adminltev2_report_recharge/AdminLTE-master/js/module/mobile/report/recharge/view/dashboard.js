/**
 * Project Name : smartflex-client
 * Created: 06/03/2018
 * @author Gustavo Ramos <C24363>
 */

define([
    'pageLoad',
    'sidebarMenu',
	'recharge/util/resourceRechargeDashboard',
	'recharge/component/dashboard/filterComponent',
	'recharge/component/dashboard/viewComponent',
    'recharge/event/DashboardEvent'
], function(PageLoad, sidebarMenu, dashboardResource, filterComponent, viewComponent, dashboardEvent) {

    //Variables utiles
    var settings, publicView, filters,
        wsUri, wsLayersUri,
        listCharts = {}, listBars = {}, listMaps = {};

	$('#test').on('click', function(){
		console.log(handleFiltersSelected());
		console.log(filters.DATA);
		console.log(filters.SELECTED);
	});

	//Devuelve variables para filtros
	function handleFiltersData(data){
		//Valida existencia de data para agregar nueva valor de data
		if(typeof data !== 'undefined'){
			filters.DATA = data;
		}
		return filters.DATA;
	}

	//Devuelve filtros seleccionados
	function handleFiltersSelected(){
		filters.SELECTED = filterComponent.getFilters();
		return filters.SELECTED;
	}

    //Devuelve filtros de texto
    function handleFiltersText(){
        return filterComponent.getFiltersText();
    }

    //Devuelve metodo de carga de data para componentes de vista
    function handleViewLoadData(){
        viewComponent.loadData();
    }

	//Inicializa vista inicial
    function initializeView() {
        //Obtiene recursos para asignar a variables
        filters = dashboardResource.FILTERS;
    }

	//Iniciaiza objeto publico para componentes de vista y eventos
    function initializePublicObject() {
        //Construye metodos a usar en eventos
        publicView = {};
		publicView['filters'] = {
			'handleData': handleFiltersData,
			'handleSelected': handleFiltersSelected,
            'handleText': handleFiltersText
		};
		publicView['view'] = {
			'wsUri': wsUri,
			'wsLayersUri': wsLayersUri,
            'loadData': handleViewLoadData,
            'components': {
                'charts': listCharts,
                'bars': listBars,
				'maps': listMaps
            },
            'validation': {
                'bar': false,
                'chart': false,
                'loadData': false,
				'modal': false,
				'map': true
            },
            'actions': {
                'reAnimateAndFit': {
                    'bars': viewComponent.activeReAnimateAndFitBar,
                    'charts': viewComponent.activeReAnimateAndFitChart
                },
				'fit': {
					'groupBars': viewComponent.activeFitGroupBarsModal,
					'singleBar': viewComponent.activeFitBar
				},
				'reAnimate': {
					'singleBar': viewComponent.activeReAnimateBar
				}
            }
		};
        publicView['message'] = {
            'validation': false
		};
        publicView['request'] = {
            'validation': false,
            'counter': null
		};
    }

	//Inicializa componentes para vista
    function initializeComponents() {
		//Inicializa componente de filtro
		filterComponent.initialize(publicView);
		//Inicializa componente de vista
		viewComponent.initialize(publicView);
    }

	//Inicializa eventos y alertas en vista
    function initializeEvents() {
        //Inicializa construccion de eventos
        dashboardEvent.initialize(publicView);
    }

    //Inicializa metodos
    function initializeMethods() {
        //Inicializa variables de vista
        initializeView();
        //Inicializa objeto publico para vista
        initializePublicObject();
        //Inicializa componentes para vista
        initializeComponents();
        //Inicializa eventos
        initializeEvents();
    }

    /*metodo publico*/
    function initialize(config) {
		//Almacena url de ws
		wsUri = config.urlWS;
		//Almacena url de ws de layers
		wsLayersUri = config.urlWSLayers;
         //Inicializa metodos utiles
        initializeMethods();
        //Llama a metodo para activar componentes de sidebar segun parametros de configuracion
        sidebarMenu.activeSidebar(config.root, config.main, config.subMain, config.section);
        //Obtiene configuracion publica
        settings = this.settings;
        //Inicializa PageLoad
        new PageLoad(settings.pageLoad);
    }

    return {
        initialize: initialize,
        settings: {
            pageLoad: 6
        }
    };
});
