/**
 * Project Name : smartflex-client
 * Created: 22/03/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

/**  Obtener informacion para vista de dashboard
 *
 */
define(['jquery',
		'recharge/util/resourceRechargeDashboard'
], function($, dashboardResource) {

	 //Inicializando variables con con url ws para obtener informacion
	 var WS_DASHBOARD_URI;

     //Obtener objeto ajax de informacion de chart para dashboard
     function getDashboardChart(filters) {
		var WS_DASHBOARD_CHART_URI = WS_DASHBOARD_URI;

		//Agrega parametro de tipo
		filters.type = dashboardResource.REQUEST.TYPE.CHART;

		//Completa url de ws con parametros de filtros
		WS_DASHBOARD_CHART_URI = completeWSUriWithFilters(WS_DASHBOARD_CHART_URI, filters);

		console.log(WS_DASHBOARD_CHART_URI);

		//Para prueba
		if(filters.level === "1"){
			WS_DASHBOARD_CHART_URI = "data/module/mobile/report/recharge/dashboard/chartNetwork.json";
		} else if(filters.level === "2"){
			WS_DASHBOARD_CHART_URI = "data/module/mobile/report/recharge/dashboard/chartSales.json";
		} else if(filters.level === "3"){
			WS_DASHBOARD_CHART_URI = "data/module/mobile/report/recharge/dashboard/chartDepartment.json";
		}
		console.log(WS_DASHBOARD_CHART_URI);
		return $.ajax({
		  url: WS_DASHBOARD_CHART_URI,
		  contentType: "application/json",
		  dataType: "json",
		  type: "GET",
		  cache: false,
		  async: true
		});
     }

	 //Obtener objeto ajax de informacion de data para dashboard
     function getDashboardData(filters) {
		var WS_DASHBOARD_DATA_URI = WS_DASHBOARD_URI;

		//Agrega parametro de tipo
		filters.type = dashboardResource.REQUEST.TYPE.DATA;

		//Completa url de ws con parametros de filtros
		WS_DASHBOARD_DATA_URI = completeWSUriWithFilters(WS_DASHBOARD_DATA_URI, filters);

		//Para prueba
		if(filters.level === "1"){
			WS_DASHBOARD_DATA_URI = "data/module/mobile/report/recharge/dashboard/dataNetwork.json";
		} else if(filters.level === "2"){
			WS_DASHBOARD_DATA_URI = "data/module/mobile/report/recharge/dashboard/dataSales.json";
		} else if(filters.level === "3"){
			WS_DASHBOARD_DATA_URI = "data/module/mobile/report/recharge/dashboard/dataDepartment.json";
		}
		console.log(WS_DASHBOARD_DATA_URI);
		return $.ajax({
		  url: WS_DASHBOARD_DATA_URI,
		  contentType: "application/json",
		  dataType: "json",
		  type: "GET",
		  cache: false,
		  async: true
		});
     }

	//Completa url con filtros
	 function completeWSUriWithFilters(wsUri, filters){
		var parameter, filter, counter = 0, quantityFilters = Object.keys(filters);

		 //Recorre filtros
		for(parameter in filters){
			//Valida numero de contador para agregar parametros a url
			if(counter === 0) {
				wsUri.concat("?");
			}
			//Obtiene parametro de filtro
			filter = filters[parameter];
			//Valida valor de filtro
			if(filter !== null){
				//Agrega parametro a url de ws
				wsUri.concat(parameter).concat("=").concat(filter);
				//Valida numero de contador con cantidad de parametros en filtros
				if(counter !== quantityFilters){
					wsUri.concat("&");
				}
			}
			//Aumenta contador
			counter++;
		}
		return wsUri;
	 }

	//Inicializa url de peticion a ws
	function initialize(wsUri){
		WS_DASHBOARD_URI = wsUri + "/movil/recharge/dashboard";
	}

    return {
		initialize: initialize,
		getDashboardChart: getDashboardChart,
		getDashboardData: getDashboardData
    };
});
