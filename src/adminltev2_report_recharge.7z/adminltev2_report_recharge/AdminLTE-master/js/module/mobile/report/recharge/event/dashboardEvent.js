/**
 * Project Name : smartflex-client
 * Created: 25/03/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

define([
	'recharge/util/resourceRechargeDashboard',
    'recharge/builder/buildMessage'
], function(dashboardResource, MessageBuilder) {

    var globalView, filtersClass = dashboardResource.UTIL.FILTERS.CLASS,
        filterButton = dashboardResource.UTIL.FILTERS.BUTTON,
        messages = dashboardResource.MESSAGES;

    //Eventos de boton
    function button(){
		//Click a boton de busqueda
        $.dataJS(filterButton.name).on('click', function(event){
    		var $search = $(this), filtersOk,
                $mainContent = $.dataJS(dashboardResource.UTIL.VIEW.name);
                filters = globalView.filters.handleSelected();
            //Valida filtros
    		filtersOk = $.dataJS(dashboardResource.UTIL.FILTERS.NAME).valid();
            //Valida llenado de filtros
    		if(filtersOk && filters.level !== null && filters.year_month !== null){
    			console.log("search success");
                //Habilita boton
    			$search.removeClass("disabled");
    			console.log(globalView.filters.handleSelected());
                //Activa animacion de ocultar a contenido y quita el mostrar animacion
                console.log($mainContent);
    			$mainContent.addClass(messages.ANIMATION.HIDE);
                $mainContent.removeClass(messages.ANIMATION.SHOW);
                //Elimina mensaje de contenedor padre
                $.dataJS(messages.CONTAINER.parent).empty();
                //Construye mensaje
                MessageBuilder.initialize(globalView, messages.TYPE.LOAD);
                //Activate animacion de entrada gradual
                MessageBuilder.fadeIn(globalView.message.validation);
                //Carga data
                globalView.view.loadData();
    		} else {
    			console.log("filters fail");
                //Deshabilita boton
    			$search.addClass("disabled");
    		}
            //Evita acciones de eventos de boton
    		event.preventDefault();
    	});
		//Click a boton de modal incremental
		$.dataJS(dashboardResource.BAR.incremental.main.btnBarModal).on('click', function(){
			 $.dataJS(dashboardResource.BAR.incremental.detail.modal).modal("show");
		});
    }

    //Eventos de ancho de pantalla
    function widthWindow(){
        //Valida ancho de pantalla
    	if ($(window).width() <= 500) {
    		$(filtersClass.LABEL).removeClass('col-xs-4');
    		$(filtersClass.LABEL).addClass('col-xs-12');
    		$(filtersClass.COMPONENT).removeClass('col-xs-8');
    		$(filtersClass.COMPONENT).addClass('col-xs-12');
    	} else {
    		$(filtersClass.LABEL).removeClass('col-xs-12');
    		$(filtersClass.LABEL).addClass('col-xs-4');
    		$(filtersClass.COMPONENT).removeClass('col-xs-12');
    		$(filtersClass.COMPONENT).addClass('col-xs-8');
    	}
    }

    //Eventos de redimensionamiento de pantalla
    function resizeWindow(){
        $(window).resize(function() {
    		widthWindow();
			//Encaja y reanima grupo de bars de vista principal
            globalView.view.actions.reAnimateAndFit.bars(globalView.view.validation.bar,
                                $.dataJS(dashboardResource.BAR.incremental.main.container).children(),
                                $(window).width(),
								dashboardResource.VIEW.TYPE.MAIN);
			//Encaja grupo de barras de vista modal
			globalView.view.actions.fit.groupBars(globalView.view.validation.bar, $(window).width());
			//Valida existencia de modal
			if(globalView.view.validation.modal && $.dataJS(dashboardResource.BAR.incremental.detail.modal).is(':visible')){
				//Encaja y reanima primer grupo de bars de vista detalle
				globalView.view.actions.reAnimateAndFit.bars(globalView.view.validation.bar,
									$.dataJS(dashboardResource.BAR.incremental.detail.groupContainer.first).children(),
									$(window).width(),
									dashboardResource.VIEW.TYPE.DETAIL);
				//Encaja y reanima segundo grupo de bars de vista detalle
				globalView.view.actions.reAnimateAndFit.bars(globalView.view.validation.bar,
									$.dataJS(dashboardResource.BAR.incremental.detail.groupContainer.second).children(),
									$(window).width(),
									dashboardResource.VIEW.TYPE.DETAIL);
			}
			//Encaja y reanima charts de vista
            globalView.view.actions.reAnimateAndFit.charts(globalView.view.validation.chart,
                                globalView.view.components.charts);
    	});
    }

    //Eventos de modal
    function modal(){
		//Evento cuando modal se muestra antes que lo vea el usuario
		$.dataJS(dashboardResource.BAR.incremental.detail.modal).on('show.bs.modal', function () {
            //Encaja grupos principales de modal
			globalView.view.actions.fit.groupBars(globalView.view.validation.bar, $(window).width());
			//Encaja bars de modal
			globalView.view.actions.fit.singleBar(globalView.view.validation.bar,
								$.dataJS(dashboardResource.BAR.incremental.detail.groupContainer.first).children(),
								$(window).width(),
								dashboardResource.VIEW.TYPE.DETAIL);
			globalView.view.actions.fit.singleBar(globalView.view.validation.bar,
								$.dataJS(dashboardResource.BAR.incremental.detail.groupContainer.second).children(),
								$(window).width(),
								dashboardResource.VIEW.TYPE.DETAIL);
		});
		//Evento cuando modal se muestra en vista para el usuario
		$.dataJS(dashboardResource.BAR.incremental.detail.modal).on('shown.bs.modal', function () {
            //Encaja y reanima primer grupo de bars de vista detalle
			globalView.view.actions.reAnimate.singleBar(globalView.view.validation.bar,
								dashboardResource.VIEW.TYPE.DETAIL);
			//Encaja y reanima segundo grupo de bars de vista detalle
			globalView.view.actions.reAnimate.singleBar(globalView.view.validation.bar,
								dashboardResource.VIEW.TYPE.DETAIL);
		});
    }

	//Inicia eventos
	function initialize(publicView){
        globalView = publicView;
		//Inicializa eventos de componentes y visuales
        button();
        widthWindow();
        resizeWindow();
        modal();
	}

    return {
        initialize: initialize
    };
});
