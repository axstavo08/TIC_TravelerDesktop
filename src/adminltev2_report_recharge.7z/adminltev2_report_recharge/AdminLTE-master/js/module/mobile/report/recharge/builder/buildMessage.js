/**
 * Project Name : smartflex-client
 * Created: 23/03/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

define([
	'recharge/util/resourceRechargeDashboard',
    'handlebars'
], function(dashboardResource, Handlebars) {

    var messages = dashboardResource.MESSAGES;

    //Crea mensaje
    function createMessage(globalView, message){
        buildMessage(globalView, {'type': message.type, 'button': message.button,
                'icon': message.icon, 'content': message.content});
    }

    //Construye mensaje
    function buildMessage(globalView, context){
        var source   = document.getElementById(messages.TEMPLATE).innerHTML;
        var template = Handlebars.compile(source);
        var html = template(context);
        $.dataJS(messages.CONTAINER.parent).html(html);
        //Activa parametro validacion de creacion de mensaje
        globalView.message.validation = true;
    }

    //Muestra estado de mensaje luego de cargar data
    function showMessageAfterLoad(validation, message){
        var mainContainer = $.dataJS(messages.CONTAINER.main);
        //Valida parametro validacion
        if(validation){
            //Remueve todos los estilos y agrega clase de mensaje
            mainContainer.removeClass().addClass(message.class);
            //Encuentra componente span y agrega contenido de texto
            mainContainer.find('span').text(message.content);
            //Ejecuta metodo para boton cerrar de mensaje
            message.buttonDisplay();
            //Encuentra componente i para cambiar icono
            mainContainer.find('i').removeClass().addClass(message.icon);
            //Valida tipo de estado de mensaje
            if(message === messages.TYPE.SUCCESS){
                //Tiempo progresivo para borrado de mensaje exitosoy muestra data
    			setTimeout(function() {
                    //Activate animacion de salida gradual
                    fadeOutAnimation(validation);
    			}, 1500);
            }
        }
    }

    //Animacion de entrada gradual
    function fadeInAnimation(validation){
        var message = messages.CONTAINER.main;
        //Valida parametro validacion
        if(validation){
            $.dataJS(message).fadeIn({
                duration: 1400,
                easing: "linear",
                start: function() {
                   $.dataJS(message).removeClass('hidden');
                }
            });
        }
    }

    //Animacion de salida gradual
    function fadeOutAnimation(validation){
        var message = messages.CONTAINER.main;
        //Valida parametro validacion
        if(validation){
            $.dataJS(message).fadeOut(
                  {
                      duration: 800,
                      easing: "linear",
                      complete: function(){
                           $.dataJS(message).remove();
                           $.dataJS(dashboardResource.UTIL.VIEW.name).removeClass(messages.ANIMATION.HIDE);
                           $.dataJS(dashboardResource.UTIL.VIEW.name).addClass(messages.ANIMATION.SHOW);
						   //Tiempo progresivo para borrado de clase de mostrado de animacion
							setTimeout(function() {
								//Activate animacion de salida gradual
								$.dataJS(dashboardResource.UTIL.VIEW.name).removeClass(messages.ANIMATION.SHOW);
							}, 600);
                      }
                  }
           );
        }
    }

	//Inicia construccion de mensaje
	function initialize(globalView, message){
		createMessage(globalView, message);
	}

    return {
        initialize: initialize,
        fadeIn: fadeInAnimation,
        fadeOut: fadeOutAnimation,
        showMessage: showMessageAfterLoad
    };
});
