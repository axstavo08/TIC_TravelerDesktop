/**
 * Project Name : smartflex-client
 * Created: 06/03/2018
 * @author Gustavo Ramos <C24363>
 */

define([
     'i18n!js/nls/imessages',
     'recharge/ajax/FilterAjax',
	 'recharge/util/resourceRechargeDashboard',
	 'select2-configuration',
	 'datepickerMonth',
	 'select2-es',
	 'jquery-messages_es_PE',
	 'jquery.validate-additional'
], function(imessages, filterAjax, dashboardResource, select2Configuration, DatepickerMonth) {

	var globalView, filtersData, filtersComponent = {}, firstLoadValidation = true,
		filtersSelected = {'level': null, 'sublevel': null, 'year_month': null, 'children': null},
        filtersText = {level: null, 'sublevel': null},
		$form = $.dataJS(dashboardResource.UTIL.FILTERS.NAME),
        $button = $.dataJS(dashboardResource.UTIL.FILTERS.BUTTON.name);

	/*Carga data*/
	function loadData() {
		//Obtiene objetos ajax de peticion y ejecuta
		$.when(filterAjax.getGeographicLevels(),
				filterAjax.getNetworkRegions(),
				filterAjax.getSalesRegions(),
				filterAjax.getDepartments())
		.done(function(dataGeoLevels, dataNetRegs, dataSalesRegs, dataDeps) {
			//Inicializa data de filtros como objeto
			filtersData = {};
			//Valida estado de retorno de peticion de niveles geograficos
			if(dataGeoLevels[1] === dashboardResource.REQUEST.STATUS.SUCCESS) {
				filtersData['geographycLevels'] = processFilterData(dataGeoLevels[0]);
			}
			//Valida estado de retorno de peticion de regiones de red
			if(dataNetRegs[1] === dashboardResource.REQUEST.STATUS.SUCCESS) {
				filtersData['networkRegions'] = processFilterData(dataNetRegs[0]);
			}
			//Valida estado de retorno de peticion de regiones de ventas
			if(dataSalesRegs[1] === dashboardResource.REQUEST.STATUS.SUCCESS) {
				filtersData['salesRegions'] = processFilterData(dataSalesRegs[0]);
			}
			//Valida estado de retorno de peticion de departamentos
			if(dataDeps[1] === dashboardResource.REQUEST.STATUS.SUCCESS) {
				filtersData['departments'] = processFilterData(dataDeps[0]);
			}
			//Actualiza data de vista principal
			globalView.filters.handleData(filtersData);
			//Inicializa variable para contener objetos de select
			filtersComponent['select'] = {};
			//Construye componentes select
			buildSelects();
            //Carga data inicial para componentes de vista
            globalView.view.loadData();
		});
	}

	/*Procesa data y transforma a formato de select2*/
	function processFilterData(data) {
		var items = [], item, iData, oData;
		//Recorre data
		for(iData in data) {
			//Inicializa objeto item
			item = {};
			//Obtiene objeto data de listado
			oData = data[iData];
			//Llena data para item
			item['id'] = oData.id;
			item['text'] = oData.label;
			//Valida que data tenga propiedad selected
			if(oData.hasOwnProperty('selected')) {
				item['selected'] = oData.selected;
			}
			items.push(item);
		}
		return items;
	}

	/*Inicializa calendario de mes*/
	function initializeMonthCalendar() {
		//Inicializa componente fecha
		filtersComponent['date'] = new DatepickerMonth($.dataJS(dashboardResource.UTIL.CALENDAR_MONTH.NAME), true);
		//Construye y crea fecha
		filtersComponent['date'].buildAndCreate();
	}

	/*Inicializa validacion de formulario de filtros*/
	function initializeValidationForm() {
		//Deshabilita atributo required para validacion
		$.validator.messages.required = '';
		//Agrega metodo de validacion para calendaria de mes
		$.validator.addMethod("calendarMonth", function (value, element) {
			//Valida valor de calendario de mes
			if(value === "" || value === 'Fuera de limite'){
				return false;
			}
			if(filtersComponent['date'].getParameters().year_month === null && value === 'Error en fecha'){
				return false;
			}
			return true;
		}, "");
		//Agrega metodo de validacion para select2
		$.validator.addMethod("validSelect", function (value, element) {
			//Valida valor de select2
			if(value ===  null || typeof value === 'undefined'){
				return false;
			}
			return true;
		}, "");
		//Valida formulario
		$form.validate({
			errorClass: 'input-danger-cust',
			rules: {
				calendarMonth: {
					calendarMonth: true
				},
				sGeoLevel: {
					validSelect: true
				},
			},
			highlight: function(element) {
				$element = $(element);
				if ($element.hasClass('select2')) {
					$element.parent().find('.select2-selection').addClass('input-danger-cust');
				} else {
					$element.addClass('input-danger-cust');
				}
				$button.addClass("disabled");
			},
			unhighlight: function(element) {
				$element = $(element);
				if ($element.hasClass('select2')) {
					$element.parent().find('.select2-selection').removeClass('input-danger-cust');
				} else {
					$element.removeClass('input-danger-cust');
				}
				$button.removeClass("disabled");
			}
		});
	}

	/*Construye componentes select*/
	function buildSelects(){
		//Crea y almacena en variable componente select2 para nivel geografico
		filtersComponent.select['geographycLevel'] = $.dataJS('sGeoLevel').select2({
			theme: select2Configuration.THEME.BOOTSTRAP,
			closeOnSelect: select2Configuration.CLOSE_ON_SELECT.ACTIVE,
			language: select2Configuration.LANGUAGE.ES,
			data: filtersData['geographycLevels'],
			placeholder: imessages.recharge.select.placeholder,
			allowClear: select2Configuration.ALLOW_CLEAR.ACTIVE,
			minimumResultsForSearch: select2Configuration.MINIMUN_RESULTS_FOR_SEARCH.NEVER,
		});
		//Obtiene valor actual de select2 para nivel geografico
		filtersSelected['level'] = filtersComponent.select['geographycLevel'].val();
        filtersText['level'] = filtersComponent.select['geographycLevel'].select2('data')[0]['text'];
		//Crea y almacena en variable componente select2 para subnivel
		filtersComponent.select['subGeographycLevel'] = $.dataJS('sSubGeoLevel').select2({
			theme: select2Configuration.THEME.BOOTSTRAP,
			closeOnSelect: select2Configuration.CLOSE_ON_SELECT.ACTIVE,
			language: select2Configuration.LANGUAGE.ES,
			data: filtersData[dashboardResource.UTIL.FILTERS.ATTRIBUTE[filtersSelected.level]],
			placeholder: imessages.recharge.select.placeholder,
			allowClear: select2Configuration.ALLOW_CLEAR.ACTIVE,
			minimumResultsForSearch: select2Configuration.MINIMUN_RESULTS_FOR_SEARCH.NEVER,
		});
		updateLabelGeographycSublevel(filtersComponent.select['geographycLevel'].select2('data')[0]);
		//Limpia select2 para subnivel geografico
		filtersComponent.select['subGeographycLevel'].val(null).trigger('change');
		//Activa trigger para seleccion de select para nivel geografico
		filtersComponent.select['geographycLevel'].on('select2:select', function() {
			//Actualiza valor de filtro
			filtersSelected.level = $(this).val();
            filtersText.level = filtersComponent.select['geographycLevel'].select2('data')[0]['text'];
			//Destruye select child, limpia data y crea select2 nuevo
			filtersComponent.select['subGeographycLevel'].select2('destroy').empty().select2({
                theme: select2Configuration.THEME.BOOTSTRAP,
				closeOnSelect: select2Configuration.CLOSE_ON_SELECT.ACTIVE,
                language: select2Configuration.LANGUAGE.ES,
				data: filtersData[dashboardResource.UTIL.FILTERS.ATTRIBUTE[filtersSelected.level]],
                placeholder: imessages.recharge.select.placeholder,
				allowClear: select2Configuration.ALLOW_CLEAR.ACTIVE,
				minimumResultsForSearch: 20,
            });
			//Limpia select2 para subnivel geografico
			filtersComponent.select['subGeographycLevel'].val(null).trigger('change');
		});
		//Activa trigger de cambio de select para nivel geografico
		filtersComponent.select['geographycLevel'].on('change', function() {
			var selectId = $(this).val(), selectText = $(this).select2('data')[0];
			$(this).valid();
			updateLabelGeographycSublevel(selectText);
			if(selectId === null){
				filtersComponent.select['subGeographycLevel'].empty();
			}
		});
		//Activa trigger para seleccion de select para subnivel geografico
		filtersComponent.select['subGeographycLevel'].on('change', function() {
			var selectId = $(this).val();
			//Actualiza valor de filtro
			filtersSelected.sublevel = selectId;
			filtersSelected.children = (selectId === null) ? selectId : false;
            filtersText.sublevel = (selectId !== null) ? filtersComponent.select['subGeographycLevel'].select2('data')[0]['text'] : null;
		});
	}

	//Actualiza etiqueta de filtro subnivel geografico
	function updateLabelGeographycSublevel(label){
		$.dataJS('lbSubGeoLevel').text((typeof label !== 'undefined' && label !== null)
							? label.text : dashboardResource.UTIL.DEFAULT.SUB_GEO_LEVEL);
	}

	//Obtiene filtros seleccionados
	function getFilters(){
		//Valida estado de boton de busqueda para llenado de valores de filtros faltantes
		if(!$button.hasClass('disabled')){
			filtersSelected.year_month = filtersComponent['date'].getParameters().year_month;
		}
		return filtersSelected;
	}

    //Obtiene filtros con texto
    function getFiltersText(){
        return filtersText;
    }

	/*Metodo publico*/
	function initialize(publicView) {
		globalView = publicView;
		console.log(globalView);
		initializeValidationForm();
		loadData();
		initializeMonthCalendar();
	}

	return {
		initialize: initialize,
		getFilters: getFilters,
        getFiltersText: getFiltersText
	};
});
