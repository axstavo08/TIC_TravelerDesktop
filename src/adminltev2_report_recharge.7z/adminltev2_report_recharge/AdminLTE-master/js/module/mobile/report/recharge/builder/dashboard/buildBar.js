/**
 * Project Name : smartflex-client
 * Created: 23/03/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

define([
	'recharge/util/resourceRechargeDashboard', 'global-colors',
	'handlebars', 'progressBar',
], function(dashboardResource, gColors, Handlebars, ProgressBarUtil) {

    var globalView, listBars = {}, typeBar = dashboardResource.UTIL.BAR.TYPE,
		statusBar = dashboardResource.UTIL.BAR.STATUS,
		barTemplate = dashboardResource.UTIL.BAR.TEMPLATE,
		containerElementBar = dashboardResource.UTIL.BAR.ELEMENT,
		containerBar = {'main': $.dataJS(dashboardResource.BAR.incremental.main.container),
						'detail': $.dataJS(dashboardResource.BAR.incremental.detail.container)},
		groupContainerBar = {'first': $.dataJS(dashboardResource.BAR.incremental.detail.groupContainer.first),
						     'second': $.dataJS(dashboardResource.BAR.incremental.detail.groupContainer.second)};
			

    /*Renderiza bars*/
    function renderBars(globalView, data){
        var geoLevel = dashboardResource.UTIL.FILTERS.LAYERS[globalView.filters.handleSelected().level],
            topTenHeader = $.dataJS(dashboardResource.BAR.incremental.main.topTenHeader),
            contBarModal = $.dataJS(dashboardResource.BAR.incremental.main.contBarModal),
            parentContainerBar = $.dataJS(dashboardResource.BAR.incremental.main.parentContainer),
            parentContBarName = $.dataJS(dashboardResource.BAR.incremental.main.parentContainerName);

        //Limpia bars en contenedor
        containerBar.main.empty();
		groupContainerBar.first.empty();
		groupContainerBar.second.empty();
        //Limpia estilos en contenedor
		containerBar.main.removeClass();
		groupContainerBar.first.removeClass();
		groupContainerBar.second.removeClass();
        //Valida nivel geografico para acciones con contenedor
        if(geoLevel === dashboardResource.UTIL.FILTERS.LEVELS.NETWORK){
			topTenHeader.addClass('hidden');
			contBarModal.addClass('hidden');
		} else if(geoLevel === dashboardResource.UTIL.FILTERS.LEVELS.SALES){
			topTenHeader.addClass('hidden');
			contBarModal.addClass('hidden');
		} else if(geoLevel === dashboardResource.UTIL.FILTERS.LEVELS.DEPARTMENT){
			topTenHeader.removeClass('hidden');
			contBarModal.removeClass('hidden');
		}

		//Agrega contador de peticiones
		globalView.request.counter.success++;

        //Valida parametro de filtro subnivel geografico
        if(globalView.filters.handleSelected().sublevel === null) {
			containerBar.main.addClass('container-bars');
			containerBar.main.addClass('bars-height-'.concat(geoLevel));
			parentContBarName.text(globalView.filters.handleText().level);
			createBars(geoLevel, data);
			parentContainerBar.removeClass('hidden');
		} else {
			parentContainerBar.addClass('hidden');
			//Actualiza validacion de creacion de bars para acciones publicas
			globalView.view.validation.bar = false;
			//Actualiza validacion de creacion de modal para acciones publicas
			globalView.view.validation.modal = false;
		}
    }

		//Crea barras de progreso
	function createBars(geoLevel, data){
		var valueBarsMax = {'main': $.dataJS(dashboardResource.BAR.incremental.main.max.label),
							'detail': $.dataJS(dashboardResource.BAR.incremental.detail.max.label)},
			valueBarsMin = {'main': $.dataJS(dashboardResource.BAR.incremental.main.min.label),
							'detail': $.dataJS(dashboardResource.BAR.incremental.detail.min.label)},
			valuesData = data.values, maxData = data.max, iData, nodeData,
			typeDataBar, percentage, statusColor, oStatusTypeBar, statusNegative, statusPositive, counter = 1,
			groupContainerBarModal;
		//Actualiza texto de valor para barras
		valueBarsMax.main.text(maxData.positive);
		valueBarsMin.main.text(maxData.negative);
		valueBarsMax.detail.text(maxData.positive);
		valueBarsMin.detail.text(maxData.negative);
		//Inicializa objeto para vista principal
        listBars.main = {};
		//Inicializa objeto para vista modal
        listBars.detail = {};
		//Recorre data
		for(iData in valuesData){
			//Obtiene nodo de data
			nodeData = valuesData[iData];
			//Obtiene tipo de bar
			typeDataBar = getTypeDataBar(nodeData.variation);
			//Obtiene porcentaje por valor, tipo de bar y valor maximo
			percentage = getPercentage(nodeData.variation, typeDataBar, maxData);
			//Obtiene estado de color para bar
			statusColor = getStatusColor(percentage, typeDataBar);
			//Obtiene objeto con estados de color para tipos de barra
			oStatusTypeBar = getTypeDataBarStatusColor(typeDataBar,statusColor);
			//Almacena en variable estado de color de bar negativo
			statusNegative = oStatusTypeBar.NEGATIVE;
			//Almacena en variable estado de color de bar positivo
			statusPositive = oStatusTypeBar.POSITIVE;
			//Valida tipo de nivel geografico
			if(geoLevel === dashboardResource.UTIL.FILTERS.LEVELS.DEPARTMENT){
				//Valida grupo de bars donde se creara bar
				groupContainerBarModal = (counter <= 13) ? groupContainerBar.first : groupContainerBar.second
				//Crea componente de bar para vista modal
				buildBarComponent(groupContainerBarModal,
								  createContextForBarComponent(geoLevel, nodeData, statusColor,
											statusNegative.name, statusPositive.name,
											dashboardResource.VIEW.TYPE.DETAIL));
				//Llena propiedades para bar
				listBars.detail[nodeData.name] = {};
				//Crea objeto bar con propiedades
				createObjectBarContext(listBars.detail, percentage, typeDataBar, nodeData.name, statusColor.color);
				//Actualiza validacion de creacion de modal para acciones publicas
				globalView.view.validation.modal = true;
			}
			//Valida valor de contador para bars de vista general
			if(counter <= 10){
				//Crea componente de bar para vista principal
				buildBarComponent(containerBar.main,
								  createContextForBarComponent(geoLevel, nodeData, statusColor,
												statusNegative.name, statusPositive.name,
												dashboardResource.VIEW.TYPE.MAIN));
				//Crea objeto bar con propiedades
				createObjectBarContext(listBars.main, percentage, typeDataBar, nodeData.name, statusColor.color);
			}
			//Aumenta valor de contador
			counter++;
		}
		//Acomoda componente padre bar por ancho de pantalla
		fitGroupBarsByWindowWidth(true, containerBar.main.children(), $(window).width(), dashboardResource.VIEW.TYPE.MAIN);
		//Valida variable para acomodar grupo de bars de modal
		if(globalView.view.validation.modal){
			fitGroupBarsByWindowWidth(true, containerBar.detail.children(), $(window).width(), dashboardResource.VIEW.TYPE.DETAIL);
		}
		//Une listado de componentes con listado general de dashboard
        $.extend(globalView.view.components.bars, listBars);
		//Actualiza validacion de creacion de bars para acciones publicas
		globalView.view.validation.bar = true;
	}

	//Crea objeto contexto para creacion de bar
	function createContextForBarComponent(geoLevel, incremental, statusColor,
								statusNegative, statusPositive, typeView){
		//Retorna objeto contexto
		return {'geo-level': geoLevel, 'label': incremental.label,
				 'name': incremental.name, 'value': incremental.variation,
				 'status': statusColor.name, 'orientation': statusColor.orientation,
				 'status-negative': statusNegative, 'status-positive': statusPositive,
				 'view': typeView};
	}

	//Crea componente bar con objeto contexto
	function buildBarComponent(typeContainer, context) {
		var source   = document.getElementById(barTemplate).innerHTML;
		var template = Handlebars.compile(source);
		var html = template(context);
		typeContainer.append(html);
	}

	//Crea objeto bar y sus propiedades por tipo de vista
	function createObjectBarContext(bar, percentage, typeDataBar, name, statusColor){
		//Completa lista de bar con propiedades
		bar[name] = {};
		bar[name].percentage = getPercentageToAnimate(percentage, typeDataBar);
		bar[name].active = typeDataBar;
		bar[name].component = {};
		//Crea objeto bar para tipo negativo
		bar[name].component[typeBar.NEGATIVE] = new ProgressBarUtil('#bar_'.concat(name).concat('_').concat(typeBar.NEGATIVE),
																getOptionsBar(statusColor));
		//Crea y construye bar tipo negativo
		bar[name].component[typeBar.NEGATIVE].buildAndCreate();
		//Crea objeto bar para tipo positivo
		bar[name].component[typeBar.POSITIVE] = new ProgressBarUtil('#bar_'.concat(name).concat('_').concat(typeBar.POSITIVE),
																getOptionsBar(statusColor));
		//Crea y construye bar tipo positivo
		bar[name].component[typeBar.POSITIVE].buildAndCreate();
		//Valida tipo de bar para animacion con valor
		if(typeDataBar !== typeBar.NONE){
			//Anima a bar activo con valor
			bar[name].component[typeDataBar].animate(bar[name].percentage);
		}
	}

	//Obtiene opciones para progressbar
	function getOptionsBar(statusColor){
		return {
			strokeWidth: 4,
			easing: 'easeInOut',
			duration: 2000,
			color: statusColor,
			trailColor: gColors.BAR.WHITE_SMOKE,
			trailWidth: 1,
			svgStyle: {width: '100%', height: '100%'}
		};
	}

	//Obtiene tipo de bar por valor para bar
	function getTypeDataBar(value) {
		return (value < 0) ? typeBar.NEGATIVE : (value > 0) ? typeBar.POSITIVE : typeBar.NONE;
	}

	//Obtiene valor de porcentaje para bar
	function getPercentage(input, typeDataBar, oMax) {
		var max = (typeDataBar === typeBar.NEGATIVE) ? oMax.negative : (typeDataBar === typeBar.POSITIVE) ? oMax.positive : 0;
		if(input != 0) {
			return (input/max).toFixed(3);
		}
		return 0;
	}

	//Obtiene estado de color para bar
	function getStatusColor(value, typeDataBar){
		//Valida tipo de data bar para acciones
		if(typeDataBar === typeBar.POSITIVE) {
			//Valida valor para retorno de estado de color para bar
			if(value > 0 && value <= 0.5) {
				return statusBar.NOT_SO_GOOD;
			} else if (value > 0.5 && value <= 1) {
				return statusBar.GOOD;
			}
		} else if (typeDataBar === typeBar.NEGATIVE) {
			//Valida valor para retorno de estado de color para bar
			if(value > 0 && value <= 0.5) {
				return statusBar.NOT_SO_BAD;
			} else if (value > 0.5 && value <= 1) {
				return statusBar.BAD;
			}
		} else if (typeDataBar === typeBar.NONE && value === 0) {
			//Retorna estado de color en reposo
			return statusBar.REPOSE;
		} else {
			//Retorna estado de color con errores
			return statusBar.INCORRECT;
		}
	}

	//Obtiene tipo de data por estado de color
	function getTypeDataBarStatusColor(type, statusColor) {
		var statusTypeBar = {'POSITIVE': null, 'NEGATIVE': null};
		//Valida tipo de data bar para dar estado de color
		if(type === typeBar.POSITIVE){
			statusTypeBar.NEGATIVE = statusBar.REPOSE;
			statusTypeBar.POSITIVE = statusColor;
		} else if(type === typeBar.NEGATIVE){
			statusTypeBar.NEGATIVE = statusColor;
			statusTypeBar.POSITIVE = statusBar.REPOSE;
		} else if(type === typeBar.NONE){
			statusTypeBar.NEGATIVE = statusColor;
			statusTypeBar.POSITIVE = statusColor;
		} else {
			statusTypeBar.NEGATIVE = statusBar.INCORRECT;
			statusTypeBar.POSITIVE = statusBar.INCORRECT;
		}
		return statusTypeBar;
	}

	//Retorna valor de porcentaje transformado para animacion
	function getPercentageToAnimate(value, typeDataBar){
		return (typeDataBar === typeBar.NEGATIVE) ? value*(-1) : value;
	}

	//Acomoda grupo de bars por ancho de pantalla
	function fitGroupBarsByWindowWidth(validation, children, width, typeView){
		var iChildren, child, 
			labelBar, componentBar, valueBar;
		//Valida parametro validacion
		if(validation) {
			for(iChildren=0; iChildren<=children.length-1; iChildren++){
				child = $(children[iChildren]);
				labelBar = child.find(containerElementBar[typeView].LABEL);
				componentBar = child.find(containerElementBar[typeView].COMPONENT);
				valueBar = child.find(containerElementBar[typeView].VALUE);
				//Valida tipo de vista detalle para acciones de acomodamiento de grupo de bars
				if(typeView === dashboardResource.VIEW.TYPE.MAIN){
					//Valida ancho de pantalla para acciones
					if (width <= 500) {
						fitBarByUnderOrEqualLimitWindowWidthMain(labelBar, componentBar, valueBar);
					} else {
						fitBarByOverLimitWindowWidthMain(labelBar, componentBar, valueBar);
					}
				} else if(typeView === dashboardResource.VIEW.TYPE.DETAIL){
					//Valida ancho de pantalla para acciones
				    if(width >= 1200) {
						fitBarByOverLimitWindowWidthDetail(labelBar, componentBar, valueBar);
					} else if(width < 1200 && width >= 768) {
						fitBarByUnderOrEqualLimitWindowWidthDetail(labelBar, componentBar, valueBar);
					} else if(width < 768 && width >= 600) {
						fitBarByUnderOrEqualLimitWindowWidthDetail(labelBar, componentBar, valueBar);
					} else if(width < 600 && width >= 520) {
						fitBarByOverLimitWindowWidthDetail(labelBar, componentBar, valueBar);
					} else {
						fitBarByUnderOrEqualLimitWindowWidthDetail(labelBar, componentBar, valueBar);
					}
				}
			}
		}
	}
	
	//Acomoda grupos principales de modal
	function fitGroupBarsModal(validation, width){
		var iChildren, child, 
			labelBar, componentBar, valueBar;
		//Valida parametro validacion
		if(validation) {
			//Valida ancho de pantalla para acciones
			if(width >= 1200) {
				fitSplittedGroupBarsModal();
			} else if(width < 1200 && width >= 768) {
				fitSplittedGroupBarsModal();
			} else if(width < 768 && width >= 600) {
				fitJoinedGroupBarsModal();
			} else {
				fitJoinedGroupBarsModal();
			}
		}
	}
	
	//Encaje de bar en vista mayor a limite de ancho para vista principal
	function fitBarByOverLimitWindowWidthMain(labelBar, componentBar, valueBar){
		valueBar.insertAfter(componentBar);
		labelBar.removeClass('col-xs-6');
		labelBar.addClass('col-xs-3');
		componentBar.removeClass('col-xs-12');
		componentBar.addClass('col-xs-6');
		valueBar.removeClass('col-xs-6');
		valueBar.addClass('col-xs-3');
	}
		
	//Encaje de bar en vista menor o igual limite de ancho para vista principal
	function fitBarByUnderOrEqualLimitWindowWidthMain(labelBar, componentBar, valueBar){
		valueBar.insertBefore(componentBar);
		labelBar.removeClass('col-xs-3');
		labelBar.addClass('col-xs-6');
		componentBar.removeClass('col-xs-6');
		componentBar.addClass('col-xs-12');
		valueBar.removeClass('col-xs-3');
		valueBar.addClass('col-xs-6');
	}
	//Encaje de bar en vista mayor a limite de ancho para vista detalle
	function fitBarByOverLimitWindowWidthDetail(labelBar, componentBar, valueBar){
		valueBar.insertAfter(componentBar);
		labelBar.removeClass('col-xs-6').removeClass('col-sm-6').removeClass('col-md-6');
		labelBar.addClass('col-xs-3').addClass('col-sm-3').addClass('col-md-4');
		componentBar.removeClass('col-xs-12').removeClass('col-sm-12').removeClass('col-md-12');
		componentBar.addClass('col-xs-6').addClass('col-sm-6').addClass('col-md-5');
		valueBar.removeClass('col-xs-6').removeClass('col-sm-6').removeClass('col-md-6');
		valueBar.addClass('col-xs-3').addClass('col-sm-3').addClass('col-md-3');
	}

	//Encaje de bar en vista menor o igual limite de ancho para vista principal
	function fitBarByUnderOrEqualLimitWindowWidthDetail(labelBar, componentBar, valueBar){
		valueBar.insertBefore(componentBar);
		labelBar.removeClass('col-xs-3').removeClass('col-sm-3').removeClass('col-md-4');
		labelBar.addClass('col-xs-6').addClass('col-sm-6').addClass('col-md-6');
		componentBar.removeClass('col-xs-6').removeClass('col-sm-6').removeClass('col-md-5');
		componentBar.addClass('col-xs-12').addClass('col-sm-12').addClass('col-md-12');
		valueBar.removeClass('col-xs-3').removeClass('col-sm-3').removeClass('col-md-3');
		valueBar.addClass('col-xs-6').addClass('col-sm-6').addClass('col-md-6');
	}
	
	//Encaja grupos principales de bars de vista modal mostrado divido
	function fitSplittedGroupBarsModal(){
		var firstGroup = $.dataJS(dashboardResource.BAR.incremental.detail.groupParentContainer.first),
			secondGroup = $.dataJS(dashboardResource.BAR.incremental.detail.groupParentContainer.second);
		firstGroup.removeClass('col-xs-12').removeClass('col-sm-12').removeClass('col-md-12').removeClass('col-lg-12');
		firstGroup.addClass('col-xs-6').addClass('col-sm-6').addClass('col-md-6').addClass('col-lg-6');
		secondGroup.removeClass('col-xs-12').removeClass('col-sm-12').removeClass('col-md-12').removeClass('col-lg-12');
		secondGroup.addClass('col-xs-6').addClass('col-sm-6').addClass('col-md-6').addClass('col-lg-6');
	}
	
	//Encaja grupos principales de bars de vista modal mostrado unido
	function fitJoinedGroupBarsModal(){
		var firstGroup = $.dataJS(dashboardResource.BAR.incremental.detail.groupParentContainer.first),
			secondGroup = $.dataJS(dashboardResource.BAR.incremental.detail.groupParentContainer.second);
		firstGroup.addClass('col-xs-12').addClass('col-sm-12').addClass('col-md-12').addClass('col-lg-12');
		firstGroup.removeClass('col-xs-6').removeClass('col-sm-6').removeClass('col-md-6').removeClass('col-lg-6');
		secondGroup.addClass('col-xs-12').addClass('col-sm-12').addClass('col-md-12').addClass('col-lg-12');
		secondGroup.removeClass('col-xs-6').removeClass('col-sm-6').removeClass('col-md-6').removeClass('col-lg-6');
	}
	
	//Reanima todos los bars de los tipos de vistas
	function reAnimateProgressBars(validation, typeView) {
		var bars = globalView.view.components.bars[typeView],
			iBar, bar, component;
		//Valida parametro validacion
		if(validation) {
			//Recorre bars por tipo de vista
			for(iBar in bars){
				//Obtiene barra por tipo de vista
				bar = bars[iBar];
				//Valida que bar activo sea diferente a ninguno
				if(bar.active !== typeBar.NONE){
					//Obtiene componente bar activo
					component = bar.component[bar.active];
					//Reanima componente bar activo con valor de porcentaje
					component.reAnimate(bar.percentage);
				}
			}
		}
	}

	//Inicia construccion de bars
	function initialize(publicView, data){
		globalView = publicView;
		//Renderiza bars
		renderBars(globalView, data);
	}

    return {
        initialize: initialize,
		reAnimateProgressBars: reAnimateProgressBars,
		fitGroupBars: fitGroupBarsByWindowWidth,
		fitGroupBarsModal: fitGroupBarsModal
    };
});
