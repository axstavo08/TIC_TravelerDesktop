/**
 * Project Name : smartflex-client
 * Created: 23/03/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

define([
	'recharge/util/resourceRechargeDashboard',
    'openlayers',
    'global-images'
], function(dashboardResource, ol, gImages) {

    var listMaps = {};

    /*Renderiza charts*/
    function buildMap(globalView, urlKml, data){
		var map, kmlLayer;
		//Obtiene map guardado en listado si lo hubiese
		map = listMaps["incremental"];
		//Crea capa kml
		kmlLayer = new ol.layer.Vector({
			name: "kml",
			source: new ol.source.Vector({
				url: urlKml,
				format: new ol.format.KML({
					projection: 'EPSG:3857',
					extractStyles: false
				})
			}),
			style: (function() {
				var stroke = new ol.style.Stroke({
						color: 'black'
					}),
					textStroke = new ol.style.Stroke({
						color: '#fff',
						width: 3
					}),
					textFill = new ol.style.Fill({
						color: '#000'
					});
				//Retorna estilo para capas
				return function(feature, resolution) {
					/*var x, obj, increment, color, text = "";
					for (x in techData) {
						obj = techData[x];
						if (obj["key"] == feature.get("name")) {
							increment = obj["variation"];
							break;
						}
					}
					if (increment === VIEWS.NO_DATA) {
						color = MAP_CONFIG['STATUS_COLORS']['DEFAULT'];
						text = feature.get('name') + "\n" + increment;
					} else if (increment > 1) {
						color = MAP_CONFIG['STATUS_COLORS']['POOR'];
						text = feature.get('name') + "\n" + "\u2193" + increment + "%";
					} else if (increment < -1) {
						color = MAP_CONFIG['STATUS_COLORS']['GOOD'];
						text = feature.get('name') + "\n" + "\u2191" + (increment * -1) + "%";
					} else if (increment >= -1 && increment <= 1) {
						color = MAP_CONFIG['STATUS_COLORS']['EQUALS'];
						text = feature.get('name') + "\n" + "\u2192" + ((increment < 0) ? increment * (-1) : increment) + "%";
					} else {
						color = MAP_CONFIG['STATUS_COLORS']['DEFAULT'];
						text = feature.get('name');
					}*/
					//Retorna estilo de texto
					return [new ol.style.Style({
							stroke: stroke,
							text: new ol.style.Text({
								font: '12px Calibri,sans-serif',
								text: "hola",
								fill: textFill,
								stroke: textStroke,
								offsetX: 0,
								offsetY: 0
							}),
							fill: new ol.style.Fill({
								color: '#ffffff'
							})
						})];
				};
			})()
		});
		//Valida existencia de objeto map
		if (map === undefined || map === null) {
			//Crea nuevo mapa y almacena en variable
			map = new ol.Map({
				view: new ol.View({
					maxZoom: 18,
					minZoom: 5,
					extent: ol.proj.transformExtent([-68, -18.32, -82, 0.5], 'EPSG:4326', 'EPSG:900913')
				}),
				layers: [new ol.layer.Tile({source: new ol.source.OSM()})],
				renderer: 'canvas',
				target: document.getElementById(dashboardResource.MAP.incremental.id)
			});
		} else {
			//Remueve capa de mapa
			map.removeLayer(map.getLayers().a[1]);
		}
		//Agrega nueva capa a mapa
		map.addLayer(kmlLayer);
		//Establece un centro al mapa
		map.getView().setCenter(ol.proj.transform([-75.019515, -10.023393], 'EPSG:4326', 'EPSG:900913'));
		//Establece zoom inicial a mapa
		map.getView().setZoom(6);
    }

	//Inicia construccion de charts
	function initialize(globalView, urlKml, data){
		buildMap(globalView, urlKml, data);
	}

    return {
        initialize: initialize
    };
});
