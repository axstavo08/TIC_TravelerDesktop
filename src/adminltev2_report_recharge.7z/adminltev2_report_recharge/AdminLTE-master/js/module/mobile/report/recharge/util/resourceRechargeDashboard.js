/**
 * Project Name : smartflex-client
 * Created: 21/03/2018
 * @author Gustavo Ramos <C24363>
 */
define({
	'VIEW': {
		'TYPE': {
			'MAIN': "main",
			'DETAIL': "detail"
		}
	},
	'FILTERS': {
		'DATA': null,
		'SELECTED': null
	},
	'REQUEST': {
		'STATUS': {
			'SUCCESS': "success",
			'ERROR': "error",
			'NO_DATA': "no_data"
		},
		'TYPE': {
			'CHART': "chart",
			'DATA': "data"
		}
	},
	'UTIL': {
		'VIEW': {
			'name': "mainContent"
		},
		'FILTERS': {
			'ATTRIBUTE': {
				'1': 'networkRegions',
				'2': 'salesRegions',
				'3': 'departments'
			},
			'LAYERS': {
				'1': 'network',
				'2': 'sales',
				'3': 'general'
			},
			'LEVELS': {
				'NETWORK': 'network',
				'SALES': 'sales',
				'DEPARTMENT': 'general'
			},
			'CLASS': {
				'LABEL': ".filter-label",
				'COMPONENT': ".filter-component"
			},
			'BUTTON': {
				'name': "btnSearch"
			},
			'NAME': "filters"
		},
		'DEFAULT': {
			'SUB_GEO_LEVEL': "Sub Nivel"
		},
		'CALENDAR_MONTH': {
			'NAME': "calendarMonth"
		},
		'BAR': {
			'TYPE': {
				'NEGATIVE': "negative",
				'POSITIVE': "positive",
				'NONE': "none"
			},
			'STATUS': {
				'GOOD': {'name': 'good', 'color': 'rgb(0, 128, 0)', 'orientation': 'up'},
				'NOT_SO_GOOD': {'name': 'not-so-good', 'color': 'rgb(255, 204, 0)', 'orientation': 'up'},
				'NOT_SO_BAD': {'name': 'not-so-bad', 'color': 'rgb(230, 115, 0)', 'orientation': 'down'},
				'BAD': {'name': 'bad', 'color': 'rgb(255, 0, 0)', 'orientation': 'down'},
				'REPOSE': {'name': 'repose', 'color': 'rgb(137, 144, 139)', 'orientation': 'right'},
				'INCORRECT': {'name': 'incorrect', 'color': 'rgb(13, 13, 13)', 'orientation': 'alt'}
			},
			'TEMPLATE': "temp-incremental-bars",
			'ELEMENT': {
				'main': {
					'LABEL': "#labelBar-main",
					'COMPONENT': "#componentBar-main",
					'VALUE': "#valueBar-main"
				},
				'detail': {
					'LABEL': "#labelBar-detail",
					'COMPONENT': "#componentBar-detail",
					'VALUE': "#valueBar-detail"
				}
			}
		}
	},
    'CHART': {
		'incremental': {
            'name': "", 'id': "incrementalChart"
        }
    },
    'BAR': {
		'incremental': {
			'main': {
				'max': {
					'label': "barsMaxValue"
				},
				'min': {
					'label': "barsMinValue"
				},
				'container': "incrementalGeoDetail",
				'topTenHeader': "compTopTenHeader",
				'contBarModal': "contBtnIncrModalDet",
				'parentContainer': "divIncrementalGeoDetail",
				'parentContainerName': "nameLevel",
				'btnBarModal': "btnIncrModalDet"
			},
			'detail': {
				'max': {
					'label': "barsMaxValueDet"
				},
				'min': {
					'label': "barsMinValueDet"
				},
				'container': "incrementalGeoDetailModal",
				'groupParentContainer': {
					'first': "contFirstGroupBarModal",
					'second': "contSecondGroupBarModal"
				},
				'groupContainer': {
					'first': "firstGroupBarModal",
					'second': "secondGroupBarModal"
				},
				'modal': "incrementalModal"
			}
		}
    },
	'MAP': {
		'incremental': {
            'id': "incrementalMap"
        }
	},
    'MESSAGES': {
		'CONTAINER': {
			'parent': "contMessage",
			'main': "message"
		},
		'ANIMATION': {
			'HIDE': "hidden-effect",
			'SHOW': "show-effect"
		},
		'TYPE': {
			'LOAD': {
				'type': "info",
				'button': "hidden",
				'icon': "fa fa-spinner fa-spin",
				'content': "La carga de informaci\u00F3n se encuentra en proceso.",
				'class': "alert alert-info",
				'buttonDisplay': function(){
				   $.dataJS('message').find('button').addClass('hidden');
				}
			},
			'DANGER': {
				'type': "danger",
				'button': "",
				'icon': "icon fa fa-ban",
				'content': "La carga de informaci\u00F3n se complet\u00F3 con errores.",
				'class': "alert alert-danger",
				'buttonDisplay': function(){
				   $.dataJS('message').find('button').removeClass('hidden');
				}
			},
			'WARNING': {
				'type': "warning",
				'button': "",
				'icon': "icon fa fa-warning",
				'content': "La informaci\u00F3n no se carg\u00F3 correctamente.",
				'class': "alert alert-warning",
				'buttonDisplay': function(){
				   $.dataJS('message').find('button').removeClass('hidden');
				}
			},
			'SUCCESS': {
				'type': "success",
				'button': "hidden",
				'icon': "icon fa fa-check",
				'content': "La carga de informaci\u00F3n se complet\u00F3 correctamente.",
				'class': "alert alert-success",
				'buttonDisplay': function(){
				   $.dataJS('message').find('button').addClass('hidden');
				}
			}
		},
        'TEMPLATE': "temp-message"
    }
});
