/**
 * Project Name : smartflex-client
 * Created: 22/03/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

/**  Obtener kmls por nivel geografico
 *
 */
define(['jquery'], function($) {
	
	 //Inicializando variables con con url ws para obtener informacion
	 var WS_REGIONS_LAYERS_URI; 

     //Obtener objeto ajax de layers de departmento
     function getDepartmentLayers(filters) {
		//Completa url de ws de layers
		var WS_DEPARTMENT_LAYERS_URI = WS_REGIONS_LAYERS_URI.concat('/general');
		
		//Valida cantidad de parametros en filtros
		if(Object.keys(filters) > 0){
			WS_DEPARTMENT_LAYERS_URI = completeWSUriWithFilters(WS_DEPARTMENT_LAYERS_URI, filters);
		}
		
		return {
			'xhr': $.ajax({
			  url: WS_DEPARTMENT_LAYERS_URI,
			  type: "GET",
			  cache: true,
			  async: true
			}),
			'url': WS_DEPARTMENT_LAYERS_URI
		};
     }
	 
	 //Obtener objeto ajax de layers de region red
     function getNetworkRegionLayers(filters) {
		//Completa url de ws de layers
		var WS_NETWORK_REGION_LAYERS_URI = WS_REGIONS_LAYERS_URI.concat('/network');
		
		//Valida cantidad de parametros en filtros
		if(Object.keys(filters) > 0){
			WS_NETWORK_REGION_LAYERS_URI = completeWSUriWithFilters(WS_NETWORK_REGION_LAYERS_URI, filters);
		}
		
		return {
			'xhr': $.ajax({
			  url: WS_NETWORK_REGION_LAYERS_URI,
			  type: "GET",
			  cache: true,
			  async: true
			}),
			'url': WS_NETWORK_REGION_LAYERS_URI
		};
     }
	 
	 //Obtener objeto ajax de layers de region ventas
     function getSalesRegionLayers(filters) {
		//Completa url de ws de layers
		var WS_NETWORK_SALES_LAYERS_URI = WS_REGIONS_LAYERS_URI.concat('/sales');
		
		//Valida cantidad de parametros en filtros
		if(Object.keys(filters) > 0){
			WS_NETWORK_SALES_LAYERS_URI = completeWSUriWithFilters(WS_NETWORK_SALES_LAYERS_URI, filters);
		}
		console.log(WS_NETWORK_SALES_LAYERS_URI);
		
		return {
			'xhr': $.ajax({
			  url: WS_NETWORK_SALES_LAYERS_URI,
			  type: "GET",
			  cache: true,
			  async: true
			}),
			'url': WS_NETWORK_SALES_LAYERS_URI
		};
     }
	 
	 //Completa url con filtros
	 function completeWSUriWithFilters(wsUri, filters){
		var parameter, filter, counter = 0, quantityFilters = Object.keys(filters);
		
		 //Recorre filtros
		for(parameter in filters){
			//Valida numero de contador para agregar parametros a url
			if(counter === 0) {
				wsUri.concat("?");
			}
			//Obtiene parametro de filtro
			filter = filters[parameter];
			//Valida valor de filtro
			if(filter !== null){
				//Agrega parametro a url de ws
				wsUri.concat(parameter).concat("=").concat(filter);
				//Valida numero de contador con cantidad de parametros en filtros
				if(counter !== quantityFilters){
					wsUri.concat("&");
				}
			}
			//Aumenta contador
			counter++;
		}
		return wsUri;
	 }
	
	//Inicializa url de peticion a ws
	function initialize(wsUri){
		WS_REGIONS_LAYERS_URI = wsUri.concat("/regions");
	}

    return {
		initialize: initialize,
		getDepartmentLayers: getDepartmentLayers,
		getNetworkRegionLayers: getNetworkRegionLayers,
		getSalesRegionLayers: getSalesRegionLayers
    };
});
