/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 30/01/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */
define({
    'MESSAGES': {
        'S_PROCESSING': "Procesando...",
        'S_LENGTH_MENU': "Mostrar _MENU_ registros",
        'S_ZERO_RECORDS': "No se encontraron resultados",
        'S_EMPTY_TABLE': "Ning&uacute;n dato disponible en esta tabla",
        'S_INFO': "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
        'S_INFO_EMPTY': "Mostrando registros del 0 al 0 de un total de 0 registros",
        'S_INFO_FILTERED': "(filtrado de un total de _MAX_ registros)",
        'S_INFO_POST_FIX': "",
        'S_SEARCH': "Buscar:",
        'S_URL': "",
        'S_INFO_THOUSANDS': ",",
        'S_LOADING_RECORDS': "Cargando...",
        'O_PAGINATE': {
            'S_FIRST': "Primero",
            'S_LAST': "Último",
            'S_NEXT': "Siguiente",
            'S_PREVIOUS': "Anterior"
        },
        'O_ARIA': {
            'S_SORT_ASCENDING': ": Activar para ordenar la columna de manera ascendente",
            'S_SORT_DESCENDING': ": Activar para ordenar la columna de manera descendente"
        },
        'O_SELECT': {
            'ROWS': "%d filas seleccionadas"
        }
    },
    'BUTTONS': {
        'COPY': "COPY",
        'EXCEL': "EXCEL",
        'CSV': "CSV",
        'PIE_CHART': "PIE_CHART"
    },
    'DOM': {
        'BFRTIP': "Bfrtip"
    },
    'CLASS': {
        'TEXT_CENTER': "text-center"
    },
    'CHECKBOX': {
        'STRUCTURE': '<div class="checkbox"><input type="checkbox" class="dt-checkboxes"><label></label></div>'
    },
    'SELECT': {
        'TYPE': {
            'MULTI': 'multi'
        } 
    }
});

