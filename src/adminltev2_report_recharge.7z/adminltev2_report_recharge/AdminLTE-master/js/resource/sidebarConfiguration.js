/**
 * Project Name : smartflex-client 
 * Created: 06/03/2018
 * @author Gustavo Ramos <C24363>
 */
define({
    'ROOT_MENU': "root_menu",
    'COMPONENT_CHILDREN': "ul, li",
    'COMPONENT_ACTIVE': "ul.active, li.active",
    'PREFIX_ROOT_MODULE': "sd",
    'COMPONENT_MODULE': "_{{component}}",
    'CLASS_ACTIVE': "active",
    'CLASS_TREEVIEW': "treeview",
    'CLASS_MENU_OPEN': "menu-open",
    'HIERARCHY': {
        'root': null,
        'main': null,
        'sub_main': null,
        'section': null,
        'sub_section': null
    }
});

