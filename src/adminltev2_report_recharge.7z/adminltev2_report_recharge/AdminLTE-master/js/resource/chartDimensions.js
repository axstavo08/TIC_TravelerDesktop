/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 18/01/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */
define({
    'VIEW': {
        'MAIN': {
            'SOURCE': {
                'WIDTH': 1200, 'HEIGHT': 400
            }
        },
        'SOLID_CAUGE': {
            'SOURCE': {
                'WIDTH': 400, 'HEIGHT': 400
            }
        },
        'PIE': {
            'SOURCE': {
                'WIDTH': 800, 'HEIGHT': 400
            }
        }
    },
    'RESPONSIVE': {
        'CONDITION': {
            'MAX': {
                'WIDTH': 480
            }
        }
    }
});

