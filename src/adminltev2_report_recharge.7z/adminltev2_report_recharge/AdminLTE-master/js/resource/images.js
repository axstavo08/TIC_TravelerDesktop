/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 02/04/2017
 * @author John Portella <C16915>
 * @version 1.0
 */
define({
    'IMG_LOAD': '/smartflex/template/adminLTE/img/ajax-loader.gif',
    'IMG_ERROR': '/smartflex/template/adminLTE/img/error.png',
    'IMG_SUCCESS': '/smartflex/template/adminLTE/img/success.png',
    'IMG_CLARO_LOGO': '/smartflex/images/coverage/logo-claro.png',
    'IMG_ENTEL_LOGO': '/smartflex/images/coverage/logo-entel.png',
    'IMG_MOVISTAR_LOGO': '/smartflex/images/coverage/logo-movistar.png',
    'IMG_BITEL_LOGO': '/smartflex/images/coverage/logo-bitel.png',
    'IMG_MARKER_RADIO_TOWER': '/smartflex/images/radio-tower.png',
    'IMG_MARKER_POINT': '/smartflex/images/marker.png'
});