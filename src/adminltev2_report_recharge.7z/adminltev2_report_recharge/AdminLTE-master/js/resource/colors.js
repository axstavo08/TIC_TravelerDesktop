/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 04/05/2017
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

define({
    'COVERAGE': {
        'MOBILE': {
            'INIT': {
                'VILLAGES': {
                    'RED': "#e60000"
                },
                'POPULATION': {
                    'BLUE': "#346da4"
                },
                'WITH_COVERAGE': {
                    'RED': "#e60000"
                },
                'WITHOUT_COVERAGE': {
                    'BLUE': "#264d73"
                }
            },
            'SEARCHER': {
                'WITH_COVERAGE': {
                    'RED': "#e60000"
                },
                'WITHOUT_COVERAGE': {
                    'BLUE': "#264d73"
                }
            },
            'VENDOR': {
                'VILLAGES': {
                    'BITEL': {
                        'YELLOW': "#ffcc00"
                    },
                    'CLARO': {
                        'RED': "#e60000"
                    },
                    'ENTEL': {
                        'BLUE': "#0059b3"
                    },
                    'MOVISTAR': {
                        'GREEN': "#009933"
                    }
                },
                'POPULATION': {
                    'BITEL': {
                        'YELLOW': "#cca300"
                    },
                    'CLARO': {
                        'RED': "#b30000"
                    },
                    'ENTEL': {
                        'BLUE': "#0073e6"
                    },
                    'MOVISTAR': {
                        'GREEN': "#00cc44"
                    }
                }
            }
        }
    },
    'CRITICAL_SEGMENT': {
        'USERS_SCORE_PRIORITY': {
            '00': {
                'RED': "rgba(179, 0, 0, 0.5)"
            },
            '0': {
                'ORANGE': "rgba(204, 82, 0, 0.5)"
            },
            '1': {
                'YELLOW': "rgba(230, 138, 0, 0.5)"
            },
            '2': {
                'BLUE': "rgba(0, 89, 179, 0.5)"
            },
            '3': {
                'TURQUOISE': "rgba(0, 128, 128, 0.5)"
            },
            'SOLO_KQI': {
                'GREEN': "rgba(45, 134, 45, 0.5)"
            }
        },
        'PRIORITY': {
            '00': {
                'RED': "#b30000"
            },
            '0': {
                'ORANGE': "#cc5200"
            },
            '1': {
                'YELLOW': "#e68a00"
            },
            '2': {
                'BLUE': "#0059b3"
            },
            '3': {
                'TURQUOISE': "#008080"
            },
            'SOLO_KQI': {
                'GREEN': "#2d862d"
            }
        },
        'RESPONSIBLE_PLANIFICATION': {
            'PLANIFICATION': {
                'ORANGE': "#cc3300"
            },
            'PLANIFICATION_FAR_TRAFFIC': {
                'BLUE': "#0059b3"
            }
        },
        'RESPONSIBLE_OPTIMIZATION': {
            'OPTIMIZATION': {
                'GREEN': "#264d00"
            },
            'OPTIMIZATION_FEW_TRAFFIC': {
                'BLUE': "#006699"
            },
            'OPTIMIZATION_RURAL': {
                'ORANGE': "#cc7a00"
            },
            'OPTIMIZATION_FAR_TRAFFIC': {
                'RED': "#990000"
            }
        }
    },
    'CHARTS_COMPONENTS': {
        'Y_AXIS': {
            'STACK_LABELS': {
                'WHITE_SMOKE': "#f2f2f2"
            },
            'STOPS': {
                'RED': "#DF5353", 'YELLOW': "#DDDF0D", 'GREEN': "#55BF3B"
            }
        },
        'TOOLTIP': {
            'MANY_SERIES': {
                'BACKGROUND_COLOR': {
                    'WHITE': "rgba(255,255,255,0)"
                }
            }
        },
        'SERIE': {
            'DATA_LABELS': {
                'SOLID_CAUGE': {
                    'VALUE': "#000000",
                    'SUFFIX': "#c0c0c0"
                }
            }
        },
        'PANE': {
            'BACKGROUND_COLOR': {
                'LIGHT_GRAY': "#eeeeee"
            }
        },
        'EXPORTING': {
            'CHART': {
                'TEXT': {
                    'BRICK': "#cc3300"
                }
            },
            'CREDITS': {
                'TEXT': {
                    'RED': "#b30000"
                }
            }
        }
    },
	'BAR': {
		'WHITE_SMOKE': "#eeeeee"
	}
});
