/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 18/01/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */
define({
    'PROJECT': {
        'NAME': "SMARTFLEX",
        'LABEL': "Smartflex"
    },
    'VIEW': {
        'MAIN': "MAIN",
        'DETAIL': "DETAIL",
        'SOLID_CAUGE': "SOLID_CAUGE",
        'PIE': "PIE"
    },
    'CHART': {
        'NO_DATA': "No Data"
    },
    'VENDORS': {
        'CLARO': "CLARO",
        'MOVISTAR': "MOVISTAR",
        'ENTEL': "ENTEL",
        'BITEL': "BITEL"
    },
    'COVERAGE': {
        'VILLAGES': "Centros Poblados",
        'POPULATION': "Habitantes",
        'WITH_COVERAGE': "Con Cobertura",
        'WITHOUT_COVERAGE': "Sin Cobertura"
    },
    'CRITICAL_SEGMENT': {
        'PRIORITY': {
            '00': "00",
            '0': "0",
            '1': "1",
            '2': "2",
            '3': "3",
            'SOLO_KQI': "SOLO KQI"
        },
        'RESPONSIBLE_PLANIFICATION': {
            'PLANIFICATION': "PLANIFICACION",
            'PLANIFICATION_FAR_TRAFFIC': "PLANIF TRAFICO LEJ"
        },
        'RESPONSIBLE_OPTIMIZATION': {
            'OPTIMIZATION': "OPTIMIZACION",
            'OPTIMIZATION_FEW_TRAFFIC': "OPTI POCO TRAFICO",
            'OPTIMIZATION_RURAL': "OPTI RURAL",
            'OPTIMIZATION_FAR_TRAFFIC': "OPTI TRAFICO LEJ"
        }
    }
});
