/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 30/01/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */
define({
    'COPY': {
        'EXTEND': 'copyHtml5',
        'TEXT': '<i class="fa fa-files-o"></i>'
    },
    'EXCEL': {
        'EXTEND': 'excelHtml5',
        'TEXT': '<i class="fa fa-file-excel-o"></i>'
    },
    'CSV': {
        'EXTEND': 'csvHtml5',
        'TEXT': '<i class="fa fa-file-text-o"></i>'
    },
    'PIE_CHART': {
        'TEXT': '<i class="fa fa-pie-chart"></i>'
    }
});
