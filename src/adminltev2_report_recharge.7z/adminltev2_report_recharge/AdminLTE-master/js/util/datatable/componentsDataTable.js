/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 19/01/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */
define(['jquery', 'datatable-configuration'], function($, configDataTable) {

    //Declaracion de variables
    var mDTLanguage, mDTResetAllFilters, mBuildColumnDatatable;

    /*Construccion de mensajes para componentes de datatable*/
    mDTLanguage = function() {
        var oLanguage = {}, aPaginate = {}, aAria = {}, aSelect = {};
        //Construye objeto language
        oLanguage['sProcessing'] = configDataTable['MESSAGES']['S_PROCESSING'];
        oLanguage['sLengthMenu'] = configDataTable['MESSAGES']['S_LENGTH_MENU'];
        oLanguage['sZeroRecords'] = configDataTable['MESSAGES']['S_ZERO_RECORDS'];
        oLanguage['sEmptyTable'] = configDataTable['MESSAGES']['S_EMPTY_TABLE'];
        oLanguage['sInfo'] = configDataTable['MESSAGES']['S_INFO'];
        oLanguage['sInfoEmpty'] = configDataTable['MESSAGES']['S_INFO_EMPTY'];
        oLanguage['sInfoFiltered'] = configDataTable['MESSAGES']['S_INFO_FILTERED'];
        oLanguage['sInfoPostFix'] = configDataTable['MESSAGES']['S_INFO_POST_FIX'];
        oLanguage['sSearch'] = configDataTable['MESSAGES']['S_SEARCH'];
        oLanguage['sUrl'] = configDataTable['MESSAGES']['S_URL'];
        oLanguage['sInfoThousands'] = configDataTable['MESSAGES']['S_INFO_THOUSANDS'];
        oLanguage['sLoadingRecords'] = configDataTable['MESSAGES']['S_LOADING_RECORDS'];
        aPaginate['sFirst'] = configDataTable['MESSAGES']['O_PAGINATE']['S_FIRST'];
        aPaginate['sLast'] = configDataTable['MESSAGES']['O_PAGINATE']['S_LAST'];
        aPaginate['sNext'] = configDataTable['MESSAGES']['O_PAGINATE']['S_NEXT'];
        aPaginate['sPrevious'] = configDataTable['MESSAGES']['O_PAGINATE']['S_PREVIOUS'];
        oLanguage['oPaginate'] = aPaginate;
        aAria['sSortAscening'] = configDataTable['MESSAGES']['O_ARIA']['S_SORT_ASCENDING'];
        aAria['sSortDescending'] = configDataTable['MESSAGES']['O_ARIA']['S_SORT_DESCENDING'];
        oLanguage['oAria'] = aAria;
        aSelect['rows'] = configDataTable['MESSAGES']['O_SELECT']['ROWS'];
        oLanguage['select'] = aSelect;
        return oLanguage;
    };

    /*Construye metodo para reiniciar filtros de datatable*/
    mDTResetAllFilters = function() {
        $.fn.dataTableExt.oApi.fnResetAllFilters = function(oSettings, bDraw/*default true*/) {
            for (iCol = 0; iCol < oSettings.aoPreSearchCols.length; iCol++) {
                oSettings.aoPreSearchCols[ iCol ].sSearch = '';
            }
            oSettings.oPreviousSearch.sSearch = '';

            if (typeof bDraw === 'undefined')
                bDraw = true;
            if (bDraw)
                this.fnDraw();
        };
    };

    /*Construye objeto columna*/
    mBuildColumnDatatable = function(dName, className, title) {
        var column = {};
        //Construye objeto columna
        column['data'] = dName;
        //Valida si variable existe para atributo nombre de clase
        if (typeof className !== 'undefined' && className !== null) {
            column['className'] = className;
        }
        //Valida si variable existe para atributo titulo
        if (typeof title !== 'undefined' && title !== null) {
            column['title'] = title;
        }
        return column;
    };

    //Retorno de metodos publicos
    return {
        language: mDTLanguage,
        addResetAllFilters: mDTResetAllFilters,
        buildColumn: mBuildColumnDatatable
    };
});
