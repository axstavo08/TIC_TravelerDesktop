/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client
 * Created: 19/01/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */
define([], function() {

    function Legend(tFormatterChart, widthChart) {
        var legend = {};

        //Valida existencia de objeto Legend
        if (!(this instanceof Legend)) {
            throw new TypeError("Legend constructor cannot be called as a function.");
        }
        //Construye objeto legend
        function build() {
            //Valida formatter
            if (typeof tFormatterChart !== 'undefined' && tFormatterChart !== null) {
                if (typeof widthChart !== 'undefined') {
                    legend['width'] = buildWidthLegendByFormatter(tFormatterChart, widthChart);
                    legend['itemWidth'] = buildItemWidthLegendByFormatter(tFormatterChart, widthChart);
                }
                legend['enabled'] = disableLegend(tFormatterChart);
            }
        }

        //Construye propiedad width para legenda por tipo de formato de chart
        function buildWidthLegendByFormatter(formatter, width) {
            var lWidth;
            if (formatter.indexOf("two_cols") !== -1) {
                lWidth = width;
            } else {
                lWidth = width - '10%';
            }
            return lWidth;
        }

        //Construye propiedad itemWidth para legenda por tipo de formato de chart
        function buildItemWidthLegendByFormatter(formatter, width) {
            var lItemWidth;
            if (formatter.indexOf("two_cols") !== -1) {
                lItemWidth = width / 2;
            } else {
                lItemWidth = width - '10%';
            }
            return lItemWidth;
        }

		//Deshabilita legend por tipo de formato de chart
		function disableLegend(formatter){
			if(formatter === 'recharge_dashboard'){
				return false;
			}
			return true;
		}

        //Metodo de objeto que construye objeto legend
        this.buildAndGet = function() {
            //Llama a metodo para construir legend
            build();
            return legend;
        };

        //Metodo para mostrar en consola propiedades de construidas de legend
        this.toString = function() {
            console.log("legend - object property");
            console.log(legend);
        };
    }

    return Legend;
});
