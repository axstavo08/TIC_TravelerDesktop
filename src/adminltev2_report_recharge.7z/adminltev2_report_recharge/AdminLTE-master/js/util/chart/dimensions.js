/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 22/01/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */
define(['jquery'], function($) {

    //Declaracion de variables
    var mChartWidth;

    //Devuelve ancho de chart
    mChartWidth = function(id, formatter) {
        var element = $('#'.concat(id)), width;
        if (formatter === "vas_tab_legend_two_cols_not_axis") {
            width = getWidthRiseParentsByElement(element, 2);
        } else if (formatter === "vas_main_legend_two_cols") {
            width = getWidthByElement(element);
        } else if (formatter === "vas_legend_two_cols_not_axis") {
            width = getWidthRiseParentsByElement(element, 1);
        } else if (formatter === "vas_pie_main_tab_legend") {
            width = getWidthRiseParentsByElement(element, 2);
        } else if (formatter === "vas_pie_det_tab_legend_two_cols") {
            width = getWidthRiseParentsByElement(element, 3);
        } else if (formatter === "vas_pie_legend_two_cols") {
            width = getWidthByElement(element);
        }
        return width;
    };

    //Obtiene medida ancho de elemento
    function getWidthByElement(element) {
        return element.width();
    }

    //Obtiene medida ancho de elemento buscando dos niveles arriba
    function getWidthRiseParentsByElement(element, levels) {
        var width, parent;
        //Obtiene padre
        parent = getParentByLevelNumber(element, levels);
        //Valida que padre esta activo
        if (!parent.hasClass('active')) {
            getWidthByParentAndElement(element, parent);
        } else {
            width = getWidthByElement(element);
        }
        return width;
    }

    //Obtiene elemento padre subiendo por numero establecido como parametro
    function getParentByLevelNumber(element, levels) {
        var parent, loop;
        for (loop = 0; loop < levels; loop++) {
            parent = element.parent();
        }
        return parent;
    }

    //Obtiene ancho de elemento descubriendo al padre
    function getWidthByParentAndElement(element, parent) {
        var width;
        parent.addClass('active');
        width = getWidthByElement(element);
        parent.removeClass('active');
        return width;
    }

    //Retorno de metodos publicos
    return {
        chartWidth: mChartWidth
    };
});