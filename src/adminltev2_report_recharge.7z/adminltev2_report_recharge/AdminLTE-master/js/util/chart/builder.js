/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 18/01/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */
define([
    'jquery', 'chart-labels', 'chart/components', 'chart/typeChart', 'chart/dimensions', 'chart/xAxis', 'chart/yAxis',
    'chart/tooltip', 'chart/series', 'chart/plotOptions', 'chart/legend', 'chart/exporting', 'chart/responsive'
], function($, cLabels, components, typeChart, dimensions, XAxis, YAxis,
        Tooltip, Serie, PlotOptions, Legend, Exporting, Responsive) {

    //Declaracion de variables globales de retorno
    var mChartProperties;

    //Construye chartOptions
    mChartProperties = function(data, id) {
        var oChartProperties = {}, tChart, tView, dChartWidth;
        //Obtiene tipo de chart
        tChart = getTypeChart(data['_type']);
        dChartWidth = dimensions.chartWidth(id, data['_formatter']);
        //Obtiene tipo de vista
        tView = getTypeView(tChart);
        //Construye chartObject
        oChartProperties['chartOptions'] = buildChartOptions(tChart, tView, data, id, dChartWidth);
        oChartProperties['hasData'] = validateHasData(tChart, data['series']);
        oChartProperties['hasNotNullableValue'] = validateNullableData(tChart, data['series']);
        oChartProperties['substrTitle'] = getSubstrTitleByTypeFormatter(data['_title'], data['_formatter']);
        return oChartProperties;
    };

    //Construye chartOptions
    function buildChartOptions(type, view, data, id, chartWidth) {
        var oChartOptions = {}, formatter = data['_formatter'], oYAxis, hasPropStack;
        //Valida tipo de chart y construye chartOptions
        switch (type) {
            case typeChart['LINE']:
            case typeChart['AREA']:
            case typeChart['COLUMN']:
            case typeChart['BAR']:
            case typeChart['SCATTER_PLOT']:
            case typeChart['SOLID_GAUGE']:
            default:
                oYAxis = getListYAxis(data['_yAxis'], formatter, id);
                oChartOptions['yAxis'] = oYAxis['listYAxis'];
                hasPropStack = oYAxis['hasPropStack'];
                if (type !== typeChart['SOLID_GAUGE']) {
                    oChartOptions['xAxis'] = getXAxis(data['xAxis'], formatter);
                } else {
                    oChartOptions['pane'] = components.pane(data['pane']);
                }
                break;
            case typeChart['PIE']:
                break;
        }
        //Construye objeto chartOptions
        oChartOptions['chart'] = components.chart(type, data['zoomType']);
        oChartOptions['credits'] = components.credits();
        oChartOptions['title'] = components.title(data['_title']);
        oChartOptions['subtitle'] = components.title(data['_subtitle']);
        oChartOptions['tooltip'] = getTooltip(data['tooltip'], formatter, data['series'].length, data['xAxis']);
        oChartOptions['series'] = getListSeries(data['series'], formatter, data['xAxis'], id);
        oChartOptions['plotOptions'] = getPlotOptions(type, hasPropStack, formatter, data['xAxis'], data['_yAxis']);
        oChartOptions['exporting'] = getExporting(data['_exportConfig'], view, type, getAuxiliarNameExportingByTypeFormatter(data));
        oChartOptions['legend'] = getLegend(formatter, chartWidth);
        oChartOptions['responsive'] = getResponsive(formatter, chartWidth);
        oChartOptions['noData'] = components.noData(formatter);
        return oChartOptions;
    }

    //Valida data por cantidad de series o cantidad de data en serie (especial caso para pie chart)
    function validateHasData(tChart, dataSeries) {
        var vHasData = false;
        if (tChart !== typeChart['PIE']) {
            //Valida cantidad de series
            if (dataSeries.length > 0) {
                //Cambia variable de existencia de data a true
                vHasData = true;
            }
        } else {
            //Valida cantidad de series
            if (dataSeries[0]['data'].length > 0) {
                //Cambia variable de existencia de data a true
                vHasData = true;
            }
        }
        return vHasData;
    }

    //Valida data por cantidad de valores nulos por tipo de chart
    function validateNullableData(tChart, dataSeries) {
        var hasValues, iSerie, vSerie, iDataSerie, vDataSerie;
        //Valida tipo de chart
        if (tChart === typeChart['PIE']) {
            hasValues = false;
            //Iniciando recorrido de series
            for (iSerie in dataSeries) {
                //Asignando el valor de serie por recorrido
                vSerie = dataSeries[iSerie];
                //Iniciando recorrido de la lista de data de cada serie
                for (iDataSerie in vSerie['data']) {
                    //Asignando a variable el objeto data de la lista de data de la serie por recorrido
                    vDataSerie = vSerie['data'][iDataSerie];
                    //Validando si hay un valor en cada data de la lista 
                    if (vDataSerie['y'] !== null && !hasValues) {
                        hasValues = true;
                    }
                }
            }
        } else {
            hasValues = true;
        }
        return hasValues;
    }

    //Obtiene caracteres de titulo para acciones por tipo de formatter
    function getSubstrTitleByTypeFormatter(dTitle, tFormatter) {
        var substr;
        //Valida tipo de formatter
        if (typeof tFormatter !== 'undefined' && tFormatter !== null) {
            if (tFormatter === "critseg_initresp") {
                //Asigna a variable los dos ultimos caracteres de titulo
                substr = dTitle.slice(-2);
            }
        }
        return substr;
    }

    //Obtiene nombre auxiliar para exportación por tipo de formatter
    function getAuxiliarNameExportingByTypeFormatter(data) {
        var name, formatter = data['_formatter'];
        //Valida existencia de data de exporting
        if (data['_exportConfig'] !== null) {
            //valida tipo de vista de data de objeto exporting
            switch (data['_exportConfig']['view']) {
                case cLabels['VIEW']['MAIN']:
                default:
                    //para graficas solidcauge, obtener el titulo --> data['_yAxis'][0]['_title']
                    break;
                case cLabels['VIEW']['DETAIL']:
                    if (formatter !== null) {
                        //Valida tipo de formatter
                        if (formatter.indexOf("vas") !== -1) {
                            name = $.dataJS("titlePlatformDetail").text();
                        }
                    }
                    break;
            }
        }
        return name;
    }

    //Obtiene tipo de chart
    function getTypeChart(tChart) {
        var type;
        //Valida existencia de tipo de chart
        type = (tChart === null) ? typeChart['DEFAULT'] : tChart;
        return type;
    }

    //Obtiene tipo de chart
    function getTypeView(tChart) {
        var type;
        switch (tChart) {
            case typeChart['SOLID_GAUGE']:
                type = cLabels['VIEW']['SOLID_CAUGE'];
                break;
            case typeChart['PIE']:
                type = cLabels['VIEW']['PIE'];
                break;
            default:
                type = cLabels['VIEW']['MAIN'];
                break;
        }
        return type;
    }

    //Obtiene xAxis de objeto XAxis
    function getXAxis(dataXAxis, formatterChart) {
        var oXAxis, cXAxis;
        //Instancia objeto XAxis
        oXAxis = new XAxis(dataXAxis, formatterChart);
        //Construye xAxis y obtiene
        cXAxis = oXAxis.buildAndGet();
        //Muestra en consola xAxis construido
        //oXAxis.toString();
        return cXAxis;
    }

    //Obtiene listado de yAxis de objeto YAxis
    function getListYAxis(dataYAxis, formatterChart, id) {
        var cYAxis;
        //Llama a metodo de objeto YAxis para construir listado de yAxis
        cYAxis = YAxis.buildListYAxis(dataYAxis, formatterChart, id);
        //Muestra en consola listado de yAxis construido
        //YAxis.toString(id);
        return cYAxis;
    }

    //Obtiene tooltip de objeto Tooltip
    function getTooltip(dataTooltip, formatterChart, quantitySeries, dXAxis) {
        var oTooltip, cTooltip, existXAxis;
        //Valida existencia de data de objeto xAxis
        existXAxis = (dXAxis !== null) ? true : false;
        //Instancia objeto Tooltip
        oTooltip = new Tooltip(dataTooltip, formatterChart, quantitySeries, existXAxis);
        //Construye tooltip y obtiene
        cTooltip = oTooltip.buildAndGet();
        //Muestra en consola tooltip construido
        //oTooltip.toString();
        return cTooltip;
    }

    //Obtiene listado de serie de objeto Serie
    function getListSeries(dataSeries, formatterChart, dataXAxis, id) {
        var cSeries, dataXAxisCategories = [];
        //Valida existencia de data de xAxis para obtener categories
        if (typeof dataXAxis !== 'undefined' && dataXAxis !== null) {
            dataXAxisCategories = dataXAxis['categories'];
        }
        //Llama a metodo de objeto Serie para construir listtado de serie
        cSeries = Serie.buildListSeries(dataSeries, formatterChart, dataXAxisCategories, id);
        //Muestra en consola listado de serie construido
        //Serie.toString(id);
        return cSeries;
    }

    //Obtiene series de objeto PlotOptions
    function getPlotOptions(type, hasPropStackYAxis, formatterChart, dataXAxis, dataYAxis) {
        var oPlotOptions, cPlotOptions, titleXAxis, titleYAxis;
        //Valida existencia de data de xAxis para obtener categories
        if (typeof dataXAxis !== 'undefined' && dataXAxis !== null) {
            titleXAxis = dataXAxis['_title'];
        }
        //Valida cantidad de elementos en yAxis para obtener titulo
        if (typeof dataYAxis !== 'undefined') {
            if (dataYAxis.length > 0) {
                titleYAxis = dataYAxis[0]['_title'];
            }
        }
        //Instancia objeto PlotOptions
        oPlotOptions = new PlotOptions(type, hasPropStackYAxis, formatterChart, titleXAxis, titleYAxis);
        //Construye plotOptions y obtiene
        cPlotOptions = oPlotOptions.buildAndGet();
        //Muestra en consola plotOptions construido
        //oPlotOptions.toString();
        return cPlotOptions;
    }

    //Obtiene series de objeto Exporting
    function getExporting(dataExporting, tView, tChart, auxNameExport) {
        var oExporting, cExporting;
        //Instancia objeto Exporting
        oExporting = new Exporting(dataExporting, tView, tChart, auxNameExport);
        //Construye exporting y obtiene
        cExporting = oExporting.buildAndGet();
        //Muestra en consola exporting construido
        //oExporting.toString();
        return cExporting;
    }

    //Obtiene legend de objeto Legend
    function getLegend(formatterChart, chartWidth) {
        var oLegend, cLegend;
        //Instancia objeto legend
        oLegend = new Legend(formatterChart, chartWidth);
        //Construye legend y obtiene
        cLegend = oLegend.buildAndGet();
        //Muestra en consola legend construido
        //oLegend.toString();
        return cLegend;
    }

    //Obtiene responsive de objeto Responsive
    function getResponsive(formatterChart, chartWidth) {
        var oResponsive, cResponsive;
        //Instancia objeto responsive
        oResponsive = new Responsive(chartWidth, formatterChart);
        //Construye responsive y obtiene
        cResponsive = oResponsive.buildAndGet();
        //Muestra en consola responsive construido
        //oResponsive.toString();
        return cResponsive;
    }

    //Retorno de metodos publicos
    return {
        properties: mChartProperties
    };
});
