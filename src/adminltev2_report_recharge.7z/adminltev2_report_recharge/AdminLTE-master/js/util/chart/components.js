/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 19/01/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */
define(['global-colors', 'chart-labels'], function(gColors, cLabels) {

    //Declaracion de variables
    var mChart, mCredits, mTitle, mSubtitle, mPane, mNoData;

    /*Construccion de objeto chart*/
    mChart = function(tChart, tZoom) {
        var oChart = {};
        //Construye objeto chart
        oChart['type'] = tChart;
        oChart['reflow'] = true;
        //Valida existencia de zoom
        if (typeof tZoom !== 'undefined' && tZoom !== null) {
            oChart['zoomType'] = tZoom;
        }
        return oChart;
    };

    /*Construccion de objeto credits*/
    mCredits = function() {
        var oCredits = {};
        //Construye objeto credits
        oCredits['enabled'] = false;
        oCredits['text'] = cLabels['PROJECT']['LABEL'];
        return oCredits;
    };

    /*Construccion de objeto title*/
    mTitle = function(nTitle) {
        var oTitle = {};
        //Construye objeto title
        oTitle['text'] = nTitle;
        return oTitle;
    };

    /*Construccion de objeto subtitle*/
    mSubtitle = function(nSubtitle) {
        var oSubtitle = {};
        //Construye objeto subtitle
        oSubtitle['text'] = nSubtitle;
        return oSubtitle;
    };

    /*Construccion de objeto pane*/
    mPane = function(dPane) {
        var oPane = {};
        //Valida existencia de data pane
        if (dPane !== null) {
            //Construye objeto pane diectamente de data
            oPane = dPane;
            //Asignando atributos de configuracion para tipo de formatter
            oPane['center'] = ['50%', '70%'];
            //Asigna un color al background
            oPane['background']['backgroundColor'] = gColors['CHARTS_COMPONENTS']['PANE']['BACKGROUND_COLOR']['LIGHT_GRAY'];
        }
        return oPane;
    };

    /*Construccion de objeto noData*/
    mNoData = function(tFormatter) {
        var oNoData = {}, pPosition = {};
        //Valida formatter
        if (typeof tFormatter !== 'undefined' && tFormatter !== null) {
            if (tFormatter.indexOf("solidGauge_arc") !== -1) {
                //Construye objeto noData
                oNoData['useHTML'] = true;
                pPosition['y'] = 25;
                oNoData['position'] = pPosition;
            }
        }
        return oNoData;
    };

    //Retorno de metodos publicos
    return {
        chart: mChart,
        credits: mCredits,
        title: mTitle,
        subtitle: mSubtitle,
        pane: mPane,
        noData: mNoData
    };
});
