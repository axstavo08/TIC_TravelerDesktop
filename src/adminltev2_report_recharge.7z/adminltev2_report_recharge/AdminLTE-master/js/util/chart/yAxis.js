/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 19/01/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */
define(['global-colors'], function(gColors) {

    //Variables de clase para contener valores globales de todas las graficas
    var gListYAxis = {}, gHasPropStackYAxis = {};

    function YAxis(dYAxis, formatter) {
        var yAxis = {}, hasPropStack;

        //Valida existencia de objeto YAxis
        if (!(this instanceof YAxis)) {
            throw new TypeError("YAxis constructor cannot be called as a function.");
        }

        //Construye objeto yAxis
        function build() {
            //Declaracion de variables para construccion de atributo yAxis
            var pTitle = {}, pLabels = {}, pStackLabels = {}, dStackLabels = dYAxis['_stackLabels'];
            //Valida si nodo stackLabels existe
            if (typeof dStackLabels !== 'undefined') {
                //Valida que tenga valor atributo stackLabels
                if (dStackLabels === null) {
                    //Asigna valor para desactivar funcion de stackLabels para objeto yAxis
                    pStackLabels['enabled'] = false;
                    //Asigna variable para validar que no tiene propiedad stack
                    hasPropStack = false;
                } else {
                    //Asigna valor para activar funcion de stackLabels para objeto yAxis
                    pStackLabels['enabled'] = true;
                    //Valida que atributo stackLabels tenga formatter
                    if (typeof dStackLabels['_hasFormatter'] !== 'undefined' && dStackLabels['_hasFormatter'] !== null) {
                        if (dStackLabels['_hasFormatter']) {
                            //Agrega propiedades a objeto stackLabels para objeto YAxis
                            pStackLabels = buildPropertyStackLabelsForYAxis(dStackLabels, pStackLabels);
                        }
                    }
                    //Asigna variable para validar que tiene propiedad stack
                    hasPropStack = true;
                }
            }
            //Construccion de objeto titulo para yAxis
            pTitle['text'] = dYAxis._title;
            //Construccion de objeto labels para yAxis
            pLabels['format'] = dYAxis._format;
            //Construye objeto yAxis con estructura de sus atributos
            yAxis['max'] = dYAxis['max'];
            yAxis['min'] = dYAxis['min'];
            yAxis['opposite'] = dYAxis['opposite'];
            yAxis['title'] = pTitle;
            yAxis['labels'] = pLabels;
            yAxis['stackLabels'] = pStackLabels;
            //Valida que formatter de chart exista
            if (typeof formatter !== 'undefined' && formatter !== null) {
                yAxis = buildAttributesForObjectYAxisByChartFormmater(yAxis, formatter);
            }
        }

        //Construye propiedad StackLabels para YAxis
        function buildPropertyStackLabelsForYAxis(nStackLabels, pStackLabelsYAxis) {
            var vFormatterSuffix = '', vDefaultStackSerie = 0, vStyle = {};
            //Valida que nodo StackLabels tenga tipo de formatter
            if (nStackLabels['_formatterType'] !== null) {
                //Valida que nodo StackLabels tenga tipo de formatter por condicion
                if (nStackLabels['_formatterType'] === 'percentage') {
                    //Asigna valor a variable para almacenar sufijo para propiedad formatter
                    vFormatterSuffix = " %";
                }
            }
            //Valida que nodo StackLabels tenga opciones de formatter
            if (nStackLabels['_formatterOptions'] !== null) {
                //Asigna valor a variable para almacenar serie que mostrará propiedad StackLabels
                vDefaultStackSerie = nStackLabels['_formatterOptions']['serieId'];
            }
            //Construye estilos para StackLabels
            vStyle['color'] = gColors['CHARTS_COMPONENTS']['Y_AXIS']['STACK_LABELS']['WHITE_SMOKE'];
            //Construye objeto StackLabels para YAxis
            pStackLabelsYAxis['formatter'] = function() {
                //Retorna valor de YAxis de posicion de serie (definido como parametro) y sufijo de formatter (definido como parametro)
                return (this.axis.series[vDefaultStackSerie].yData[this['x']]).toFixed(2).concat(vFormatterSuffix);
            };
            pStackLabelsYAxis['align'] = 'left';
            pStackLabelsYAxis['style'] = vStyle;
            return pStackLabelsYAxis;
        }

        //Construye atributos para objeto yAxis por formato de chart
        function buildAttributesForObjectYAxisByChartFormmater(oYAxis, formatter) {
            var aStops = [];
            //Valida formatter
            if (formatter === 'coverage_percentage_quantity') {
                //Adicion de nuevos atributos a objeto yAxis
                oYAxis['reversedStacks'] = false;
            } else if (formatter.indexOf('solidGauge_arc') !== -1) {
                //Adicion de nuevos atributos a objeto yAxis
                oYAxis['reversedStacks'] = false;
                aStops.push([0.85, gColors['CHARTS_COMPONENTS']['Y_AXIS']['STOPS']['RED']]);
                aStops.push([0.9, gColors['CHARTS_COMPONENTS']['Y_AXIS']['STOPS']['YELLOW']]);
                aStops.push([0.95, gColors['CHARTS_COMPONENTS']['Y_AXIS']['STOPS']['GREEN']]);
                oYAxis['stops'] = aStops;
                oYAxis['lineWidth'] = 0;
                oYAxis['tickAmount'] = 2;
                oYAxis['title']['y'] = -90;
                oYAxis["minorTickInterval"] = null;
                if (formatter === 'solidGauge_arc_small')
                    oYAxis['labels']['y'] = 500;
                else
                    oYAxis['labels']['y'] = 600;
            }
            return oYAxis;
        }

        //Metodo de objeto que construye objeto yAxis
        this.buildAndGet = function() {
            //Llama a metodo para construir yAxis
            build();
            return yAxis;
        };

        //Metodo de objeto que devuelve variable para validacion de existencia de funcionalidad stack
        this.getHasPropStack = function() {
            return hasPropStack;
        };

        //Metodo para mostrar en consola propiedades de construidas de yAxis
        this.toString = function() {
            console.log("yAxis - object property");
            console.log(yAxis);
            console.log("yAxis - hasPropStack property");
            console.log(hasPropStack);
        };
    }

    //Metodo estatico de YAxis para construir listado de yAxis
    YAxis.buildListYAxis = function(dataYAxis, nFormatterChart, id) {
        var gYAxis = {}, iYAxis, yAxis, oYAxis, rYAxis, listYAxis = [], hasPropStackYAxis = false;
        //Recorre listado de yAxis de data
        for (iYAxis in dataYAxis) {
            //Obtiene objeto yAxis de data
            yAxis = dataYAxis[iYAxis];
            //Instancia objeto yAxis
            oYAxis = new YAxis(yAxis, nFormatterChart);
            //Construye objeto yAxis
            rYAxis = oYAxis.buildAndGet();
            //Agrega objeto yAxis a listado
            listYAxis.push(rYAxis);
            //Valida que variable de existencia de Stack para yAxis sea diferente a false
            if (!hasPropStackYAxis) {
                //Asigna valor de existencia de propiedad Stack para YAxis
                hasPropStackYAxis = oYAxis.getHasPropStack();
            }
        }
        //Construye objeto de retorno con datos para YAxis
        gYAxis['listYAxis'] = listYAxis;
        gYAxis['hasPropStack'] = hasPropStackYAxis;
        //Guarda en variable global conjunto de yAxis por cada id
        gListYAxis[id] = listYAxis;
        gHasPropStackYAxis[id] = hasPropStackYAxis;
        return gYAxis;
    };

    //Metodo estatico de YAxis para construir listado de yAxis
    YAxis.toString = function(id) {
        console.log("yAxis - list yAxis");
        console.log(gListYAxis[id]);
        console.log("yAxis - hasPropStackYAxis");
        console.log(gHasPropStackYAxis[id]);
    };

    return YAxis;
});

