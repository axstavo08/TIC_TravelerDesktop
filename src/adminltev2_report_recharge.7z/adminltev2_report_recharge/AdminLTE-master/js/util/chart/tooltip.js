/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 19/01/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */
define(['jquery', 'global-colors'], function($, gColors) {

    function Tooltip(dTooltip, formatter, quantitySeries, existXAxis) {
        var tooltip = {};

        //Valida existencia de objeto Tooltip
        if (!(this instanceof Tooltip)) {
            throw new TypeError("Tooltip constructor cannot be called as a function.");
        }

        //Construye objeto tooltip
        function build() {
            //Declaracion de variables para construccion de propiedad atributo
            var aShared = true, formatTooltip = false, aFormatter, tFormatterTooltip;
            //Valida si existe configuracion en data tooltip
            if (typeof dTooltip !== 'undefined' && dTooltip !== null) {
                //Valida que tooltip tenga formato
                if (dTooltip['_hasFormatter']) {
                    //Asigna nombre de formatter a variable
                    tFormatterTooltip = dTooltip['_formatterType'];
                    //Asigna a variable valor de validacion para construir tooltip
                    formatTooltip = true;
                    //Propiedad formatter para tooltip
                    aFormatter = function() {
                        var formatter;
                        formatter = buildFormatterActionTooltipForCoverageDepartment(dTooltip, tFormatterTooltip, this['x'], this['points']);
                        return formatter;
                    };
                }
            } else {
                //Asigna a variable valor de validacion para construir tooltip
                formatTooltip = true;
            }
            //Validacion para construir objeto chart por atributos o directamente de data
            if (formatTooltip) {
                //Construccion de objeto tooltip
                tooltip['shared'] = aShared;
                tooltip['formatter'] = aFormatter;
            } else {
                //Construccion de tooltip por data tooltip directamente
                tooltip = dTooltip;
            }
            //Valida que formatter de chart exista
            if (typeof formatter !== 'undefined' && formatter !== null) {
                tooltip = buildAttributesForObjectTooltipByChartFormmater(tooltip, formatter);
            }
            //Valida cantidad de series para agregar atributos adicionales a objeto tooltip
            /*if (quantitySeries > 18 && existXAxis) {
                tooltip = buildAttributesForObjectTooltipByQuantitySeries(tooltip);
            }*/
        }

        //Retorna accion de formatter para tooltip
        function buildFormatterActionTooltipForCoverageDepartment(dataTooltip, nFormatter, valueX, valuePoints) {
            var rFormatter = '', listOptions, vOption, iOptions, points, iPoints, point,
                    options = dataTooltip['_formatterOptions']['quantity'];
            //Inicia formatter con valor de x
            rFormatter = '<b>'.concat(valueX).concat('</b>');
            //Obtiene nombre de llaves de opciones
            listOptions = Object.keys(options);
            //Recorre opciones
            for (iOptions in listOptions) {
                vOption = listOptions[iOptions];
                //Valida que opcion coincida con valor x
                if (vOption === valueX) {
                    points = valuePoints;
                    //Recorre puntos
                    for (iPoints in points) {
                        point = points[iPoints];
                        //Valida por nombre de formato
                        if (nFormatter === 'coverage_percentage_quantity') {
                            //Construye formatter por nombre
                            rFormatter += buildTooltipForCoverageDepartment(point, options);
                        }
                    }
                    break;
                }
            }
            return rFormatter;
        }

        //Construye tooltip por formatter para chart de Cobertura - Departamento
        function buildTooltipForCoverageDepartment(point, options) {
            var formatter;
            //Agrega a variable formato
            formatter = '<br/>' + point['series']['name'].concat(': ').concat(((point['y'] / 100) * options[point['x']]).toFixed(0))
                    .concat(' (').concat((point['y']).toFixed(2)).concat('%)');
            return formatter;
        }

        //Construye atributos para objeto tooltip por formato de chart
        function buildAttributesForObjectTooltipByChartFormmater(oTooltip, formatter) {
            var aStyle = {};
            //Valida formatter
            if (formatter === 'critseg_usersscore') {
                //Asigna nuevos atributos a objeto tooltip
                oTooltip['useHTML'] = true;
                aStyle['pointerEvents'] = "auto";
                oTooltip["style"] = aStyle;
            } else if (formatter.indexOf("not_axis") !== -1) {
                oTooltip['headerFormat'] = "";
            }
            return oTooltip;
        }

        //Construye atributos para objeto tooltip por cantidad de series
        /*function buildAttributesForObjectTooltipByQuantitySeries(oTooltip) {
            oTooltip['shared'] = true;
            oTooltip['useHTML'] = true;
            oTooltip['backgroundColor'] = gColors['CHARTS_COMPONENTS']['TOOLTIP']['MANY_SERIES']['BACKGROUND_COLOR']['WHITE'];
            oTooltip['borderWidth'] = 0;
            oTooltip['shadow'] = false;
            oTooltip['followPointer'] = false;
            oTooltip['positioner'] = function(labelWidth, labelHeight, point) {
                var position;
                position = buildPositionerTooltipByQuantitySeries(labelWidth, labelHeight, point);
                return {
                    'x': position
                };
            };
            oTooltip['formatter'] = function() {
                //Inicializa variables
                var formatter = '<div class="custChartTooltip"><b>'.concat(this['x']).concat('</b>');
                //Recorre puntos
                $.each(this.points, function() {
                    formatter += '<br/><span style="color:'.concat(this['color']).concat('" x="8" dy="15"><i class="fa fa-circle" aria-hidden="true"></i></span>')
                            .concat('<span class="chart-space" style="">').concat(this['series']['name']).concat(': ')
                            .concat(this['y']).concat('</span>');
                });
                formatter += '</div>';
                return formatter;

            };
            return oTooltip;
        }*/

        //Retorna posicion de tooltip por cantidad de series
        /*function buildPositionerTooltipByQuantitySeries(labelWidth, labelHeight, point) {
            var position, labelW = labelWidth * 2, position = point.plotX - labelW / 2;
            if (position < 0) {
                position = point.plotX + labelW / 4;
            }
            return position;
        }*/

        //Metodo de objeto que construye objeto tooltip
        this.buildAndGet = function() {
            //Llama a metodo para construir tooltip
            build();
            return tooltip;
        };

        //Metodo para mostrar en consola propiedades de construidas de tooltip
        this.toString = function() {
            console.log("tooltip - object property");
            console.log(tooltip);
        };
    }

    return Tooltip;
});
