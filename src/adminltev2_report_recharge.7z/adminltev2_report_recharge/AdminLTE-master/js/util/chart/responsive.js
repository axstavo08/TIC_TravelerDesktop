/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 22/01/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */
define(['chart-dimensions'], function(cDimensions) {

    function Responsive(tFormatterChart, widthChart) {
        var responsive = {};

        //Valida existencia de objeto Responsive
        if (!(this instanceof Responsive)) {
            throw new TypeError("Responsive constructor cannot be called as a function.");
        }

        //Construye objeto responsive
        function build() {
            //Valida existencia de tipo formatter
            if (typeof tFormatterChart !== 'undefined' && tFormatterChart !== null) {
                //Valida tipo de formatter
                switch (tFormatterChart) {
                    case "vas_main_tab_legend_two_cols":
                    case "vas_main_legend_two_cols":
                    case "vas_tab_legend_two_cols_not_axis":
                    case "vas_pie_det_tab_legend_two_cols":
                    case "vas_pie_legend_two_cols":
                        responsive['rules'] = buildRulesForObjectResponsive(widthChart);
                        break;
                }
            }
        }

        //Construye reglas para objeto responsive
        function buildRulesForObjectResponsive(widthChart) {
            var rules = [], rule = {};
            //Consttruye regla
            rule['condition'] = buildConditionRule();
            rule['chartOptions'] = buildChartOptionsRule(widthChart);
            //Agrega regla a listado de reglas para retorno
            rules.push(rule);
            return rules;
        }

        //Construye objeto condicion para regla responsive
        function buildConditionRule() {
            var oCondition = {};
            //Construye objeto condition
            oCondition['maxWidth'] = cDimensions['RESPONSIVE']['CONDITION']['MAX']['WIDTH'];
            return oCondition;
        }

        //Construye objeto chartOptions para regla responsive
        function buildChartOptionsRule(widthChart) {
            var oChartOptions = {}, aLegend = {};
            //Construye atributo legend para objeto chartOptions
            aLegend['width'] = widthChart - '10%';
            aLegend['itemWidth'] = widthChart - '10%';
            //construye objeto chartOptions
            oChartOptions['legend'] = aLegend;
            return oChartOptions;
        }

        //Metodo de objeto que construye objeto responsive
        this.buildAndGet = function() {
            //Llama a metodo para construir responsive
            build();
            return responsive;
        };

        //Metodo para mostrar en consola propiedades de construidas de responsive
        this.toString = function() {
            console.log("responsive - object property");
            console.log(responsive);
        };
    }

    return Responsive;
});