/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 19/01/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */
define([
    'global-colors', 'chart-labels', 'chart-dimensions', 'chart/typeChart'
], function(gColors, cLabels, cDimensions, typeChart) {

    function Exporting(dataExporting, tView, tChart, auxNameExport) {
        var exporting = {};

        //Valida existencia de objeto Exporting
        if (!(this instanceof Exporting)) {
            throw new TypeError("Exporting constructor cannot be called as a function.");
        }

        //Construye objeto exporting
        function build() {
            //Declaracion de variables para construccion de listado de xAxis
            var aName, nExport = (typeof auxNameExport !== 'undefined' && auxNameExport !== "") ? "_".concat(auxNameExport) : "";
            //Valida existencia de data de objeto exporting
            if (dataExporting !== null) {
                //Construye nombre de exporting
                aName = dataExporting['module'].concat("_").concat(dataExporting['indicator']).concat(nExport);
                //Construye objeto exporting
                exporting['buttons'] = buildButtonsForExporting();
                exporting = getDimensForObjectExportingByTypeChart(exporting, tView);
                exporting['enabled'] = dataExporting['enabled'];
                exporting['filename'] = aName;
                exporting['chartOptions'] = buildChartOptionsForObjectExporting(aName, tChart);
            } else {
                exporting['enabled'] = false;
            }
        }

        //Construye propiedad buttons para objeto exporting
        function buildButtonsForExporting() {
            var pButtons = {}, pContextButton = {};
            //Construye objeto buttons
            pContextButton['enabled'] = true;
            pButtons['contextButton'] = pContextButton;
            return pButtons;
        }

        //Obtiene dimensiones por tipo de chart
        function getDimensForObjectExportingByTypeChart(exporting, view) {
            var oDimensions;
            //Obtiene dimensiones segun tipo de vista
            oDimensions = cDimensions['VIEW'][view]['SOURCE'];
            //Construye dimensiones para objeto exporting
            exporting['sourceWidth'] = oDimensions['WIDTH'];
            exporting['sourceHeight'] = oDimensions['HEIGHT'];
            return exporting;
        }

        //Construye propiedad chartOptions para objecto exporting
        function buildChartOptionsForObjectExporting(name, type) {
            var oChartOptions = {}, aChart = {}, aCredits = {};
            //Construye objeto chartOptions
            aChart['events'] = buildEventsChartForObjectExporting(name);
            oChartOptions['chart'] = aChart;
            aCredits['enabled'] = true;
            aCredits['text'] = cLabels['PROJECT']['LABEL'];
            aCredits['position'] = buildPositionCreditsForObjectExporting();
            aCredits['style'] = buildStyleCreditsForObjectExporting();
            oChartOptions['credits'] = aCredits;
            oChartOptions['yAxis'] = buildYAxisChartOptionsForObjectExporting(type);
            return oChartOptions;
        }

        //Construye eventos para chart en objeto exporting
        function buildEventsChartForObjectExporting(name) {
            var events = {};
            //Construye eventos
            events['load'] = function() {
                this.renderer.text(name, 22, 22).css({
                    color: gColors['CHARTS_COMPONENTS']['EXPORTING']['CHART']['TEXT']['BRICK'],
                    fontWeigth: "bold",
                    fontSize: "16px",
                    fontFamily: "Times New Roman"
                }).add();
            };
            return events;
        }

        //Construye posicion para creditos en objeto exporting
        function buildPositionCreditsForObjectExporting() {
            var oPosition = {};
            //Construye posicion para creditos
            oPosition['align'] = "right";
            oPosition['x'] = -25;
            oPosition['verticalAlign'] = "bottom";
            oPosition['y'] = -15;
            return oPosition;
        }

        //Construye estilo para creditos en objeto exporting
        function buildStyleCreditsForObjectExporting() {
            var oStyle = {};
            //Construye posicion para creditos
            oStyle['cursor'] = "pointer";
            oStyle['color'] = gColors['CHARTS_COMPONENTS']['EXPORTING']['CREDITS']['TEXT']['RED'];
            oStyle['fontWeight'] = "bold";
            oStyle['fontSize'] = "13px";
            oStyle['fontFamily'] = "Trebuchet MS, Verdana, sans-serif";
            return oStyle;
        }

        //Construye yAxis para propiedad chartOptions para objeto exporting
        function buildYAxisChartOptionsForObjectExporting(type) {
            var oYAxis = {}, aTitle = {};
            //Valida tipo de chart
            if (type === typeChart['SOLID_GAUGE']) {
                aTitle['y'] = -110;
                oYAxis['title'] = aTitle;
            }
            return oYAxis;
        }

        //Metodo de objeto que construye objeto exporting
        this.buildAndGet = function() {
            //Llama a metodo para construir exporting
            build();
            return exporting;
        };

        //Metodo para mostrar en consola propiedades de construidas de exporting
        this.toString = function() {
            console.log("exporting - object property");
            console.log(exporting);
        };
    }

    return Exporting;
});