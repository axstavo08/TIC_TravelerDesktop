/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 18/01/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

define({
    'DEFAULT': "line",
    'LINE': "line",
    'AREA': "area",
    'COLUMN': "column",
    'BAR': "bar", 
    'PIE': "pie",
    'SCATTER_PLOT': "scatter",
    'SOLID_GAUGE': "solidgauge"
});
