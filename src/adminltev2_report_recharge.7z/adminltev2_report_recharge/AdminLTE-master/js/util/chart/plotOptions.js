/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 19/01/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */
define(['jquery'], function($) {

    function PlotOptions(tChart, hasPropStackYAxis, tFormatterChart, titleXAxis, titleYAxis) {
        var plotOptions = {};

        //Valida existencia de objeto PlotOptions
        if (!(this instanceof PlotOptions)) {
            throw new TypeError("PlotOptions constructor cannot be called as a function.");
        }

        //Construye objeto plotOptions
        function build() {
            //Inicializa objeto atributo por nombre de tipo de chart
            plotOptions[tChart] = {};
            //Valida que propiedad Stack sea verdadero
            if (hasPropStackYAxis) {
                plotOptions[tChart]['stacking'] = "normal";
            }
            //Valida que formatter de chart exista
            if (tFormatterChart === null) {
                tFormatterChart = tChart;
            }
            plotOptions = buildAttributesForObjectPlotOptionsByChartFormmater(plotOptions, tFormatterChart, tChart, titleXAxis, titleYAxis);
        }

        //Construye atributos de objeto plotOptions por formato de chart
        function buildAttributesForObjectPlotOptionsByChartFormmater(oPlotOptions, formatter, typeChart, titleXAxis, titleYAxis) {
            var vSeries = {}, vLabelDistance, vPoint = {};
            if (typeof formatter !== 'undefined' && formatter !== null) {
                //Valida formatter
                if (formatter === "coverage_percentage_quantity") {
                    //Agrega nuevos atributos a objeto plotOptions
                    vSeries['events'] = actionsEventsSeriesForObjectPlotOptionsByChartFormatter(formatter);
                } else if (formatter === "critseg_usersscore") {
                    //Agrega nuevos atributos a objeto plotOptions
                    vSeries['turboThreshold'] = 10000;
                    oPlotOptions[typeChart]['tooltip'] = buildFormatTooltipForObjectPlotOptionsByChartFormatter(titleXAxis, titleYAxis);
                    oPlotOptions[typeChart]['cursor'] = "pointer";
                    oPlotOptions[typeChart]['events'] = actionsEventsTypeChartForObjectPlotOptionsByChartFormatter(formatter);
                } else if (formatter.indexOf("vas_main") !== -1) {
                    //Agrega nuevos atributos a objeto plotOptions
                    vSeries['allowPointSelect'] = true;
                    vPoint['events'] = actionsEventsPointSeriesForObjectPlotOptionsByChartFormatter(formatter);
                    vSeries['point'] = vPoint;
                } else if (formatter === "solidGauge_arc") {
                    oPlotOptions[typeChart]['dataLabels'] = buildDataLabelsTypeChartForObjectPlotOptionsByChartFormatter(formatter, vLabelDistance);
                } else if (formatter === "solidGauge_arc_small") {
                    oPlotOptions[typeChart]['dataLabels'] = buildDataLabelsTypeChartForObjectPlotOptionsByChartFormatter(formatter, vLabelDistance);
                } else if (formatter.indexOf("pie") !== -1) {
                    oPlotOptions[typeChart]['allowPointSelect'] = true;
                    oPlotOptions[typeChart]['cursor'] = "pointer";
                    oPlotOptions[typeChart]['showInLegend'] = true;
                    if (formatter === "critseg_pie_init") {
                        vLabelDistance = -25;
                    } else if (formatter === "coverage_pie_init") {
                        vLabelDistance = -50;
                    } else if (formatter === "coverage_pie_searcher") {
                        vLabelDistance = -50;
                    } else if (formatter.indexOf("vas_pie") !== -1) {
                        vLabelDistance = -25;
                    } else if (formatter === "pie") {
                        vLabelDistance = -50;
                    }
                    oPlotOptions[typeChart]['dataLabels'] = buildDataLabelsTypeChartForObjectPlotOptionsByChartFormatter(formatter, vLabelDistance);
                }
            }
            //Construye atributos para objeto plotOptions
            oPlotOptions['series'] = vSeries;
            return oPlotOptions;
        }

        //Retorne acciones de eventos para series por tipo de formato de chart
        function actionsEventsSeriesForObjectPlotOptionsByChartFormatter(formatter) {
            var events = {};
            if (formatter === "coverage_percentage_quantity") {
                events['legendItemClick'] = function() {
                    return false;
                };
            }
            return events;
        }

        //Retorne acciones de eventos para tipo de chart por tipo de formato de chart
        function actionsEventsTypeChartForObjectPlotOptionsByChartFormatter(formatter) {
            var events = {};
            if (formatter === "critseg_usersscore") {
                events['click'] = function(event) {
                    console.log("puntos_click_event");
                    console.log(event.point);
                    //location.href = "http://api.highcharts.com/highcharts/series%3Cscatter%3E.events.click";
                };
            }
            return events;
        }

        //Retorne acciones de eventos para punto de series por tipo de formato de chart
        function actionsEventsPointSeriesForObjectPlotOptionsByChartFormatter(formatter) {
            var events = {}, pointSerie = {};
            if (formatter.indexOf("vas_main") !== -1) {
                events['click'] = function() {
                    pointSerie['category'] = this['category'];
                    $('#modalPlatform').triggerHandler("modalDetail", [pointSerie]);
                };
            }
            return events;
        }

        //Construye atributo dataLabels para objeto plotOptions por tipo de formato de chart
        function buildDataLabelsTypeChartForObjectPlotOptionsByChartFormatter(formatter, labelDistance) {
            var dataLabels = {};
            dataLabels['borderWidth'] = 0;
            if (formatter.indexOf("solidGauge_arc") !== -1) {
                dataLabels['useHTML'] = true;
                if (formatter === "solidGauge_arc") {
                    dataLabels['y'] = -60;
                } else if (formatter === "solidGauge_arc_small") {
                    dataLabels['y'] = -40;
                }
            } else if (formatter.indexOf("pie") !== -1) {
                dataLabels['distance'] = labelDistance;
                dataLabels['format'] = '<b>{point.percentage:.1f}%</b>';
            }
            return dataLabels;
        }

        //Construye formato de tooltip por tipo de formato de chart
        function buildFormatTooltipForObjectPlotOptionsByChartFormatter(titleXAxis, titleYAxis) {
            var tooltip = {};
            tooltip['headerFormat'] = '<b>{series.name}</b><br>';
            tooltip['pointFormat'] = titleXAxis.concat(': {point.x}<br>').concat(titleYAxis)
                    .concat(': {point.y}<br>').concat('C&oacute;digo: {point._segmentCode}<br>')
                    .concat('Nombre: {point._segmentName}');
            return tooltip;
        }

        //Metodo de objeto que construye objeto plotOptions
        this.buildAndGet = function() {
            //Llama a metodo para construir plotOptions
            build();
            return plotOptions;
        };

        //Metodo para mostrar en consola propiedades de construidas de plotOptions
        this.toString = function() {
            console.log("plotOptions - object property");
            console.log(plotOptions);
        };
    }

    return PlotOptions;
});