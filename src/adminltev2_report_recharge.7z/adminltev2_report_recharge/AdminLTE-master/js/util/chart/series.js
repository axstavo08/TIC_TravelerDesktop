/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 19/01/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */
define(['global-colors', 'chart-labels'], function(gColors, cLabels) {

    var gListSeries = {};

    function Serie(dSerie, tFormatterChart, dXAxisCategories) {
        var serie = {};

        //Valida existencia de objeto Serie
        if (!(this instanceof Serie)) {
            throw new TypeError("Serie constructor cannot be called as a function.");
        }

        //Construye objeto serie
        function build() {
            //Construye atributos en comun
            serie['name'] = dSerie['name'];
            serie['yAxis'] = dSerie['yAxis'];
            serie['connectNulls'] = dSerie['connectNulls'];
            serie['visible'] = dSerie['visible'];
            serie['tooltip'] = dSerie['tooltip'];
            serie['type'] = dSerie['type'];
            serie['dashStyle'] = dSerie['dashStyle'];
            serie['data'] = dSerie['data'];
            //Valida formatter
            if (typeof tFormatterChart !== 'undefined' && tFormatterChart !== null) {
                //Valida tipo de formatter
                switch (tFormatterChart) {
                    case "coverage_vendors_dep":
                        serie['data'] = buildDataStructureForSerieUsingCategoriesXAxis(dSerie['name'], dSerie['data'], tFormatterChart, dXAxisCategories);
                        serie['showInLegend'] = false;
                        serie['color'] = dSerie['color'];
                        break;
                    case "coverage_vendors_reg":
                    case "coverage_percentage_quantity":
                    case "critseg_usersscore":
                    case "critseg_priority":
                    case "critseg_resp_planning":
                    case "critseg_resp_opti":
                    case "coverage_init":
                        serie['data'] = dSerie['data'];
                        serie['color'] = assignColorForVendorSerieByTypeFormatterAndName(tFormatterChart, dSerie['name']);
                        break;
                    case "coverage_pie_init":
                    case "coverage_pie_searcher":
                        serie['data'] = buildDataStructureForSerieUsingCategoriesXAxis(dSerie['name'], dSerie['data'], tFormatterChart, dXAxisCategories);
                        break;
                    case "solidGauge_arc":
                    case "solidGauge_arc_small":
                        serie['data'] = dSerie['data'];
                        serie['dataLabels'] = buildFormatForDataLabelsByChartFormatter(tFormatterChart);
                        break;
                }
            }
        }

        //Construye nueva estructura de data de serie asignando colores
        function buildDataStructureForSerieUsingCategoriesXAxis(nSerie, dSerie, tFormatter, xAxisCategories) {
            var structureDataSerie = [], oColors, aColors, iXAxisCategories, vDataAux = {};
            //Valida tipo de formatter
            switch (tFormatter) {
                case "coverage_vendors_dep":
                    //Obtiene colores
                    oColors = gColors['COVERAGE']['MOBILE']['VENDOR'];
                    //Valida existencia de objeto colores
                    if (typeof oColors !== 'undefined') {
                        //Recorre listado de categories de xAxis
                        for (iXAxisCategories in xAxisCategories) {
                            //Guarda en objeto auxiliar nombre de operador y su valor (proviniente de data de series)
                            //El orden coincide con el nombre de operador y su valor correspondiente
                            vDataAux[xAxisCategories[iXAxisCategories]] = dSerie[iXAxisCategories];
                        }
                        //Tener en cuenta: Se utilizan nombres de las series coincidentes a su construccion en ws
                        //Valida nombre de serie
                        if (nSerie === cLabels['COVERAGE']['VILLAGES']) {
                            //Obtiene colores personalizados de objeto colores
                            aColors = oColors['VILLAGES'];
                        } else if (nSerie === cLabels['COVERAGE']['POPULATION']) {
                            //Obtiene colores personalizados de objeto colores
                            aColors = oColors['POPULATION'];
                        }
                        //Construye data de series por colores
                        structureDataSerie = buildListDataSerieForVendorsByColors(vDataAux, aColors);
                    }
                    break;
                case "coverage_pie_searcher":
                case "coverage_pie_init":
                    //Construye data de series por colores
                    structureDataSerie = assignColorForCoverageByDataSeriePieChart(tFormatter, dSerie);
                    break;
            }
            return structureDataSerie;
        }

        //Asigna color a serie por tipo de formatter y nombre
        function assignColorForVendorSerieByTypeFormatterAndName(tFormatter, nSerie) {
            var color, oColors;
            //Valida existencia de serie
            if (typeof nSerie !== 'undefined' && nSerie !== null) {
                //Valida formatter
                switch (tFormatter) {
                    case "coverage_vendors_reg":
                        //Obtiene colores
                        oColors = gColors['COVERAGE']['MOBILE']['VENDOR']['VILLAGES'];
                        break;
                    case "coverage_init":
                        //Obtiene colores
                        oColors = gColors['COVERAGE']['MOBILE']['INIT'];
                        break;
                    case "coverage_percentage_quantity":
                        //Obtiene colores
                        oColors = gColors['COVERAGE']['MOBILE']['INIT'];
                        break;
                    case "critseg_usersscore":
                        //Obtiene colores
                        oColors = gColors['CRITICAL_SEGMENT']['USERS_SCORE_PRIORITY'];
                        break;
                    case "critseg_priority":
                        //Obtiene colores
                        oColors = gColors['CRITICAL_SEGMENT']['PRIORITY'];
                        break;
                    case "critseg_resp_planning":
                        //Obtiene colores
                        oColors = gColors['CRITICAL_SEGMENT']['RESPONSIBLE_PLANIFICATION'];
                        break;
                    case "critseg_resp_opti":
                        //Obtiene colores
                        oColors = gColors['CRITICAL_SEGMENT']['RESPONSIBLE_OPTIMIZATION'];
                        break;
                }
                //Obtiene color
                color = assignColorByName(nSerie, oColors);
            }
            return color;
        }

        //Construye formato para propiedad datalabels por tipo de formato de chart
        function buildFormatForDataLabelsByChartFormatter(tFormatter) {
            var dataLabels = {}, vSizeValue, vStyleSuffix = '';
            //Valida formatter
            if (tFormatter.indexOf("solidGauge_arc") !== -1) {
                //Valida formatter para tipo chart solidcauge
                if (tFormatter === "solidGauge_arc") {
                    //Asigna tamaño de valor de dato
                    vSizeValue = '25';
                } else if (tFormatter === "solidGauge_arc_small") {
                    //Asigna tamaño de valor de dato
                    vSizeValue = '16';
                    //Asigna cadena de estilos adicionales para dataLabels
                    vStyleSuffix = ' text-align:center;';
                }
                dataLabels['format'] = '<div style = "text-align: center;"><span style = "font-size: '.concat(vSizeValue)
                        .concat('px; color: ').concat(gColors['CHARTS_COMPONENTS']['SERIE']['DATA_LABELS']['SOLID_CAUGE']['VALUE'])
                        .concat(';">{y}</span><br/>').concat('<span style = "font-size: 12px; color: ')
                        .concat(gColors['CHARTS_COMPONENTS']['SERIE']['DATA_LABELS']['SOLID_CAUGE']['SUFFIX'])
                        .concat(';').concat(vStyleSuffix).concat('">%</span></div>');
            }
            return dataLabels;
        }

        //Crear estructura de data para serie con colores personalizados
        function buildListDataSerieForVendorsByColors(dataVendors, colors) {
            var lDataStructure = [], iVendor;
            //Recorre listado de data auxiliar de operadoras
            for (iVendor in dataVendors) {
                //Agrega objecta construido a listado
                lDataStructure.push(getDataStructureByVendor(iVendor, dataVendors[iVendor], colors));
            }
            return lDataStructure;
        }

        //Asigna color a data para operadoras por listado de data de serie para pie chart
        function assignColorForCoverageByDataSeriePieChart(tFormatter, listDataSerie) {
            var lStructureDataSerie = [], iDataSerie, dataSerie, nDataSerie, oColors, aColor;
            //Recorre listado de data series
            for (iDataSerie in listDataSerie) {
                dataSerie = listDataSerie[iDataSerie];
                nDataSerie = dataSerie['name'];
                //Valida formatter
                if (tFormatter.indexOf("coverage_pie") !== -1) {
                    //Valida formatter
                    if (tFormatter === "coverage_pie_searcher") {
                        //Obtiene colores
                        oColors = gColors['COVERAGE']['MOBILE']['SEARCHER'];
                    } else if (tFormatter === "coverage_pie_init") {
                        //Obtiene colores
                        oColors = gColors['COVERAGE']['MOBILE']['INIT'];
                    }
                    //Obtiene color por nombe de data serie
                    aColor = assignColorByName(nDataSerie, oColors);
                    lStructureDataSerie.push(getDataStructureByCoverage(nDataSerie, dataSerie['y'], aColor));
                }
            }
            return lStructureDataSerie;
        }

        function getDataStructureByVendor(nameVendor, valueVendor, colors) {
            var oDataStructure = {};
            //Construyendo objeto de data
            oDataStructure['y'] = valueVendor;
            oDataStructure['color'] = assignColorByName(nameVendor, colors);
            return oDataStructure;
        }

        //Obtiene objeto data con color para cobertura
        function getDataStructureByCoverage(name, value, color) {
            var oDataSerie = {};
            //Construyendo objeto de data
            oDataSerie['name'] = name;
            oDataSerie['y'] = value;
            oDataSerie['color'] = color;
            return oDataSerie;
        }

        //Asigna color para cobertura
        function assignColorByName(name, oColors) {
            var color;
            //Valida nombre de serie o nombre de data serie
            switch (name) {
                case cLabels['VENDORS']['CLARO']:
                default:
                    color = oColors[name]['RED'];
                    break;
                case cLabels['VENDORS']['MOVISTAR']:
                    color = oColors[name]['GREEN'];
                    break;
                case cLabels['VENDORS']['ENTEL']:
                    color = oColors[name]['BLUE'];
                    break;
                case cLabels['VENDORS']['BITEL']:
                    color = oColors[name]['YELLOW'];
                    break;
                case cLabels['COVERAGE']['VILLAGES']:
                    //Asigna color por nombre de serie
                    color = oColors['VILLAGES']['RED'];
                    break;
                case cLabels['COVERAGE']['POPULATION']:
                    //Asigna color por nombre de serie
                    color = oColors['POPULATION']['BLUE'];
                    break;
                case cLabels['COVERAGE']['WITH_COVERAGE']:
                    //Asigna color por nombre de serie
                    color = oColors['WITH_COVERAGE']['RED'];
                    break;
                case cLabels['COVERAGE']['WITHOUT_COVERAGE']:
                    //Asigna color por nombre de serie
                    color = oColors['WITHOUT_COVERAGE']['BLUE'];
                    break;
                case cLabels['CRITICAL_SEGMENT']['PRIORITY']['00']:
                    //Asigna color por nombre de serie
                    color = oColors['00']['RED'];
                    break;
                case cLabels['CRITICAL_SEGMENT']['PRIORITY']['0']:
                    //Asigna color por nombre de serie
                    color = oColors['0']['ORANGE'];
                    break;
                case cLabels['CRITICAL_SEGMENT']['PRIORITY']['1']:
                    //Asigna color por nombre de serie
                    color = oColors['1']['YELLOW'];
                    break;
                case cLabels['CRITICAL_SEGMENT']['PRIORITY']['2']:
                    //Asigna color por nombre de serie
                    color = oColors['2']['BLUE'];
                    break;
                case cLabels['CRITICAL_SEGMENT']['PRIORITY']['3']:
                    //Asigna color por nombre de serie
                    color = oColors['3']['TURQUOISE'];
                    break;
                case cLabels['CRITICAL_SEGMENT']['PRIORITY']['SOLO_KQI']:
                    //Asigna color por nombre de serie
                    color = oColors['SOLO_KQI']['GREEN'];
                    break;
                case cLabels['CRITICAL_SEGMENT']['RESPONSIBLE_PLANIFICATION']['PLANIFICATION']:
                    //Asigna color por nombre de serie
                    color = oColors['PLANIFICATION']['ORANGE'];
                    break;
                case cLabels['CRITICAL_SEGMENT']['RESPONSIBLE_PLANIFICATION']['PLANIFICATION_FAR_TRAFFIC']:
                    //Asigna color por nombre de serie
                    color = oColors['PLANIFICATION_FAR_TRAFFIC']['BLUE'];
                    break;
                case cLabels['CRITICAL_SEGMENT']['RESPONSIBLE_OPTIMIZATION']['OPTIMIZATION']:
                    //Asigna color por nombre de serie
                    color = oColors['OPTIMIZATION']['GREEN'];
                    break;
                case cLabels['CRITICAL_SEGMENT']['RESPONSIBLE_OPTIMIZATION']['OPTIMIZATION_FEW_TRAFFIC']:
                    //Asigna color por nombre de serie
                    color = oColors['OPTIMIZATION_FEW_TRAFFIC']['BLUE'];
                    break;
                case cLabels['CRITICAL_SEGMENT']['RESPONSIBLE_OPTIMIZATION']['OPTIMIZATION_RURAL']:
                    //Asigna color por nombre de serie
                    color = oColors['OPTIMIZATION_RURAL']['ORANGE'];
                    break;
                case cLabels['CRITICAL_SEGMENT']['RESPONSIBLE_OPTIMIZATION']['OPTIMIZATION_FAR_TRAFFIC']:
                    //Asigna color por nombre de serie
                    color = oColors['OPTIMIZATION_FAR_TRAFFIC']['RED'];
                    break;
            }
            return color;
        }

        //Metodo de objeto que construye objeto series
        this.buildAndGet = function() {
            //Llama a metodo para construir series
            build();
            return serie;
        };

        //Metodo para mostrar en consola propiedades de construidas de serie
        this.toString = function() {
            console.log("serie - object property");
            console.log(serie);
        };
    }

    //Metodo estatico de Serie para construir listado de series
    Serie.buildListSeries = function(dataSeries, tFormatterChart, dataXAxisCategories, id) {
        var iSerie, serie, oSerie, rSerie, listSeries = [];
        //Recorre listado de series de data
        for (iSerie in dataSeries) {
            //Obtiene objeto serie de data
            serie = dataSeries[iSerie];
            //Instancia objeto serie
            oSerie = new Serie(serie, tFormatterChart, dataXAxisCategories);
            //Construye objeto serie
            rSerie = oSerie.buildAndGet();
            //Agrega objeto serie a listado
            listSeries.push(rSerie);
        }
        //Guarda en variable global conjunto de series por cada id
        gListSeries[id] = listSeries;
        return listSeries;
    };

    //Metodo estatico de Serie para construir listado de series
    Serie.toString = function(id) {
        console.log("series - list series");
        console.log(gListSeries[id]);
    };

    return Serie;
});