/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 19/01/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */
define(['global-images', 'chart-labels'], function(gImages, cLabels) {

    function XAxis(dXAxis, tFormatterChart) {
        var xAxis = {};

        //Valida existencia de objeto XAxis
        if (!(this instanceof XAxis)) {
            throw new TypeError("XAxis constructor cannot be called as a function.");
        }

        //Construye objeto xAxis
        function build() {
            //Declaracion de variables para construccion de listado de xAxis
            var aTitle = {};
            //Valida existencia de data de objeto xAxis
            if (dXAxis !== null) {
                //Construye atributos en comun
                xAxis['categories'] = dXAxis['categories'];
                xAxis['crosshair'] = dXAxis['crosshair'];
            }
            //Valida formatter
            if (typeof tFormatterChart !== 'undefined' && tFormatterChart !== null) {
                if (tFormatterChart === "coverage_vendors_dep") {
                    xAxis["labels"] = buildLabelsForObjectXaxisByChartFormatter(dXAxis, tFormatterChart);
                } else if (tFormatterChart === "critseg_usersscore") {
                    aTitle['text'] = dXAxis["_title"];
                    xAxis['title'] = aTitle;
                } else if (tFormatterChart.indexOf("not_axis") !== -1) {
                    xAxis['visible'] = false;
                }
            }
        }

        //Construye labels para objeto xAxis por formato de chart
        function buildLabelsForObjectXaxisByChartFormatter(dataXAxis, formatter) {
            var labels = {};
            //Valida formatter
            if (formatter === "coverage_vendors_dep") {
                labels['useHTML'] = true;
                labels['formatter'] = function() {
                    var xAxisImage = {};
                    xAxisImage = buildFormatterXAxisByChartFormatter(dataXAxis, formatter);
                    return xAxisImage[this.value];
                };
            }
            return labels;
        }

        //Retorna formatter para labels de objeto xAxis por tipo de formatter
        function buildFormatterXAxisByChartFormatter(dataXAxis, formatter) {
            var xAxisImage = {}, iCategories;
            //Valida formatter
            if (formatter === "coverage_vendors_dep") {
                for (iCategories in dataXAxis['categories']) {
                    switch (dataXAxis['categories'][iCategories]) {
                        case cLabels['VENDORS']['CLARO']:
                            xAxisImage[cLabels['VENDORS']['CLARO']] = '<img src="'.concat(gImages['IMG_CLARO_LOGO']).concat('" style="width: 30px; margin-left: -10px;" />');
                            break;
                        case cLabels['VENDORS']['MOVISTAR']:
                            xAxisImage[cLabels['VENDORS']['MOVISTAR']] = '<img src="'.concat(gImages['IMG_MOVISTAR_LOGO']).concat('" style="width: 30px; margin-left: -10px; margin-top: 20%;" />');
                            break;
                        case cLabels['VENDORS']['ENTEL']:
                            xAxisImage[cLabels['VENDORS']['ENTEL']] = '<img src="'.concat(gImages['IMG_ENTEL_LOGO']).concat('" style="width: 30px; margin-left: -10px; margin-top: 20%;" />');
                            break;
                        case cLabels['VENDORS']['BITEL']:
                            xAxisImage[cLabels['VENDORS']['BITEL']] = '<img  src="'.concat(gImages['IMG_BITEL_LOGO']).concat('" style="width: 30px; margin-left: -10px;" />');
                            break;
                    }
                }
            }
            return xAxisImage;
        }

        //Metodo de objeto que construye objeto xAxis
        this.buildAndGet = function() {
            //Llama a metodo para construir xAxis
            build();
            return xAxis;
        };

        //Metodo para mostrar en consola propiedades de construidas de xAxis
        this.toString = function() {
            console.log("xAxis - object property");
            console.log(xAxis);
        };
    }

    return XAxis;
});