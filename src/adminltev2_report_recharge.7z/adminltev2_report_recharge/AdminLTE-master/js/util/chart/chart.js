/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 17/01/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

define([
    'chart/builder', 'chart-labels', 'i18n!js/nls/imessages', 'highcharts-common',
    'highcharts-no-data-to-display', 'highcharts-theme-smartflex', 'highcharts-more',
    'highcharts-solid-gauge', 'highcharts-exporting', 'highcharts-offline-exporting',
    'highcharts-export-csv'
], function(builder, cLabels, iMessages, Highcharts) {

    //Se agrega objeto Highcharts a ventana actual
    window.Highcharts = Highcharts;

    //Metodo principal para crear objeto principal Chart
    function Chart(id, data) {
        //Declaracion y definicion de variables
        var oChart, pChartOptions, pHasData, pHasNotNullableValue, pSubstrTitle;

        //Valida que exista tipo objeto principal Chart
        if (!(this instanceof Chart)) {
            throw new TypeError("Chart constructor cannot be called as a function.");
        }

        //Construye Chart Options para objeto chart
        function build() {
            //Declaracion de variables
            var oPropertiesChart;
            //Obtiene objeto con propiedades construidos para chart
            oPropertiesChart = builder.properties(data, id);
            //Obtener y asignar propiedades a variables
            pChartOptions = oPropertiesChart['chartOptions'];
            pHasData = oPropertiesChart['hasData'];
            pHasNotNullableValue = oPropertiesChart['hasNotNullableValue'];
            pSubstrTitle = oPropertiesChart['substrTitle'];
        }

        //Crea objeto chart
        function create() {
            oChart = Highcharts.chart(id, pChartOptions);
            //Metodo para validar mensaje de no data
            validateMessageNoData();
        }

        //Valida existencia de data o de valores nulos
        function validateMessageNoData() {
            //Valida existencia de data o existencia de valores nulos
            if (!pHasData || !pHasNotNullableValue) {
                //Invoca metodo de chart creado para mostrar mensaje de No Data
                showMessageNoData();
            }
        }

        //Metodo para ocultar mensaje no data en chart
        function showMessageNoData() {
            hideMessageNoData();
            oChart.showNoData(cLabels['CHART']['NO_DATA']);
        }

        //Metodo para ocultar mensaje no data en chart
        function hideMessageNoData() {
            oChart.hideNoData();
        }

        //Metodo de objeto para mostrar mensaje de No Data
        this.showMsgNoData = function() {
            //Es necesario ocultar mensaje data para construir mensaje personalizado
            showMessageNoData();
        };

        //Metodo de objeto para ocultar mensaje de No Data
        this.hideMsgNoData = function() {
            hideMessageNoData();
        };

        //Metodo de objeto para mostrar en consola propiedades construidas de chart
        this.toString = function() {
            console.log("chart - chartOptions property");
            console.log(pChartOptions);
            console.log("chart - hasData property");
            console.log(pHasData);
            console.log("chart - hasNotNullableValue property");
            console.log(pHasNotNullableValue);
        };

        //Metodo de objeto para construir obtener propiedades construidas de chart y crearlo
        this.buildAndCreate = function() {
            //Metodo para construir chart
            build();
            //Metodo para crear chart
            create();
        };

        //Metodo de objeto para destruir chart
        this.destroy = function() {
            oChart.destroy();
        };

        //Metodo de objeto para ejecutar animacion a chart
        this.animate = function() {
            reAnimate(true, oChart);
        };

        //Metodo de objeto para reacomodar y ejecutar animacion a chart
        this.reflowAndAnimate = function() {
            this.reflow();
            this.animate();
        };

        //Metodo de objeto para reacomodar chart
        this.reflow = function() {
            oChart.reflow();
        };

        //Metodo de objeto para redibujar chart
        this.redraw = function() {
            oChart.redraw();
        };

        //Metodo de objeto para reacomodar chart por parametro de veces
        this.reflowNTimes = function(ntimes) {
            //Inicializa variables
            var x;
            //Inicia bucle para recorrer chart cada n veces
            for (x = 0; x < ntimes; x++) {
                //Reacomoda chart
                this.reflow();
            }
        };

        //Obtiene titulo de chart
        this.getTitle = function() {
            return oChart['title']['textStr'];
        };

        //Metodo de objeto para cambiar titulo de chart
        this.setTitle = function(newTitle) {
            var newOTitle = {}, chartTitle;
            //Valida que exista valor en la variable vsubstrTitle
            if (typeof pSubstrTitle !== 'undefined' && pSubstrTitle !== null) {
                //Obtiene titulo actual de chart
                chartTitle = this.getTitle();
                //Cambia el valor del titulo de chart del substring del titulo actual por el argumento
                chartTitle = chartTitle.replace(pSubstrTitle, newTitle);
                //Actualiza valor del substring del titulo almacenado por el argumento
                pSubstrTitle = newTitle;
            } else {
                chartTitle = newTitle;
            }
            //Llama al chart y cambia el titulo por el nuevo enviado como argumento
            newOTitle['text'] = chartTitle;
            //Actualiza titulo a chart
            oChart.setTitle(newOTitle);
        };

        //Metodo de objeto para actualizar series de chart
        this.updateSeries = function(newSeries) {
            var iNewSerie;
            this.removeSeries();
            //Inicia bucle para recorrer las nuevas series
            for (iNewSerie in newSeries) {
                //Agrega nuevas series a chart por recorrido
                oChart.addSeries(newSeries[iNewSerie], false);
            }
            this.redraw();
            this.animate();
        };

        //Metodo de objeto para actualizar series de chart
        this.updateXAxis = function(newCategories) {
            oChart['xAxis'][0].setCategories(newCategories, false);
            this.redraw();
        };

        //Metodo de objeto para eliminar series de chart
        this.removeSeries = function() {
            //Inicia bucle para recorrer series mientras sea mayor a 0
            while (oChart['series'].length > 0) {
                //Elimina cada serie de chart
                oChart['series'][0].remove(false);
            }
        };

        //Metodo de objeto para eliminar series de chart y actualizar chart
        this.removeSeriesAndFitChart = function() {
            this.removeSeries();
            this.redraw();
            this.animate();
        };

        //Metodo de objeto para actualizar data de series de pie chart
        this.updateDataPie = function(newData) {
            oChart['series'][0].setData(newData, true);
        };

        //Metodo de objeto para obtener categories de objeto XAxis de chart
        this.getCategories = function() {
            return oChart['xAxis'][0]['categories'];
        };

        //Metodo de objeto para validar si serie tiene data
        this.hasDataSerie = function() {
            return pHasData;
        };

        //Metodo de objeto para mostrar mensaje de cargando en chart
        this.showLoading = function() {
            oChart.showLoading(iMessages['global']['load']);
        };

        //Metodo de objeto para ocultar mensaje de cargando en chart
        this.hideLoading = function() {
            oChart.hideLoading();
        };
    }

    //Metodo de clase para construir y renderizar listado de charts
    Chart.renderCharts = function(structureCharts, data) {
        var i, structureChart, chart, charts = {};
        for (i in structureCharts) {
            structureChart = structureCharts[i];
            chart = new Chart(structureChart.id, data[structureChart.name]);
            chart.buildAndCreate();
            charts[structureChart.id] = chart;
        }
        return charts;
    };

    //Metodo de clase para reacomodar y reanimar listado de charts
    Chart.reflowAndReanimateCharts = function(listCharts) {
        var iChart;
        //Recorre lista de charts
        for (iChart in listCharts) {
            //Reacomoda y reanima charts
            listCharts[iChart].reflowAndAnimate();
        }
    };

    //Metodo de clase para reacomodar listado de charts
    Chart.reflowCharts = function(listCharts) {
        var iChart;
        //Recorre listado de charts
        for (iChart in listCharts) {
            listCharts[iChart].reflow();
        }
    };

    return Chart;
});
