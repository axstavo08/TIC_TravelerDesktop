/**
 * Project Name : smartflex-client 
 * Created: 22/03/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

define(['jquery'], function($) {
    
	/* Completa zeros a numero, donde
	* @num es numero a transformar
	* @width es cantidad de numeros a completar
	* @numPad es numero para completar en el padding
	*/
	function paddingZeros(num, width, numPad){
		//Inicia variables de numero de padding y valor inicial
		var numPad = numPad || '0',
			num = num + '';
		return num.length >= width ? num : new Array(width - num.length + 1).join(numPad) + num;
	}
	
	/* Transforma nombre de etiqueta a formato de letra capital
	* @label es el parametro a transformar
	*/
	function labelToCapitalLetter(label){
		return label.charAt(0).toUpperCase().concat(label.slice(1));
	}

    return {
        paddingZeros: paddingZeros,
        labelToCapitalLetter: labelToCapitalLetter
    };
});