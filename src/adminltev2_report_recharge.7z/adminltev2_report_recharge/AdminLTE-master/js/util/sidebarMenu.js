/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 12/10/2017
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

define(['sidebar-configuration', 'objUtil'], function(config, objUtil) {

    /*Variables globales*/
    //Jerarquia de componentes
    var hierarchy,
            //Obtiene modulo raiz
            rootMenu = $.dataJS(config.ROOT_MENU),
            //Variable que contiene raiz de modulo para activar
            rootModule;

    //Construye jerarquia de sidebar para configuracion
    function mAtiveSidebar(root, main, sub_main, section, sub_section) {
        //Clona objeto jerarquia de recurso
        hierarchy = objUtil.clone(config.HIERARCHY);
        //Asigna valores a objeto jerarquia
        hierarchy.root = setParameterConfigurationSidebar(root);
        hierarchy.main = setParameterConfigurationSidebar(main);
        hierarchy.sub_main = setParameterConfigurationSidebar(sub_main);
        hierarchy.section = setParameterConfigurationSidebar(section);
        hierarchy.sub_section = setParameterConfigurationSidebar(sub_section);
        //Activa componentes de objeto jerarquia de sidebar
        activeModule(hierarchy);
    }

    //Resalta modulo actual en sidebar menu
    function activeModule(oCcomponentSidebar) {
        //Variables utiles
        //Asigna prefijo de inicio de nombre de atributo para sidebar
        var prefixRoot = config.PREFIX_ROOT_MODULE,
                //Variables de jerarquia de componentes en sidebar
                mainModule, subModule, sectionModule, subSectionModule;

        //Reemplaza artificio para raiz de modulo
        rootModule = buildAttrDataJSForComponent(prefixRoot, config.COMPONENT_MODULE, oCcomponentSidebar.root);
        //Borra clases activas en componentes
        removeActiveClassForComponents();

        //Reemplaza artificio para modulo principal
        mainModule = buildAttrDataJSForComponent(rootModule, config.COMPONENT_MODULE, oCcomponentSidebar.main);
        //Convierte rootModule a objeto jquery
        rootModule = $.dataJS(rootModule);
        //Agrega clase activa a componente de modulo principal
        addActiveClassForComponent(mainModule);

        //Reemplaza artificio para sub modulo principal
        subModule = buildAttrDataJSForComponent(mainModule, config.COMPONENT_MODULE, oCcomponentSidebar.sub_main);
        //Agrega clase activa a componente de sub modulo principal
        addActiveClassForComponent(subModule);

        //Reemplaza artificio para seccion de modulo
        sectionModule = buildAttrDataJSForComponent(subModule, config.COMPONENT_MODULE, oCcomponentSidebar.section);
        //Agrega clase activa a componente de seccion de modulo
        addActiveClassForComponent(sectionModule);

        //Reemplaza artificio para sub seccion de modulo
        subSectionModule = buildAttrDataJSForComponent(sectionModule, config.COMPONENT_MODULE, oCcomponentSidebar.sub_section);
        //Agrega clase activa a componente de sub seccion de modulo
        addActiveClassForComponent(subSectionModule);
    }

    //Valida existencia de parametro de configuracion
    function setParameterConfigurationSidebar(parameter) {
        //Valida que parametro tenga valor
        if (typeof parameter !== 'undefined' && parameter !== null) {
            return parameter;
        }
        return null;
    }

    //Borra clase active a componentes de sidebar
    function removeActiveClassForComponents() {
        //Elimina clase active de componentes activos
        rootMenu.find(config.COMPONENT_ACTIVE).removeClass(config.CLASS_ACTIVE);
    }

    //Contruye nombre de atributo data js
    function buildAttrDataJSForComponent(parentComponent, configRoot, nameAttr) {
        var attrDataJS = "", component, configComponent;
        //Valida que nombre de atributo tenga valor
        if (typeof nameAttr !== 'undefined' && nameAttr !== null) {
            //Asigna copia de configuracion a variable
            configComponent = configRoot;
            //Asigna nombre de componente padre al nuevo
            component = parentComponent;
            //Concatena con nueva configuracion y el nombre de atributo
            attrDataJS = component.concat(configComponent.replace('{{component}}', nameAttr));
        }
        return attrDataJS;
    }

    //Agrega clase activa a componente
    function addActiveClassForComponent(nameDataJS) {
        var component;
        //Valida que modulo root tenga valor
        if (typeof rootModule !== 'undefined' && rootModule !== null) {
            //Almacena componente encontrado
            component = rootModule.find('[data-js="'.concat(nameDataJS).concat('"]'));
            //Encuentra componente de sub seccion de modulo actual y asigna clase activa
            component.addClass(config.CLASS_ACTIVE);
            //Valida que componente tenga clase treeview para forzar cambiar de posicion tick
            if (component.hasClass(config.CLASS_TREEVIEW)) {
                //Agrega clase menu-open para cambiar posicion de tick
                component.addClass(config.CLASS_MENU_OPEN);
            }
        }
    }

    return {
        activeSidebar: mAtiveSidebar
    };
});


