define(['jquery', 'progressbar'], function($, ProgressBar) {

    function ProgressBarUtil(id, options) {

		var progressbar;

		//Valida existencia de objeto ProgressBarUtil
        if (!(this instanceof ProgressBarUtil)) {
            throw new TypeError("ProgressBarUtil constructor cannot be called as a function.");
        }

		//Construye opciones para progress bar
        function build() {
            //Valida si existen opciones como parametro
			if(typeof options === 'undefined' || options === null){
				options = {};
			}
        }

        //Crea objeto para progress bar
		function create(){
			progressbar = new ProgressBar.Line(id, options);
		}

		//Metodo interno para construir y crear progress bar
        this.buildAndCreate = function() {
            build();
            create();
        };

		//Metodo interno para animar progress bar
		this.animate = function(value){
			progressbar.animate(value);
		};

		//Metodo interno para reanimar progress bar
		this.reAnimate = function(value){
			progressbar.animate(0, {
                duration: 300
            }, function() {
					progressbar.animate(value);
				  }
			);
		}
    }

    return ProgressBarUtil;
});
