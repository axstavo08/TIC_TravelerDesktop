/**
 * Project Name : smartflex-client 
 * Created: 21/03/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

define(['jquery', 'stringsUtil',
	'moment-with-locales', 'datepicker-with-locales'
], function($, stringsUtil, moment) {
	
    function MonthCalendar(component, validate, options) {
		
		var language = 'es', calendarMonth, validParam,
			parameters = {'date': null, 'numMonth': null, 'month': null, 
						'year': null, 'year_month': null,'outOfLimit': null},
			oLimitMonth = {'start': null, 'end': null};
		
		//Establece objeto momento a locale spanish
		moment.locale(language);
		
		//Valida que objeto sea de tipo MonthCalendar
		if (!(this instanceof MonthCalendar)) {
            throw new TypeError("MonthCalendar constructor cannot be called as a function.");
        }
		
		//Actualiza parametros de calendario de mes
		function setMonth(date) {
			var momentDate = moment(date);
			//Actualiza parametros de calendario de mes
			parameters.date = momentDate.format('DD/MM/YYYY');
			parameters.numMonth = momentDate.format('M');
			parameters.month = stringsUtil.labelToCapitalLetter(momentDate.format('MMMM'));
			parameters.year = momentDate.format('YYYY');
			parameters.year_month = momentDate.format('YYYY').concat(stringsUtil.paddingZeros(momentDate.format('M'), 2));
			parameters.outOfLimit = false;
			calendarMonth.datepicker('update', date);
		}
		
		//Construye calendario de mes
		function build(){
			//Asigna valor a variable para validacion de jquery
			validParam = validate;
			//Valida si existen opciones como parametro
			if(typeof options === 'undefined' || options === null){
				//Define opciones por defecto para calendario de mes
				options = {
					autoclose: true,
					forceParse: true,
					startDate: getStartMonth(),
					endDate: getDatePrevFinalMonth(),
					startView: 1, //inicia con vista de mes
					minViewMode: 1, //minimo vista de mes
					maxViewMode: 2, //maximo vista de anio
					language: language,
					format: {
						toDisplay: function (date, format, language) {
							var momentDate = moment(new Date(date.getFullYear(), date.getMonth(), date.getDate()+1)), isOK;
							//Valida parametros de calendario de mes
							if(parameters.year_month !== null){
								//Valida calendario de mes
								validateMonth(momentDate);
								//Llama a metodo para activar validacion de jquery
								activeJqueryValidation();
								//Valida que valor de fecha este dentro del limite establecido
								if(!parameters.outOfLimit){
									component.removeClass('input-danger-cust');
									return parameters.month.concat(' de ').concat(parameters.year);
								} else {
									component.addClass('input-danger-cust');
									return "Fuera de limite";
								}
							} else {
								component.addClass('input-danger-cust');
								return "Error en fecha";
							}
						},
						toValue: function (date, format, language) {}
					},
					templates: {
						leftArrow: '<i class="fa fa-chevron-left"></i>',
						rightArrow: '<i class="fa fa-chevron-right"></i>'
					},
					container: '#contMonthCalendar',
				};
			}
		}
		
		//Crea calendario de mes
		function create(){
			calendarMonth = component.datepicker(options)
							.on("changeMonth", function(e) {
								console.log("change");
								setMonth(e.date);
							});
		}
		
		//Valida calendario de mes
		function activeJqueryValidation(){
			//Valida activacion de parametro para validacion
			if(typeof validParam !== 'undefined' && validParam !== null){
				if(validParam) {
					calendarMonth.valid();
				}
			}
		}
		
		//Metodo para validar parametros de calendario de mes
		function validateMonth(date) {
			//Valida que fecha este en el rango de la fecha limite inicial
			if(date.isBefore(oLimitMonth.start)){
				parameters.outOfLimit = true;
			}
			//Valida que fecha este en el rango de la fecha limite final
			if(date.isAfter(oLimitMonth.end)){
				parameters.outOfLimit = true;
			}
		}
	
		//Obtiene mes inicial
		function getStartMonth(){
			//Inicia variable con primer mes del anio 2018
			var start = new Date(2018, 0, 1);
			//Almacena como objeto fecha en variable global de limite
			oLimitMonth.start = moment(start);
			return start;
		}
		
		//Obtiene mes final previo al mes actual
		function getDatePrevFinalMonth(){
			//Obtiene fecha y fecha con un mes anterior al mes actual
			var date = new Date(), end = new Date(date.getFullYear(), date.getMonth() - 1, 1);
			//Almacena como objeto fecha en variable global de limite
			oLimitMonth.end = moment(end);
			return end;
		}
	
		//Inicializa calendario de mes
		function initializeCalendarMonth(){
			var finalDate;
			//Obtiene mes anterior al mes actual
			finalDate = getDatePrevFinalMonth();
			//Actualiza calendario de mes
			calendarMonth.datepicker('setDate', finalDate);
			setMonth(finalDate);
		}
		
		//Metodo interno que construye y crea objeto calendario de mes
		this.buildAndCreate = function() {
            //Construye opciones
			build();
			//Crea objeto calendario de mes
            create();
			//Llama a metodo para inicializar calendario de mes
			initializeCalendarMonth();
        };
		
		//Metodo interno que devuelve parametros de calendario de mes actual
		this.getParameters = function() {
            return parameters;
        };
		
		//Metodo interno que devuelve objeto creado de calendario de mes
		this.getObject = function(){
			return calendarMonth;
		}
    }
    return MonthCalendar;
});