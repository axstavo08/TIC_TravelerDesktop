define(['jquery', 'select2'], function($) {

    function Select2Cascade(parent, child, url, options) {
        var afterActions = [];

        // Register functions to be called after cascading data loading done
        this.then = function(callback) {
            afterActions.push(callback);
            return this;
        };
        parent.on('select2:select', function(e) {
            child.prop("disabled", true);
            child.val(null).trigger('change');
            child.select2('destroy').select2({
                theme: "bootstrap",
                language: "es",
                placeholder: options.placeholder,
                allowClear: options.allowClear,
                ajax: {
                    url: url.replace(':parentId:', $(this).val()),
                    dataType: 'json',
                    processResults: options.processResults
                }
            });
            child.prop("disabled", false);
            afterActions.forEach(function(callback) {
                callback(parent, child, items, options);
            });
        });
    }

    return Select2Cascade;
});