/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 24/03/2017
 * @author John Portella <C16915>
 * @version 1.0
 */

define(['jquery'], function($) {
    var removeByAttr, assignObject, clone, compare, toString;

    //Eliminar un elemento por atributo
    removeByAttr = function(arr, attr, value) {
        var i = arr.length;
        while (i--) {
            if (arr[i] && arr[i].hasOwnProperty(attr) && (arguments.length > 2 && arr[i][attr] == value)) {
                arr.splice(i, 1);
            }
        }
        return arr;
    };

    /**
     * Asigna un valor a un elemento en string de un objecto
     * @param {type} obj
     * @param {type} prop
     * @param {type} value
     * @returns {undefined}
     */
    assignObject = function(obj, prop, value) {
        var pat = /\[[\d]+\]/, pat2 = /\[([^)]+)\]/, e, matches;

        if (typeof prop === "string")
            prop = prop.split(".");

        if (prop.length > 1) {
            e = prop.shift();

            if (pat.test(e)) {
                matches = pat2.exec(e);
                prop.unshift(matches[1]);
                prop.unshift(matches['input'].replace(matches[0], ''));
                e = prop.shift();
            }

            assignObject(obj[e] =
                    Object.prototype.toString.call(obj[e]) === "[object Object]"
                    ? obj[e]
                    : {},
                    prop,
                    value);
        } else {
            e = prop[0];
            if (pat.test(e)) {
                matches = pat2.exec(e);
                prop.unshift(matches[1]);
                prop.unshift(matches['input'].replace(matches[0], ''));
                e = prop.shift();
                assignObject(obj[e] =
                        Object.prototype.toString.call(obj[e]) === "[object Object]"
                        ? obj[e]
                        : {},
                        prop,
                        value);
            } else {
                obj[prop[0]] = value;
            }
        }
    };

    /**
     * Clona el objeto
     * @param {type} obj
     * @returns {clone.obj}
     */
    clone = function(obj) {
        if (null === obj || "object" !== typeof obj)
            return obj;
        var copy = obj.constructor(), attr;
        for (attr in obj) {
            if (obj.hasOwnProperty(attr))
                copy[attr] = obj[attr];
        }
        return copy;
    };

    /**
     * Ordenamiento de los options
     * @param {type} a
     * @param {type} b
     * @returns {Number}
     */
    compare = function(a, b) {
        if (a.codigo < b.codigo)
            return -1;
        if (a.codigo > b.codigo)
            return 1;
        return 0;
    };

    /**
     * Convierte un objeto a string (solo variables string)
     * @param {type} obj
     * @returns {String}
     */
    toString = function(obj) {
        var str = "", x;
        if (obj !== undefined) {
            for (x in obj) {
                if (str != "") {
                    str += "&";
                }
                str += x + "=" + obj[x];
            }
        }
        return str;
    };

    return {
        removeByAttr: removeByAttr,
        assignObject: assignObject,
        clone: clone,
        compare: compare,
        toString: toString
    };
});