/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 24/11/2017
 * @author John Portella <C16915>
 * @version 2.0
 */

define([
    'bootbox-def',
    'i18n!js/nls/imessages',
    'jquery-circle-progress'], function(bootbox, imessages) {
    function PageLoad(totalRequests) {
        var eAjaxComplete, requestCount = {all: totalRequests, loaded: 0};

        if (!(this instanceof PageLoad)) {
            throw new TypeError("PageLoad constructor cannot be called as a function.");
        }

        /**
         * Oculta todo rastro del circle progress         
         * @returns {undefined}
         */
        function hide() {
            $("#circle-progress").hide();
            $("#circle-progress").remove();
            $("#block-page").addClass("hide");
            $("#block-page").remove();
            $("body").removeClass("scroll-hide");
            $(document).unbind("ajaxComplete.pageLoad");
        }

        /**
         * Creacion del mensaje de error 
         * @returns {undefined}
         */
        function errorMessage() {
            bootbox.dialog({
                message: imessages.global.error.default,
                closeButton: false,
                buttons: {
                    goBack: {
                        label: imessages.global.redirect.goBack,
                        callback: function() {
                            window.history.back();
                        }
                    },
                    goHome: {
                        label: imessages.global.redirect.goHome,
                        callback: function() {
                            window.location.href = CONTEXT_PATH;
                        }
                    }
                }
            });
            $(".modal-backdrop").css({
                'opacity': '0.9',
                'filter': 'alpha(opacity=90)'
            });
        }

        if (totalRequests === 0) {
            hide(true);
        }

        $('#circle-progress').circleProgress({
            value: 0.01,
            fill: {gradient: ['#ff1e41', '#ff5f43']}
        }).on('circle-animation-progress', function(event, progress, stepValue) {
            $(this).find('strong').html(Math.round(100 * stepValue) + '<i>%</i>');
        });

        function updateProgress() {
            var progressPerc = requestCount.loaded / requestCount.all;
            $('#circle-progress').circleProgress('value', progressPerc);
            if (requestCount.loaded === requestCount.all) {
                setTimeout(function() {
                    hide(true);
                    $.dataJS('sectionContent').triggerHandler("endPageLoad");
                }, 900);
            }
        }

        eAjaxComplete = function(event, xhr, settings) {
            if (xhr.status === 200) {
                requestCount.loaded = requestCount.loaded + 1;
                updateProgress();
            } else {
                hide();
                errorMessage();
            }
        };

        $(document).bind("ajaxComplete.pageLoad", eAjaxComplete);
    }
    return PageLoad;
});