/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Project Name : smartflex-client 
 * Created: 12/10/2017
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

define(['jquery', 'moment', 'daterangepicker'], function($, moment) {

    function DateRPResp(el, options) {
        var daterangepicker,
                opts,
                callback,
                formatDate = 'DD/MM/YYYY',
                startDate = moment().subtract(7, 'days').format(formatDate),
                endDate = moment().format(formatDate),
                defaultOptions = {
                    locale: {
                        format: formatDate,
                        cancelLabel: 'Cancelar',
                        applyLabel: 'Aplicar',
                        fromLabel: 'Desde',
                        toLabel: 'A',
                        daysOfWeek: ['Dom', 'Lun', 'Mar', 'Mie', 'Jue', 'Vie', 'Sab'],
                        monthNames: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre',
                            'Octubre', 'Noviembre', 'Diciembre']
                    },
                    "opens": "center",
                    initEmpty: false
                };

        if (!(this instanceof DateRPResp)) {
            throw new TypeError("DateRPResp constructor cannot be called as a function.");
        }

        function build() {            
            if (options === undefined) {
                options = {singleDatePicker: false};
            }            
            //Asigna opciones a variable
            if (options.singleDatePicker) {
                opts = {
                    startDate: moment()
                };
                $.extend(opts, defaultOptions, options);                
                //Asigna funcion callback para fecha
                callback = function(start, end) {
                    startDate = start.format(formatDate);
                };
            } else {
                opts = {
                    startDate: startDate,
                    endDate: endDate
                };
                $.extend(opts, defaultOptions, options);
                //Asigna funcion callback para fecha inicio y fecha fin
                callback = function(start, end) {
                    startDate = start.format(formatDate);
                    endDate = end.format(formatDate);
                };
            }            
            //Trigger antes de mostrar daterangepicker
            el.on('show.daterangepicker', function(ev, picker) {
                //Llama a metodo para encajar posicion de daterangepicker
                fitResponsive(picker);
            });
            //Trigger antes de mostrar calendario de daterangepicker
            el.on('showCalendar.daterangepicker', function(ev, picker) {
                //Llama a metodo para encajar posicion de daterangepicker
                fitResponsive(picker);
            });
        }

        /*Corrige posicion de daterangepicker segun ancho de pantalla*/
        function fitResponsive(picker) {
            if ($(window).width() >= 992) {
                picker.opens = "center";
            } else {
                picker.opens = "left";
            }
        }

        function create() {
            //Establece rango inicial de input
            if(opts.singleDatePicker){
                el.val(startDate);
            }else{
                el.val(startDate + ' - ' + endDate);
            }            
            //Crea daterange picker
            daterangepicker = el.daterangepicker(opts, callback);
            //condicion de inicializacion
            if(opts.initEmpty){
                el.val("");
            }
        }

        this.buildAndCreate = function() {
            build();
            create();
        };

        this.getHourParams = function() {
            var hourParams = {'startDate': startDate, 'endDate': endDate};
            return hourParams;
        };
    }
    return DateRPResp;
});