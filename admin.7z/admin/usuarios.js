var tablaUsuarios;
var roles = [];
var privilegios = [];
var rolesAct = [];
var privilegiosAct = [];
var rolesDispo = [];
var privilegiosDispo = [];

var formUsuario = $('form[name="usuarioPermisos"]');
var inputRoles = $(formUsuario).find('input[name="roles"]');
var inputPrivilegios = $(formUsuario).find('input[name="permisosEsp"]');

function initUsuariosEvent(){
    obtenerRolesyPrivilegios();
    
    inicializarTabla();    
    inicializarEventosUsuario();    
    inicializarInputsEsp();           
    modoUsuario('nuevo');
}

function inicializarTabla(){
    
    columns = [
            { "bSortable":true }, 
            { "bSortable":true}, 
            { "bSortable":true },
            { "bSortable":true },
            { "bSortable":true  },           
            { "bSortable":false, "bSearchable": false, "sClass": "text-center"}
        ];
    
    tablaUsuarios = $('#tablaUsuarios').dataTable(
        {
            "bAutoWidth":false,
            "oLanguage": datatableTextSpanish(),            
            "aoColumns": columns
        }
    );
    
     $('#tablaUsuarios tbody tr').on( 'click', 'td', function () {
        
        if(!$(this).hasClass("usuario_estado")){
                        
            var tr = $(this).closest("tr");            
            if ( tr.hasClass('selected') ) {                
                modoUsuario('nuevo');
            }else {                
                modoUsuario('existente', tr);
            }
        }                  
    });
}

function inicializarEventosUsuario(){    
    
    /*Detecta cambio de estado de un usuario de la tabla*/
    $(".toggle-group").click(function() {                     
        var checkbox = $(this).prev();                       
        var id = checkbox.closest( "tr" ).attr('id');         
        estado = checkbox.prop('checked');            
        actualizarEstado(checkbox, id, !estado);           
    });
    
    /*Cancela el uso del formulario como submit*/
    $('form[name="usuarioPermisos"]').submit(function(e){
        return false;
    });
    
    /*validar los botones del formulario*/
    $('.buttons-form-user').click(function(){
        
        var id = $.trim(formUsuario.find('input[name="info.id"]').val());
        
        if( $(this).attr("name") === 'submitUpd' ){            
            limpiarFormUsuario('error');
            actualizarInfoUsuario(id, formUsuario);
        }else if( $(this).attr("name") === 'submitLoad' ){              
            modoUsuario('existente', null, id);
        }else if( $(this).attr("name") === 'submitNuevo' ){  
            modoUsuario('nuevo');            
        }else if( $(this).attr("name") === 'submitCrear' ){  
            crearUsuario(formUsuario);            
        }else if( $(this).attr("name") === 'submitRolAdd' ){              
            actualizarPermisosInput( $('#select-roles-dispo').val(), true, true);
        }else if( $(this).attr("name") === 'submitPrivilegioAdd' ){  
            actualizarPermisosInput( $('#select-privilegios-dispo').val(), true, false);
        }else if( $(this).attr("name") === 'submitLimpiar' ){  
            modoUsuario('nuevo');            
        }else if( $(this).attr("name") === 'submitGeneratePswd' ){  
            formUsuario.find('input[name="pwd"]').val(randomPassword(12));            
        }else if( $(this).attr("name") === 'submitCambiarPswd' ){  
            cambiarPwd(id);
        }
        else if( $(this).attr("name") === 'submitRefrescar' ){  
            location.reload();
        }       
        
    });    
}

function inicializarInputsEsp(){
    inputRoles.tagsinput({
        itemValue: 'id',
        itemText: 'text',
        maxTags: 10
    });
    
    inputRoles.on('itemRemoved', function(event) {
        actualizarPermisosInput(event.item.id,false,true);
    });
    
    $('#select-roles-dispo').selectize({
        create: true,
        valueField: 'id',
        labelField: 'text',
        sortField: 'text',	    
        options: convertirObjToData(roles)
    });
    
    inputPrivilegios.tagsinput({
        itemValue: 'id',
        itemText: 'text',
        maxTags: 10
    });
    
    inputPrivilegios.on('itemRemoved', function(event) {
        actualizarPermisosInput(event.item.id,false,false);
    });
    
    $('#select-privilegios-dispo').selectize({
        create: true,
        valueField: 'id',
        labelField: 'text',
        sortField: 'text',	    
        options: convertirObjToData(privilegios)
    });
}

function obtenerRolesyPrivilegios(){
    obtenerRoles();
    obtenerPrivilegios();
}

function modoUsuario(opcion, tr, id){
    
    if(opcion === 'nuevo'){
        
        limpiarFormUsuario();
        
        /*titulo*/
        $('#title-user').text("Nuevo Usuario");
        
        /*botones*/
        $('button[name="submitLimpiar"]').show();
        $('button[name="submitCrear"]').show();
        $('button[name="submitNuevo"]').hide();
        $('button[name="submitLoad"]').hide();
        $('button[name="submitUpd"]').hide();        
        $('button[name="submitRefrescar"]').hide(); 
        //$('button[name="submitGeneratePswd"]').hide(); 

        /*tabla*/
        tablaUsuarios.$('tr.selected').removeClass('selected'); 
        
        /*Roles y Privilegios disponibles*/
        rolesDispo = roles;
        privilegiosDispo = privilegios;
        rolesAct = [];
        privilegiosAct = [];
        
        actualizarPermisosInput(null,null,true);
        actualizarPermisosInput(null,null,false);    
        
        /*Pwd*/
        //$('.control-pswd').hide();
    }else if(opcion === 'existente'){
        
        limpiarFormUsuario();
        
        /*titulo*/
        $('#title-user').text("Usuario");
        
        /*botones*/
        $('button[name="submitLimpiar"]').hide();
        $('button[name="submitCrear"]').hide();
        $('button[name="submitNuevo"]').show();
        $('button[name="submitLoad"]').show();
        $('button[name="submitUpd"]').show();   
        $('button[name="submitRefrescar"]').hide();        
        //('button[name="submitGeneratePswd"]').show();
        
        /*tabla*/
        if(tr){
            tablaUsuarios.$('tr.selected').removeClass('selected');
            tr.addClass('selected');
            obtenerInfoUsuario( tr.attr("id") );
        }
        
        /*Recarga*/
        if(id){
            obtenerInfoUsuario(id);
        }
        
        /*Pwd*/
        //$('.control-pswd').show();
        
    }else if(opcion === 'creado'){
        /*titulo*/
        $('#title-user').text("Usuario Creado");
        
        /*botones*/
        $('button[name="submitLimpiar"]').hide();
        $('button[name="submitCrear"]').hide();
        $('button[name="submitNuevo"]').hide();
        $('button[name="submitLoad"]').hide();
        $('button[name="submitUpd"]').hide();   
        $('button[name="submitRefrescar"]').show(); 
        //$('button[name="submitGeneratePswd"]').hide();        
        
        /*Pwd*/
        //$('.control-pswd').show();        
    }
}


/* AJAX */

function actualizarEstado(obj, id, estado){
    
    var usuEstado = {'estado' : estado};
    
    $.ajax({
        type : 'PUT',
        url :  getURIComplete('/rest/admin/usuarios/' + id + '/estado'),
        data : JSON.stringify(usuEstado),
        async : true,
        contentType:'application/json',                
        crossDomain: true,
        cache: false        
    }).fail(function( jqXHR, textStatus, errorThrown ) {                        
        cambiarEstadoCheckBox(obj, estado, true);
        alert(getAlarmMessage("error.user.state"));        
    }).done(function(){
        cambiarEstadoCheckBox(obj, estado, false);
    });	   
}

function obtenerRoles(){
    $.ajax({
        type : 'GET',
        url :  getURIComplete('/rest/admin/permisos/roles') ,        
        async : false,
        contentType:'application/json',        
        crossDomain: true,        
        cache: false
    }).done(function(data) {	
        roles = data;
    }).fail(function( jqXHR, textStatus, errorThrown ) {
        alert(getAlarmMessage("error.general.complete", ['la carga de roles']));
    });
}

function obtenerPrivilegios(){
    $.ajax({
        type : 'GET',
        url :  getURIComplete('/rest/admin/permisos/privilegios') ,        
        async : false,
        contentType:'application/json',        
        crossDomain: true,        
        cache: false
    }).done(function(data) {	
        privilegios = data;
    }).fail(function( jqXHR, textStatus, errorThrown ) {
        alert(getAlarmMessage("error.general.complete", ['la carga de privilegios']));
    });
}

function obtenerInfoUsuario(id){        
    $.ajax({
        type : 'GET',
        url :  getURIComplete('/rest/admin/usuarios/' + id) ,        
        async : true,
        contentType:'application/json',        
        crossDomain: true,
        cache: false
    }).done(function(data) {	
        completarInfoUsuario(data);
    }).fail(function( jqXHR, textStatus, errorThrown ) {
        alert(getAlarmMessage("error.general.direct"));
    });
}

function actualizarInfoUsuario(id, usuInfoForm){    
    var usuInfoObject = usuInfoForm.serializeObjectBrackets();  
    usuInfoObject.roles = rolesAct;
    usuInfoObject.permisosEsp = privilegiosAct;
                
    $.ajax({
        type : 'PUT',
        url :  getURIComplete('/rest/admin/usuarios/' + id) ,
        data : JSON.stringify(usuInfoObject),
        async : true,
        contentType:'application/json',                
        crossDomain: true,
        cache: false        
    }).fail(function( jqXHR, textStatus, errorThrown ) {                        
        var mensajesError = JSON.parse(jqXHR.responseText);
        if(mensajesError.code === 'InvalidRequest'){
            $('form[name="usuarioPermisos"]').showErrorMessages(mensajesError.fieldErrors);
        } else{
            alert(getAlarmMessage("error.general.direct"));
        }       
    }).done(function(){
        alert(getAlarmMessage("success.update"));
    });
}

function crearUsuario(usuInfoForm){
    var usuInfoObject = usuInfoForm.serializeObjectBrackets();  
    usuInfoObject.roles = rolesAct;
    usuInfoObject.permisosEsp = privilegiosAct;
    console.log(usuInfoObject);
    
    modoUsuario('creado');
}

/* Support */

function cambiarEstadoCheckBox(obj, nuevoEstado, alMismo){    
    var estado = ( !alMismo && nuevoEstado) || ( alMismo && !nuevoEstado);    
    obj.bootstrapToggle( (estado) ? 'on' : 'off' );    
}

function completarInfoUsuario(data){    
    
    /*Llenar Form*/
    
    $('form[name="usuarioPermisos"]  input[name="info.id"] ').val(data.info.id);
    $('form[name="usuarioPermisos"]  input[name="info.usuario"] ').val(data.info.usuario);    
    $('form[name="usuarioPermisos"]  input[name="info.codigoC"] ').val(data.info.codigoC);    
    $('form[name="usuarioPermisos"]  input[name="info.nombres"] ').val(data.info.nombres);
    $('form[name="usuarioPermisos"]  input[name="info.apellidoPat"] ').val(data.info.apellidoPat);
    $('form[name="usuarioPermisos"]  input[name="info.apellidoMat"] ').val(data.info.apellidoMat);
    $('form[name="usuarioPermisos"]  input[name="info.email"] ').val(data.info.email);
    $('form[name="usuarioPermisos"]  input[name="info.direccion"] ').val(data.info.direccion);
    $('form[name="usuarioPermisos"]  input[name="info.area"] ').val(data.info.area);
           
    rolesDispo = obtenerRolesDispo(data.roles);
    privilegiosDispo = obtenerPrivilegiosDispo(data.roles, data.permisosEsp);
    rolesAct = data.roles;
    privilegiosAct = data.permisosEsp;
    
    actualizarPermisosInput(null,null,true);
    actualizarPermisosInput(null,null,false);
}

function limpiarFormUsuario(opcion){
    
    /*Limpieza general de Formulario*/
    if(!opcion){
        $('form[name="usuarioPermisos"]').clearElementsForm();
        
        /*Limpieza de Tag Inputs*/
        inputRoles.tagsinput('removeAll');
        inputPrivilegios.tagsinput('removeAll');
    }else{ 
        $('form[name="usuarioPermisos"]').clearElementsForm(opcion);
    } 
    
}


function obtenerRolesDispo(rolesImpl){
    var rolesDisponibles = [];    
        
    for(var i in roles){
        var a = $.grep(rolesImpl, function(e){
            return e.id === roles[i].id;
        });
        if(a.length === 0){            
            rolesDisponibles.push(roles[i]);
        }
    }
    return rolesDisponibles;
}

function obtenerPrivilegiosDispo(rolesImpl, privEspImpl){
    
    var privImpl = [];
    for(var i in privEspImpl){
        privImpl.push(privEspImpl[i]);
    }
    
    
    /* agrega los privilegios obtenidos de roles*/
    for(var i in rolesImpl){
        var privsRol = rolesImpl[i].permisos;
        for(var j in privsRol){
            privImpl.push(privsRol[j]);
        }
    }
    
    var privDisponibles = [];
    
    /*Descarta los priviligeos ya obtenidos*/
    for(var i in privilegios){
        var a = $.grep(privImpl, function(e){
            return e.id === privilegios[i].id;
        });
        if(a.length === 0){            
            privDisponibles.push(privilegios[i]);
        }
    }
    return privDisponibles;
}

/**
 * 
 * @param {type} objs
 * @returns {convertirObjToData.objsData|Array}
 */
function convertirObjToData(objs){
    var objsData = [];
    for(var i in objs){
        objsData.push( { 'id' : objs[i].id, 'text' : objs[i].nombre } );
    }
    return objsData;
}

function actualizarPermisosInput(id, esNuevo,esRol){
    if(esRol){
        if(id){
            var rolesActNuevo = [];
            if(esNuevo){
                rolesActNuevo = rolesAct;
                rolesActNuevo.push(obtenerPermisoObj(id,true));                                
            }else{                
                for(var i in rolesAct){
                    if(rolesAct[i].id !== parseInt(id)){
                        rolesActNuevo.push(rolesAct[i]);
                    }
                }                
            }    
            rolesDispo = obtenerRolesDispo(rolesActNuevo);                
            rolesAct = rolesActNuevo;                                
        }
        
        var rolesImpData = convertirObjToData(rolesAct);
        inputRoles.tagsinput('removeAll');
        for(var i in rolesImpData){
            inputRoles.tagsinput('add', rolesImpData[i]);
        }

        var selectize = $("#select-roles-dispo")[0].selectize;
        selectize.clear();
        selectize.clearOptions();
        selectize.load(function(callback) {
            callback(convertirObjToData(rolesDispo));
        });  
        
        /*Actualiza los privilegios*/
        var privilegiosActRoles = [];
        for(var i in rolesAct){
            var privAct = rolesAct[i].permisos;
            for(var j in privAct){                
                privilegiosActRoles.push(privAct[j]);
            }            
        }
        var privilegiosDispoNuevo = [];
        for(var i in privilegios){
            var existe = false;
            for(var j in privilegiosActRoles){
                if(privilegios[i].id === privilegiosActRoles[j].id){
                    existe = true;
                    break;
                }
            }
            if(!existe){
               privilegiosDispoNuevo.push(privilegios[i]); 
            }
        }
        privilegiosDispo = privilegiosDispoNuevo;
        
        var selectizePriv = $("#select-privilegios-dispo")[0].selectize;
        selectizePriv.clear();
        selectizePriv.clearOptions();
        selectizePriv.load(function(callback) {
            callback(convertirObjToData(privilegiosDispo));
        });  
        
    }else{
        if(id){
            var privilegiosActNuevo = [];
            if(esNuevo){
                privilegiosActNuevo = privilegiosAct;
                privilegiosActNuevo.push(obtenerPermisoObj(id,false));                                
            }else{                
                for(var i in privilegiosAct){
                    if(privilegiosAct[i].id !== parseInt(id)){
                        privilegiosActNuevo.push(privilegiosAct[i]);
                    }
                }                
            }    
            privilegiosDispo = obtenerPrivilegiosDispo(rolesAct, privilegiosActNuevo);                
            privilegiosAct = privilegiosActNuevo;     
        }
        
        var privImpData = convertirObjToData(privilegiosAct);
        inputPrivilegios.tagsinput('removeAll');
        for(var i in privImpData){
            inputPrivilegios.tagsinput('add', privImpData[i]);
        }

        var selectize = $("#select-privilegios-dispo")[0].selectize;
        selectize.clear();
        selectize.clearOptions();
        selectize.load(function(callback) {
            callback(convertirObjToData(privilegiosDispo));
        });
        
    }
}

function obtenerPermisoObj(id, esRol){
    if(esRol){
        for(var i in roles){
            if(roles[i].id === parseInt(id)){
                return roles[i];
            }
        }
        return null;
    }else{
        for(var i in privilegios){
            if(privilegios[i].id === parseInt(id)){
                return privilegios[i];
            }
        }
        return null;
    }
}

function randomPassword(length){
  chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
  pass = "";
  for(x=0;x<length;x++)
  {
    i = Math.floor(Math.random() * 62);
    pass += chars.charAt(i);
  }
  return pass;
}