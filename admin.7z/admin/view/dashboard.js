/**
 * Project Name : smartflex-client 
 * Created: 13/02/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

define([
    'pageLoad',
    'admin/util/resourceAdminDashboard',
    'admin/event/adminDashboardEvent',
    'admin/action/dashboard/main', 'admin/action/dashboard/onlineSessionUsers',
    'admin/ajax/dashboardAjax'
], function(PageLoad, resource, dashboardEvent, mainAction, onSesUsersAction, dashboardAjax) {

    //Variables utiles
    var s, publicDashboard, $data,
            dataChartNodes, dataCardsNodes, dataTablesNodes,
            listCharts = {}, listTables = {}, listCards = {};

    //Obtiene data para vista de dashboard
    function getDataForDashboard() {
        var state, $obj;
        //Valida modal abierto para obtener objeto jquery
        $obj = $.dataJS(($.dataJS('modalOnlineUsers').is(':visible')) ? 'bRefreshM' : 'bRefresh');
        console.log($obj);
        //Ejecuta ajax y obtiene data
        dashboardAjax.getDataDashboard().done(function(data, textStatus, jqXHR) {
            //Valida peticion exitosa y almacena data en variable global
            if (jqXHR["status"] === 200) {
                $data = data;
                //Llama a acciones de vista
                callViewActions();
            } else {
                $obj.triggerHandler('buildMessage', [resource['MESSAGES']['STATE']['WARNING']]);
            }
        }).fail(function(jqXHR, textStatus, errorThrown) {
            console.log(jqXHR);
            console.log(textStatus);
            console.log(errorThrown);
            $obj.triggerHandler('buildMessage', [resource['MESSAGES']['STATE']['ERROR']]);
        });
        return state;
    }

    //Valida existencia de objetos mensajes
    function validateAndRemoveMessages() {
        //Valida existencia de mensaje en dashboard
        if ($.dataJS('msgStateLoadDashboard').length > 0) {
            $.dataJS('msgStateLoadDashboard').empty();
        }
        //Valida existencia de mensaje en modal de usuarios en linea
        if ($.dataJS('msgStateLoadOnUsers').length > 0) {
            $.dataJS('msgStateLoadOnUsers').empty();
        }
    }

    //Llama a acciones para vista de dashboard
    function callViewActions() {
        //Inicializa accion general en dashboard
        mainAction.initialize(publicDashboard);
        //Inicializa accion de usuarios en linea
        onSesUsersAction.initialize(publicDashboard);
    }

    //Inicializa variables mutables
    function initializeMutableVariables() {
        return {
            'data': $data,
            'charts': listCharts,
            'tables': listTables,
            'cards': listCards
        };
    }

    //Inicializa vista inicial
    function initializeView() {
        //Obtiene recursos para asignar a variables
        dataChartNodes = resource['CHART'];
        dataCardsNodes = resource['CARD'];
        dataTablesNodes = resource['TABLE'];
    }

    //Inicializa eventos de acciones
    function initializeActionEvents() {
        //Inicializa eventos de accion general en dashboard
        mainAction.events(publicDashboard);
        //Inicializa eventos de accion de usuarios en linea
        onSesUsersAction.events(publicDashboard);
    }

    //Iniciaiza objeto publico para componentes de vista y eventos
    function initializePublicObject() {
        //Construye metodos a usar en eventos
        publicDashboard = {};
        publicDashboard['methods'] = {
            'view': getDataForDashboard,
            'components': initializeMutableVariables,
            'removeMessages': validateAndRemoveMessages
        };
        publicDashboard['utils'] = {
            'chartNodes': dataChartNodes,
            'cardNodes': dataCardsNodes,
            'tableNodes': dataTablesNodes
        };
    }

    //Inicializa eventos y alertas en vista
    function initializeEventsAndAlerts() {
        //Inicializa construccion de eventos y alarmas
        dashboardEvent.initialize(publicDashboard);
    }

    //Inicializa metodos
    function initializeMethods() {
        //Inicializa variables de vista
        initializeView();
        //Inicializa objeto publico para vista
        initializePublicObject();
        //Inicializa eventos de acciones de vista
        initializeActionEvents();
        //Inicializa eventos
        initializeEventsAndAlerts();
    }

    /*metodo publico*/
    function initialize() {
        //Inicializa metodos utiles
        initializeMethods();
        //Obtiene data de dashboard
        getDataForDashboard();
        //Configuracion
        s = this.settings;
        //Instanciando PageLoad con configuracion de la pagina
        new PageLoad(s.pageLoad);
    }

    return {
        initialize: initialize,
        settings: {
            'pageLoad': 1
        }
    };
});