/**
 * Project Name : smartflex-client 
 * Created: 26/02/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

define([
    //'pageLoad',
], function(/*PageLoad*/) {

    //Variables utiles
    var s;

    /*metodo publico*/
    function initialize() {
        //Configuracion
        s = this.settings;
        //Instanciando PageLoad con configuracion de la pagina
        //new PageLoad(s.pageLoad);
    }

    return {
        initialize: initialize,
        settings: {
            //'pageLoad': 1
        }
    };
});