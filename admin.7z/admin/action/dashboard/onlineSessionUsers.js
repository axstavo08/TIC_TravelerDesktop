/**
 * Project Name : smartflex-client 
 * Created: 20/02/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

define([
    'admin/util/resourceAdminDashboard', 'i18n!js/nls/imessages',
    'admin/builder/buildTable',
    'handlebars'
], function(resource, imessages, buildTable, Handlebars) {

    var oDashboard, listTables = {};

    //Construye componentes para accionde usuarios en linea
    function callBuilderComponents() {
        //Inicializa construccion de tablas
        listTables = buildTable.dashboard(oDashboard.methods.components().data, oDashboard.utils.tableNodes, listTables);
        //Une listado de componentes con listado general de dashboard
        $.extend(oDashboard.methods.components().tables, listTables);
    }

    //Inicializa eventos de accion
    function initializeActionEvents() {
        initializeButtons();
        initializeModals();
        initializeTriggers();
    }

    //Inicializa eventos de boton
    function initializeButtons() {
        //Construye evento para boton actualizar en modal
        $.dataJS('bRefreshM').on('click', function() {
            //Actualiza data y acciones
            oDashboard.methods.view();
        });

        //Construye evento para boton al dar click en cerrar sesion
        $.dataJS(resource['COMPONENT']['CLOSE_SESSION']).on('click', function() {
            var users = [], table = oDashboard.methods.components().tables[oDashboard.utils.tableNodes['nodeOnlineUsers']['name']],
                    rows_selected = table.getRowsSelectedCheckboxes(0);
            //Valida que boton se encuentre en estado habilitado
            if (!$.dataJS(resource['COMPONENT']['CLOSE_SESSION']).hasClass('disabled')) {
                //Recorre todas las opciones seleccionadas
                $.each(rows_selected, function(index, rowData) {
                    users.push(rowData);
                });
                console.log(users);
                $.ajax({
                    url: getURIComplete('rest/admin/dashboard/session'),
                    //dataType: "json",
                    data: {'users': users},
                    type: "POST",
                    cache: false,
                    async: true,
                    success: function(data, textStatus, jqXHR) {
                        console.log("Exito eliminando sesiones de usuarios");
                        console.log(data);
                        console.log(textStatus);
                        console.log(jqXHR);
                        table.removeRowsSelected();
                    },
                    error: function(request, status, error) {
                        console.error("Problemas eliminando sesiones de usuarios");
                        console.log(request);
                        console.log(status);
                        console.log(error);
                    }
                });
            }
            //Cancela cualquier accion en boton
            return false;
        });
    }

    //Construye mensaje de estado de carga
    function buildLoadMessage(state) {
        var context = {'style': resource['MESSAGES']['STYLE'][state], 'message': imessages['admin'][state]['default']},
        messageContainer = $.dataJS('msgStateLoadOnUsers'),
                source = $.dataJS(resource['MESSAGES']['TEMPLATE']).html(), template, html;
        //Valida existencia de mensaje en dashboard y en modal
        oDashboard.methods.removeMessages();
        //Renderiza objeto mensaje
        template = Handlebars.compile(source);
        html = template(context);
        messageContainer.html(html);
    }

    //Inicializa eventos de modal
    function initializeModals() {
        //Construye evento de triggers para modal de usuarios en linea
        $.dataJS('modalOnlineUsers').on('shown.bs.modal', function() {
            oDashboard.methods.components().tables[oDashboard.utils.tableNodes['nodeOnlineUsers']['name']].fixColumns();
        });

        $.dataJS('modalOnlineUsers').on('shown.bs.modal', function() {
            oDashboard.methods.components().tables[oDashboard.utils.tableNodes['nodeOnlineUsers']['name']].fixColumns();
        });
    }

    //Inicializa eventos de trigger
    function initializeTriggers() {
        //Evento al cargar data y estado sea diferente a satisfactorio
        $.dataJS('bRefreshM').on("buildMessage", function(event, state) {
            //Valida que exista estado de carga
            if (typeof state !== 'undefined' && state !== null) {
                //Construye mensaje de estado de carga
                buildLoadMessage(state);
            }
        });
    }

    function initialize(dashboard) {
        //Inicializa metodos y objetos de clase padre dashboard
        oDashboard = dashboard;
        //Llama a metodo para construir componentes
        callBuilderComponents();
    }

    return {
        initialize: initialize,
        events: initializeActionEvents
    };
});