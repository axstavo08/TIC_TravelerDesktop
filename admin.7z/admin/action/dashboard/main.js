/**
 * Project Name : smartflex-client 
 * Created: 20/02/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

define([
    'admin/util/resourceAdminDashboard', 'i18n!js/nls/imessages',
    'admin/builder/buildCard', 'admin/builder/buildChart',
    'handlebars'
], function(resource, imessages, buildCard, buildChart, Handlebars) {

    var oDashboard, listCharts = {}, listCards = {}, idTab = {'user_session': "tabUserSessions"};

    //Construye componentes para accionde usuarios en linea
    function callBuilderComponents() {
        //Inicializa construccion de charts
        listCards = buildCard.dashboard(oDashboard.methods.components().data, oDashboard.utils.cardNodes, listCards,
                resource['COMPONENT']['GROUP_CARD']['NAME'], resource['COMPONENT']['GROUP_CARD']['TEMPLATE']);
        //Inicializa construccion de charts
        listCharts = buildChart.dashboard(oDashboard.methods.components().data, oDashboard.utils.chartNodes, listCharts);
        //Une listado de componentes con listado general de dashboard
        $.extend(oDashboard.methods.components().charts, listCharts);
        $.extend(oDashboard.methods.components().cards, listCards);
    }

    //Inicializa eventos de accion
    function initializeActionEvents() {
        initializeButtons();
        initializeTriggers();
        initializeTabs();
    }

    //Inicializa eventos de boton
    function initializeButtons() {
        //Construye evento para boton actualizar
        $.dataJS('bRefresh').on('click', function() {
            //Actualiza data y acciones
            oDashboard.methods.view();
        });
    }

    //Construye mensaje de estado de carga
    function buildLoadMessage(state) {
        var context = {'style': resource['MESSAGES']['STYLE'][state], 'message': imessages['admin'][state]['default']},
        messageContainer = $.dataJS('msgStateLoadDashboard'),
                source = $.dataJS(resource['MESSAGES']['TEMPLATE']).html(), template, html;
        //Valida existencia de mensaje en dashboard y en modal
        oDashboard.methods.removeMessages();
        //Renderiza objeto mensaje
        template = Handlebars.compile(source);
        html = template(context);
        messageContainer.html(html);
    }

    //Inicializa eventos de trigger
    function initializeTriggers() {
        //Evento al crear grupo de cards para iniciar eventos de cada card
        $.dataJS('cardUserSessions').on("actionLinks", function(event) {
            //Construye evento para link a vista de solicitudes con estado pendiente
            $.dataJS("moreInfoPendRequests").on('click', function() {
                console.log("vista a solicitudes pendientes");
            });

            //Construye evento para link a vista de usuarios con estado activo
            $.dataJS("moreInfoActiveUsers").on('click', function() {
                console.log("vista a usuarios activos");
            });

            //Construye evento para link al modal de usuarios en linea
            $.dataJS("moreInfoOnlineUsers").on('click', function() {
                //Abre modal
                $.dataJS("modalOnlineUsers").modal('show');
            });
        });
        //Evento al cargar data y estado sea diferente a satisfactorio
        $.dataJS('bRefresh').on("buildMessage", function(event, state) {
            //Valida que exista estado de carga
            if (typeof state !== 'undefined' && state !== null) {
                //Construye mensaje de estado de carga
                buildLoadMessage(state);
            }
        });
    }

    //Inicializa eventos de tab
    function initializeTabs() {
        var objTab = $('#'.concat(idTab['user_session']).concat(' a'));
        //Evento de tab para charts
        objTab.click(function() {
            $(this).tab('show');
        });
        objTab.on('show.bs.tab', function() {
            var nAttr = $(this).attr('data-js');
            //Valida nombre de atributo
            if (nAttr === oDashboard.utils.chartNodes['nodeSessions']['tab_prop']) {
                oDashboard.methods.components().charts[oDashboard.utils.chartNodes['nodeSessions']['name']].reflow();
            } else if (nAttr === oDashboard.utils.chartNodes['nodeRecurrence']['tab_prop']) {
                oDashboard.methods.components().charts[oDashboard.utils.chartNodes['nodeRecurrence']['name']].reflow();
            }
        });
        objTab.on('shown.bs.tab', function() {
            var nAttr = $(this).attr('data-js');
            //Valida nombre de atributo
            if (nAttr === oDashboard.utils.chartNodes['nodeSessions']['tab_prop']) {
                oDashboard.methods.components().charts[oDashboard.utils.chartNodes['nodeSessions']['name']].reflowAndAnimate();
            } else if (nAttr === oDashboard.utils.chartNodes['nodeRecurrence']['tab_prop']) {
                oDashboard.methods.components().charts[oDashboard.utils.chartNodes['nodeRecurrence']['name']].reflowAndAnimate();
            }
        });
    }

    function initialize(dashboard) {
        //Inicializa metodos y objetos de clase padre dashboard
        oDashboard = dashboard;
        //Llama a metodo para construir componentes
        callBuilderComponents();
    }

    return {
        initialize: initialize,
        events: initializeActionEvents
    };
});