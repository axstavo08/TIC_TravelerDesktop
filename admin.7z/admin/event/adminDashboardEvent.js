/**
 * Project Name : smartflex-client 
 * Created: 14/02/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

define([
    'admin/util/resourceAdminDashboard', 'i18n!js/nls/imessages',
    'chart/chart', 'handlebars'
], function(resource, imessages, Chart, Handlebars) {

    var oDashboard;

    //Eventos para cambio de tamano de ventana de navegador
    function resize() {
        //Evento de trigger a ventana cuando cambia de tamano
        $(window).resize(function() {
            //Valida que variable de listado de charts tenga valor
            if (typeof oDashboard.methods.components().charts !== 'undefined') {
                //Reacomoda y reanima charts
                Chart.reflowAndReanimateCharts(oDashboard.methods.components().charts);
            }
            //Valida que variable de listado de tablas existan
            if (typeof oDashboard.methods.components().tables[oDashboard.utils.tableNodes['nodeOnlineUsers']['name']] !== 'undefined') {
                //Valida que modal este abierto para cerrarlo
                if ($.dataJS('modalOnlineUsers').is(':visible')) {
                    //Reacomoda columnas de tabla
                    oDashboard.methods.components().tables[oDashboard.utils.tableNodes['nodeOnlineUsers']['name']].fixColumns();
                }
            }
        });
    }

    //Eventos para uso de tiempos y realizar acciones
    function time() {
        //Construye alerta para actualizar componentes con data cada 10 minutos
        setInterval(function() {
            //Actualiza data y acciones
            oDashboard.methods.view();
        }, 600000);//600000 //10000
    }

    /*metodo publico*/
    function initialize(dashboard) {
        //Inicializa metodos y objetos de clase padre dashboard a usar en eventos
        oDashboard = dashboard;
        //Llama a eventos
        resize();
        time();
    }

    return {
        initialize: initialize
    };
});