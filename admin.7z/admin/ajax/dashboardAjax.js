/**
 * Project Name : smartflex-client 
 * Created: 13/02/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

/**
 * Metodos Ajax de Acciones de Dashboard Admin
 * @param {type} $
 * @returns {_L11.Anonym$3}
 */
define(['jquery'], function($) {

    var REST_DATA_DASHBOARD = "/smartflex/rest/admin/dashboard";

    //Construye objeto ajax para obtener data de dashboard
    function getDataDashboard() {
        return $.ajax({
            url: REST_DATA_DASHBOARD,
            contentType: "application/json",
            dataType: "json",
            type: "GET",
            async: true
        });
    }

    return {
        getDataDashboard: getDataDashboard
    };
});