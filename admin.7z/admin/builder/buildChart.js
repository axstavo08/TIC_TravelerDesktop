/**
 * Project Name : smartflex-client 
 * Created: 13/02/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

define([
    'chart-basic-structure',
    'chart/typeChart',
    'chart/chart',
    'objUtil',
    'admin/util/resourceAdminDashboard'
], function(ChartBasicStructure, typeChart, Chart, objUtil, resource) {

    var chartOptions, listSeries, serieStructure, listYAxis, yAxisStructure;

    /*Metodo publido para vista de dashboard*/
    function mDashboard(data, nodes, listCharts) {
        //Construye variables utiles para chart
        var iNode, node;
        //Recorre cantidad de nodos para construir charts
        for (iNode in nodes) {
            //Asigna a variable nodo actual de recorrido
            node = nodes[iNode];
            //Valida asignacion de nombre a tabs de charts
            if ($.dataJS(node['tab_prop']).attr('data-create') === resource['COMPONENT']['NO']) {
                //Cambia nombre de tab de chart
                $.dataJS(node['tab_prop']).text(data[node['name']]['title']);
                $.dataJS(node['tab_prop']).attr('data-create', resource['COMPONENT']['OK']);
            }
            /*Construye chart*/
            //Obtiene plantilla de chart basico e inicializa variables utiles para chart
            listSeries = [];
            listYAxis = [];
            chartOptions = objUtil.clone(ChartBasicStructure['BASIC']);
            serieStructure = objUtil.clone(ChartBasicStructure['SERIE']);
            yAxisStructure = objUtil.clone(ChartBasicStructure['YAXIS']);
            //Valida creacion de chart
            if ($('#'.concat(node['id'])).attr('data-create') === resource['COMPONENT']['NO']) {
                //Inserta valores para objeto xAxis
                chartOptions['_type'] = typeChart['LINE'];
                chartOptions['_title'] = data[node['name']]['chartProperties']['title'];
                chartOptions['xAxis']['categories'] = data[node['name']]['quantity']['dates'];
                //Inserta valores para construir objeto serie
                serieStructure['name'] = data[node['name']]['chartProperties']['nameSerie'];
                serieStructure['data'] = data[node['name']]['quantity']['data'];
                //Inserta a objeto serie a listado
                listSeries.push(serieStructure);
                //Inserta objeto serie a listado de series
                chartOptions['series'] = listSeries;
                //Inserta valores para construir objeto yAxis
                yAxisStructure['min'] = 0;
                yAxisStructure['_title'] = data[node['name']]['chartProperties']['nameYAxis'];
                //Inserta a objeto serie a listado
                listYAxis.push(yAxisStructure);
                //Inserta objeto yAxis a listado de yAxis
                chartOptions['_yAxis'] = listYAxis;
                console.log(node['id']);
                //Construye chart y guarda en listado de objetos chart para retorno
                listCharts[node['name']] = new Chart(node['id'], chartOptions);
                listCharts[node['name']].buildAndCreate();
                //Cambia estado a creado a padre de cards
                $('#'.concat(node['id'])).attr('data-create', resource['COMPONENT']['OK']);
            } else {
                //Inserta valores para construir objeto serie
                serieStructure['name'] = data[node['name']]['chartProperties']['nameSerie'];
                serieStructure['data'] = data[node['name']]['quantity']['data'];
                //Inserta a objeto serie a listado
                listSeries.push(serieStructure);
                //Inserta objeto serie a listado de series
                chartOptions['series'] = listSeries;
                //Actualiza series y xAxis
                listCharts[node['name']].updateSeries(chartOptions['series']);
                listCharts[node['name']].updateXAxis(data[node['name']]['quantity']['dates']);
            }
        }
        return listCharts;
    }

    return {
        dashboard: mDashboard
    };
});