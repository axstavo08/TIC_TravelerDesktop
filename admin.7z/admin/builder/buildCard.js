/**
 * Project Name : smartflex-client 
 * Created: 13/02/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

define([
    'admin/util/resourceAdminDashboard',
    'handlebars'
], function(resource, Handlebars) {

    var source, template, html;

    function createCards(context, nameGroupCards, templateGroupCards) {
        var groupCards = $.dataJS(nameGroupCards);
        source = $.dataJS(templateGroupCards).html();
        template = Handlebars.compile(source);
        html = template(context);
        groupCards.html(html);
        return groupCards;
    }

    /*metodo publico*/
    function mDashboard(data, nodes, listCards, nameGroupCards, templateGroupCards) {
        var iNode, node, context = {}, cardsType = [], creation = true;
        //Recorre cantidad de nodos para construir charts
        for (iNode in nodes) {
            //Asigna a variable nodo actual de recorrido
            node = nodes[iNode];
            //Valida creacion de card
            if ($.dataJS(nameGroupCards).attr('data-create') === resource['COMPONENT']['NO']) {
                //Construye data para card
                cardsType.push(
                        {
                            'box-class': node['box-class'],
                            'dataJsQAttr': node['quantity_attr'],
                            'Quantity_Pending_Requests': data[node['name']]['quantity'],
                            'dataJsTAttr': node['title_attr'],
                            'Title_Pending_Requests': data[node['name']]['title'],
                            'icon-card': node['icon-card'],
                            'created': resource['COMPONENT']['OK'],
                            'more-info': node['more-info']
                        }
                );
            } else {
                //Inhabilita opcion para crear cards
                creation = false;
                //Actualiza data a card
                $.dataJS(node['title_attr']).text(data[node['name']]['title']);
                $.dataJS(node['quantity_attr']).text(data[node['name']]['quantity']);
            }
        }
        //Valida para crear cards
        if (creation) {
            //Agrega listado de data para cards a contexto
            context['cardsType'] = cardsType;
            //Crea grupo de cards
            listCards[nameGroupCards] = createCards(context, nameGroupCards, templateGroupCards);
            //Inicializa eventos de links de cards
            $.dataJS(nameGroupCards).triggerHandler("actionLinks");
            //Cambia estado a creado a padre de cards
            $.dataJS(nameGroupCards).attr('data-create', resource['COMPONENT']['OK']);
            //Retorna valor de metodo llamado
            return listCards;
        }
    }

    return {
        dashboard: mDashboard
    };
});