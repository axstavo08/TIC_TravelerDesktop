/**
 * Project Name : smartflex-client 
 * Created: 13/02/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */

define([
    'admin/util/resourceAdminDashboard',
    'datatable-configuration', 'datatable/datatable', 'datatable/componentsDataTable'
], function(resource, configDataTable, DataTable, componentsDataTable) {


    /*metodo publico*/
    function mDashboard(data, nodes, listTables) {
        //Construye variables utiles para chart
        var iNode, node, tOptions, $table, vKey;
        //Recorre cantidad de nodos para construir charts
        for (iNode in nodes) {
            //Limpia opciones de tabla
            tOptions = {};
            //Asigna a variable nodo actual de recorrido
            node = nodes[iNode];
            //Asigna nombre de id a variable
            $table = $('#'.concat(node['id']));
            //Asigna nombre de nodo para llave en construccion de opciones
            vKey = iNode;
            //Valida existencia de tabla en vista
            if (DataTable.existsTable(node['id'])) {
                //Actualiza data de objeto tabla
                listTables[node['name']].updateRows(data[node['name']]);
                //Deselecciona todas las filas seleccionadas
                listTables[node['name']].deselectAllCheckboxes(0);
            } else {
                //Construye opciones en comun de tablas
                tOptions['oLanguage'] = componentsDataTable.language();
                tOptions['data'] = data[node['name']];
                tOptions['columns'] = node['columns'];
                //Valida llave unica de tabla
                if (vKey === 'nodeOnlineUsers') {
                    //Construye opciones personalizadas
                    tOptions['searching'] = false;
                    tOptions['ordering'] = true;
                    tOptions['preDrawCallback'] = function(settings) {
                        //Obtiene api
                        var api = this.api();
                        //Recorre celdas de api
                        api.cells(
                                //Recorre filas y deshabilita luego de validacion
                                api.rows(function(idx, data, node) {
                                    return (data['username'] === resource['USERNAME']) ? true : false;
                                }).indexes(),
                                0
                                ).checkboxes.disable();
                    };
                    tOptions['columnDefs'] = [{
                            'targets': 0,
                            'render': function(data, type, row, meta) {
                                //Valida si columna es visible
                                if (type === 'display') {
                                    //Obtiene estructura de checkbox para columna
                                    data = configDataTable['CHECKBOX']['STRUCTURE'];
                                }
                                return data;
                            },
                            'checkboxes': {
                                'selectRow': true,
                                'selectAllRender': configDataTable['CHECKBOX']['STRUCTURE'],
                                'selectAllCallback': function(nodes, selected, indeterminate) {
                                    //Valida seleccion o deseleccion en checkbox que selecciona todaa las columnas
                                    if (selected) {
                                        //Elimina clase de estilo deshabilirado para boton cerrar sesion
                                        $.dataJS(resource['COMPONENT']['CLOSE_SESSION']).removeClass('disabled');
                                    } else {
                                        //Agrega clase de estilo deshabilirado para boton cerrar sesion
                                        $.dataJS(resource['COMPONENT']['CLOSE_SESSION']).addClass('disabled');
                                    }
                                }
                            }
                        }];
                    tOptions['paging'] = true;
                    tOptions['lengthChange'] = false;
                    tOptions['info'] = true;
                    tOptions['autoWidth'] = true;
                    tOptions['pageLength'] = node['pageLength'];
                    tOptions['scrollX'] = true;
                    tOptions['select'] = configDataTable['SELECT']['TYPE']['MULTI'];
                    tOptions['order'] = node['order'];
                }
                //Instancia objeto de tabla
                listTables[node['name']] = new DataTable($table, tOptions);
                //Crea tabla
                listTables[node['name']].createAnGet();
            }
        }
        return listTables;
    }

    return {
        dashboard: mDashboard
    };
});