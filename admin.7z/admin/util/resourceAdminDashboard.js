/**
 * Project Name : smartflex-client 
 * Created: 14/02/2018
 * @author Gustavo Ramos <C24363>
 * @version 1.0
 */
define({
    'CHART': {
        'nodeSessions': {
            'name': "sessions", 'id': "g_sessions", 'tab_prop': 'tabSessions'
        },
        'nodeRecurrence': {
            'name': "recurrence", 'id': "g_recurrence", 'tab_prop': 'tabRecurrent'
        }
    },
    'CARD': {
        'nodePendingRequests': {
            'name': "requests", 'title_attr': "tPendingRequests", 'quantity_attr': 'qPendingRequests',
            'box-class': 'bg-aqua', 'icon-card': 'ion-android-document', 'more-info': "moreInfoPendRequests"
        },
        'nodeActiveUsers': {
            'name': "activeUsers", 'title_attr': "tActiveUsers", 'quantity_attr': 'qActiveUsers',
            'box-class': 'bg-green', 'icon-card': 'ion-person-add', 'more-info': "moreInfoActiveUsers"
        },
        'nodeOnlineUsers': {
            'name': "onlineUsers", 'title_attr': "tOnlineUsers", 'quantity_attr': 'qOnlineUsers',
            'box-class': 'bg-yellow', 'icon-card': 'ion-android-people', 'more-info': "moreInfoOnlineUsers"
        }
    },
    'TABLE': {
        'nodeOnlineUsers': {
            'name': "listOnlineUsers", 'id': "tOnlineUsers", 'pageLength': 5,
            'columns': [
                {'data': "username", 'className': "text-center", 'width': "5%"},
                {'data': "username", 'className': "text-center", 'width': "10%"},
                {'data': "names", 'className': "text-center", 'width': "15%"},
                {'data': "surnames", 'className': "text-center", 'width': "15%"},
                {'data': "division", 'className': "text-center", 'width': "10%"},
                {'data': "area", 'className': "text-center", 'width': "15%"},
                {'data': "email", 'className': "text-center", 'width': "10%"},
                {'data': "modules", 'className': "text-center", 'width': "20%"},
                {'data': "quantitySessions", 'className': "text-center", 'width': "10%"}
            ],
            'order': [1, 'asc']
        }
    },
    'USERNAME': "username",
    'COMPONENT': {
        'OK': "ok", 'NO': "no", 'CLOSE_SESSION': "closeSession",
        'GROUP_CARD': {
            'NAME': "cardUserSessions", 'TEMPLATE': "templateCards"
        }
    },
    'MESSAGES': {
        'STYLE': {
            'warning': "warning", 'error': "danger"
        },
        'STATE': {
            'WARNING': "warning", 'ERROR': "error"
        },
        'TEMPLATE': "templateStateLoadMsg"
    }
});

