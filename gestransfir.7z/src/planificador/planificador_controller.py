# encoding: utf-8
'''
Created on 16/6/2015

@author: C16915
'''
import sys, os
from common import Logger, ProjectUtils, messages
from planificador_enums import Action
from planificador_utils import PlanificadorUtils
from planificador_business import PlanificadorBusiness


class PlanificadorController(object):
    
    def __init__(self, params):
        #logger                
        self.logger     = (Logger(PlanificadorUtils.getSubprojectName(), self.__class__.__name__)).getLogger()
        self.loggerDev  = (Logger(PlanificadorUtils.getSubprojectName(), self.__class__.__name__, True)).getLogger()            
        #parameters
        action  = (params[0]).upper() if 0 < len(params) else None
        label   = (params[1]).upper() if 1 < len(params) else None
        fileName    = (params[2]).upper() if 2 < len(params) else None             
        #validar accion
        if action is None:
            self.__action = Action.list
        else:
            if action in Action.actionsValue():
                self.__action = Action.getEnum(action)
            else:
                PlanificadorUtils.insertLogWarning(self.logger, self.loggerDev, "FINALIZADO", "Acción no existente: " + action)
                ProjectUtils.printTerminalMessage("FINALIZADO", messages.NO_ACTION)                                               
                sys.exit()
        #validar etiqueta
        if self.__action <> Action.list:
            if label is None:
                PlanificadorUtils.insertLogWarning(self.logger, self.loggerDev, "FINALIZADO", "No se ingreso la etiqueta del job")
                ProjectUtils.printTerminalMessage("FINALIZADO", messages.NO_ACTION)                                               
                sys.exit()
            else:
                self.__label = label    
        #validar ruta de archivo
        if self.__action == Action.create:
            if fileName is None or not os.path.exists(fileName):
                PlanificadorUtils.insertLogWarning(self.logger, self.loggerDev, "FINALIZADO", "Ruta de archivo no existente o incorrecto")
                ProjectUtils.printTerminalMessage("FINALIZADO", messages.NO_ACTION)                                               
                sys.exit()          
            else:
                self.__file = fileName
        #redireccionamiento
        self.router()        
        
        
    def router(self):
        #inicializacion del business
        planificadorBusiness = PlanificadorBusiness()
        #mapeo de acciones
        if self.__action == Action.create:
            planificadorBusiness.createJob(self.__action, self.__label, self.__file)
            