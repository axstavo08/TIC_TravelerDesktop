# encoding: utf-8
'''
Created on 17/6/2015

@author: C16915
'''

JOB_NOT_FOUND = "Job no encontrado o multiplicado"
