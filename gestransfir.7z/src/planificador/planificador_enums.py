'''
Created on 17/6/2015

@author: C16915
'''

from enum import Enum

class Action(Enum):    
    
    create          = 'CREAR'
    list            = 'LISTAR'
    start           = 'INICIAR'    
    stop            = 'DETENER'
    delete          = 'ELIMINAR'
    log             = 'LOG'
    
    @classmethod        
    def actionsValue(cls):        
        return [(action[1]).value for action in cls.__members__.items()]
    
    @classmethod          
    def getEnum(cls, actionName):
        return ([action[1] for action in cls.__members__.items() if (action[1]).value == actionName])[0]