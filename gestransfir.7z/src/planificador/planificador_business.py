'''
Created on 17/6/2015

@author: C16915
'''

from planificador_service import PlanificadorService

class PlanificadorBusiness(object):
    
    def createJob(self, action, label, fileName):
        try:
            planificadorService = PlanificadorService()
            planificadorService.parserFileConfig(label, fileName)
        finally:
            pass