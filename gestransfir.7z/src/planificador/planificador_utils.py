'''
Created on 17/6/2015

@author: C16915
'''

from common import ProjectUtils

class PlanificadorUtils(object):
    
    @staticmethod   
    def getSubprojectName():   
        return "planificador"    
    
    '''
    LOG METHODS
    '''
   
    @staticmethod   
    def insertLogWarning(logger, loggerDev, status, message):   
        ProjectUtils.insertLogWarning(logger, loggerDev, "PLANIFICADOR", "ALERTA", status, message)
        
    @staticmethod       
    def insertLogInfo(logger, loggerDev, commandName, appStatus, status, level, message):
        newMessage = "[%s][%s][%s] %s" % (commandName, status, level, message)
        ProjectUtils.insertLogInfo(logger, loggerDev, "PLANIFICADOR", appStatus, "SIGUIENTE", newMessage)        
        print newMessage        
        
    @staticmethod
    def insertLogError(logger, sys_exc):
        ProjectUtils.insertErrorFileLog(logger, sys_exc)
        
    '''
    '''
    #@staticmethod
    #def getOptionValueConf():     