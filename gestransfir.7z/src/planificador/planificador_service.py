'''
Created on 17/6/2015

@author: C16915
'''
import ConfigParser
import planificador_messages as pmessages

class PlanificadorService(object):
    
    def parserFileConfig(self, label, fileName):
        config = ConfigParser.ConfigParser()
        config.read(fileName)
        #nombre de seccion
        sectionList = [section for section in config.sections() if (section).upper() == label]                        
        if len(sectionList) == 0 or len(sectionList) > 1:            
            raise Exception(pmessages.JOB_NOT_FOUND)
        section = sectionList[0]
        #informacion de la seccion
        auxList = [config.get(section, option) for option in config.options(section) if (option).upper() == 'TIPO']        
        type = auxList[0] if len(auxList) == 1 else None
        auxList = [config.get(section, option) for option in config.options(section) if (option).upper() == 'F_INICIO']          
        startDate = auxList[0] if len(auxList) == 1 else None
        auxList = [config.get(section, option) for option in config.options(section) if (option).upper() == 'F_INICIO']
        print startDate
        
    #def    