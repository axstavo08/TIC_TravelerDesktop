'''
Created on 15/8/2017

@author: C16915 - John Portella
'''

from lbs_business import LBSBusiness

class LBSController(object):

    def __init__(self):        
        self.__lbsBusiness = LBSBusiness()
    
    def load(self):
        self.__lbsBusiness.load()