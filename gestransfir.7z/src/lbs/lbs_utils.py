'''
Created on 16/8/2017

@author: C16915 - John Portella
'''

import time,os
from common import ProjectUtils

class LBSUtils(object):
            
    @staticmethod
    def getFileName():        
        fileName = 'LBS_aaaammdd.csv'
        return fileName.replace("aaaammdd", time.strftime("%Y%m%d"))
        
    @staticmethod
    def getLocalFilesDirectory():
        return os.path.join(ProjectUtils.getFilesDirectory(), 'lbs')
    
    @staticmethod
    def insertFileLogError(logger, sys_exc):
        ProjectUtils.insertErrorFileLog(logger, sys_exc)
    
    @staticmethod
    def insertLog(logger, loggerDev, status, message):
        newMessage = "[%s] %s" % (status, message)
        alarm = "INFO" if status == "REALIZADO" else "ERROR"
        ProjectUtils.insertLogInfo(logger, loggerDev, "LBS", alarm, status, newMessage)        
        print newMessage