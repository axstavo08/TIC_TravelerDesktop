'''
Created on 15/8/2017

@author: C16915 - John Portella
'''

from common import OracleDB, ProjectUtils

class LBSRepository(object):

    def __init__(self):
        self.__conn = OracleDB(ProjectUtils.envDB("oracle", "db_smart"))
        
    def getCells(self):
        return self.__conn.executeProcedureOUTCursor("PK_GTF_LBS.SP_CARGAR_CELDAS", [], False)