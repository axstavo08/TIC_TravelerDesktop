'''
Created on 15/8/2017

@author: C16915 - John Portella
'''
import os, csv
from lbs_utils import LBSUtils
from common import CSVUtils, PyFileTransfer

class LBSService(object):

    def createAndSendCSV(self, fileName, data):
        remoteDirectory = "/root/lbs"
        fileCSVDirectory = LBSUtils.getLocalFilesDirectory()
        CSVUtils.exportRecordsToCSV(os.path.join(fileCSVDirectory, fileName), data, None, ';', csv.QUOTE_NONE) 
        #Transferencia via SFTP
        t = PyFileTransfer('ftp_lbs')
        t.connection()
        t.put(fileName, remoteDirectory, fileCSVDirectory)
        t.disconnect()