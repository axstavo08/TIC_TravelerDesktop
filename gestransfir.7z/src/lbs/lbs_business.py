'''
Created on 15/8/2017

@author: C16915 - John Portella
'''
import sys
from lbs_repository import LBSRepository
from lbs_service import LBSService
from lbs_utils import LBSUtils
from common import DateUtils, Logger

class LBSBusiness(object):

    def __init__(self):
        #logger        
        self.logger = (Logger("lbs", self.__class__.__name__)).getLogger()
        self.loggerDev  = (Logger("lbs", self.__class__.__name__, True)).getLogger()
        #init
        self.__lbsService = LBSService()
        self.__lbsRepository = LBSRepository()
        
    def load(self):
        status = 'INICIO' #status inicial        
        startTime = DateUtils.now() #generar la hora de inicio     
        try:
            fileName = LBSUtils.getFileName()
            #obtencion de la data
            cells = self.__lbsRepository.getCells()
            cellsArray = cells['data']
            #Inicio y fin del csv
            totalCells = len(cellsArray)
            cellsArray.insert(0, ('BOF','') )
            cellsArray.append( ('EOF', totalCells, '' ) )
            #Creacion y envio del CSV 
            self.__lbsService.createAndSendCSV(fileName, cellsArray)
            status = 'REALIZADO'
        except Exception:
            status = 'FALLIDO'
            LBSUtils.insertFileLogError(self.loggerDev, sys.exc_info())
        finally:            
            endTime = DateUtils.now() #log de finalizacion del proceso
            message = "Inicio:%s Fin:%s" % (startTime.strftime('%d/%m/%Y %H:%M:%S'), endTime.strftime('%d/%m/%Y %H:%M:%S'))
            LBSUtils.insertLog(self.logger, self.loggerDev, status, message)
            