'''
Created on 7/5/2015

@author: C16915
'''

import os
from ConfigParser import ConfigParser

def read_db_config(section):
    parser = ConfigParser()
    
    filename = os.path.dirname(os.path.realpath(__file__))
    directoryArray = filename.rsplit(os.sep,3)
    filename = os.path.join(directoryArray[0], 'conf', 'database.ini')
    parser.read(filename)
    
    db={}
    if parser.has_section(section):
        items = parser.items(section)
        for item in items:
            db[item[0]] = item[1]
    else:
        raise Exception('{0} not found in the {1} file'.format(section, filename))
    return db
    