# -*- coding: utf8 -*-
'''
Created on 7/5/2015

@author: C16915
'''

import dbconfig
import cx_Oracle
import os

os.environ['NLS_LANG'] = 'SPANISH_SPAIN.WE8MSWIN1252'

class OracleDB(object):


    def __init__(self, dbName):
        dbConfig = dbconfig.read_db_config(dbName)
        
        self.__user = dbConfig['user']
        self.__pwd  = dbConfig['password']
        self.__ip   = dbConfig['host']
        self.__port = dbConfig['port']
        self.__sid  = dbConfig['database']
        
        self.__dsn  = self.__getDSN()
        self.__db   = self.__getConnection()
        self.__cursor = self.getCursor()
        
    def __getDSN(self):
        dsn = cx_Oracle.makedsn(self.__ip, self.__port, self.__sid)
        return dsn
        
    def __getConnection(self):
        db = cx_Oracle.connect(self.__user, self.__pwd, self.__dsn) 
        return db    
        
    def getCursor(self):
        curs = self.__db.cursor()
        return curs 
        
    def getDBVersion(self):
        return self.__db.version   
    
    def executeProcedureOUTCursor(self, procedureName, params = None, returnObject = True):
        if params is None:
            params = []                
        l_cur = self.__cursor.var(cx_Oracle.CURSOR)
        params.append(l_cur)                
        l_query = self.__cursor.callproc(procedureName, params)
        l_results = l_query[-1]
        if returnObject:
            objectsArray = []
            for row in l_results.fetchall():
                c = 0
                objectAux = {}
                for column in row:
                    objectAux[l_results.description[c][0]] = column
                    c += 1                
                objectsArray.append(objectAux)    
            return objectsArray
        else:                        
            return {'data': l_results.fetchall(), 'description': l_results.description}
    
    def callFunction(self, functionName, returnType, params = None):
        if params is None :
            result = self.__cursor.callfunc(functionName, returnType )
        else:
            result = self.__cursor.callfunc(functionName, returnType, params )
        return result            
    
    def executeProcedure(self, procedureName, params = None):                    
        self.__cursor.callproc(procedureName, params)
        

class OracleDBTrans(object):   
    
    def __init__(self, dbName):
        dbConfig = dbconfig.read_db_config(dbName)
        
        self.__user = dbConfig['user']
        self.__pwd  = dbConfig['password']
        self.__ip   = dbConfig['host']
        self.__port = dbConfig['port']
        self.__sid  = dbConfig['database']
                
        self.__dsn      = self.__getDSN()
        self.__db       = self.__getConnection()
        self.__cursor   = self.__db.cursor()
    
    def disconnect(self):        
        self.__db.close()
                            
    def __getDSN(self):
        dsn = cx_Oracle.makedsn(self.__ip, self.__port, self.__sid)
        return dsn
        
    def __getConnection(self):
        db = cx_Oracle.connect(self.__user, self.__pwd, self.__dsn) 
        return db    
        
    def getCursor(self):
        curs = self.__cursor
        return curs 
    
    def begin(self):
        self.__db.begin()
        
    def commit(self):
        self.__db.commit()  
        
    def rollback(self):
        self.__db.rollback()      
        
    def bulkInsertWithDict(self, table, columns, data):                
        query = "INSERT INTO $TABLE_NAME ($COLS_TABLE) VALUES ($COLS_DICT)"
        columnsTable = ",".join(a['ncol'] for a in columns)
        columnsDict  = ",".join(a['ndict'] for a in columns)
        query = query.replace("$TABLE_NAME", table)
        query = query.replace("$COLS_TABLE", columnsTable)
        query = query.replace("$COLS_DICT", columnsDict)        
        self.__cursor.executemany(query, data)        
    
    def insertWithDict(self, table, columns, data):
        query = "INSERT INTO $TABLE_NAME ($COLS_TABLE) VALUES ($COLS_DICT)"
        
        columnsTable = ",".join(a['ncol'] for a in columns)
        columnsDict  = ",".join(a['ndict'] for a in columns)
        
        query = query.replace("$TABLE_NAME", table)
        query = query.replace("$COLS_TABLE", columnsTable)
        query = query.replace("$COLS_DICT", columnsDict)        
        self.__cursor.execute(query, data)    
        
    def createTable(self, table, columns):
        
        query = "CREATE TABLE $TABLE_NAME ($COLUMNS)"         
        listColumns = []
        for col in columns:            
            if col['column_type'] == 'VARCHAR':
                if col.has_key('column_length'):                    
                    listColumns.append(col['column_name'] + ' VARCHAR2('+ str(col['column_length']) +')')
                else:
                    listColumns.append(col['column_name'] + ' VARCHAR2(70)')
            else:     
                listColumns.append(col['column_name'] + ' NUMBER')        
        query = query.replace('$TABLE_NAME', table)
        query = query.replace('$COLUMNS', ','.join(listColumns))                    
        self.__cursor.execute(query)        
    
    def dropTable(self, table):
        query = "DROP TABLE $TABLE_NAME"
        query = query.replace('$TABLE_NAME', table)            
        self.__cursor.execute(query)
        
    def clearTable(self, table):
        query = "DELETE FROM $TABLE_NAME"
        query = query.replace('$TABLE_NAME', table)            
        self.__cursor.execute(query)    
        
    def newColumnsTable(self, table, columns):
        query = "ALTER TABLE $TABLE_NAME ADD $NEW_COLUMN $TYPE"
        for col in columns:
            if col['column_type'] == 'VARCHAR':
                if col.has_key('column_length'):
                    typeCol = ' VARCHAR2('+ str(col['column_length']) +')'
                else:
                    typeCol = 'VARCHAR2(70)'
            else:     
                typeCol = 'NUMBER'
            
            queryCol = query.replace('$TABLE_NAME', table)
            queryCol = queryCol.replace('$NEW_COLUMN', col['column_name'])
            queryCol = queryCol.replace('$TYPE', typeCol)
            self.__cursor.execute(queryCol)
    
    def bulkUpdateWithDict(self, table, variables, data, constraints = []):
        v_variables     = [variable['column_name'] + '=' + variable['column_dict'] for variable in variables]        
        v_constraints   = [constraint['column_name'] + '=' + constraint['column_dict'] for constraint in constraints]
                                       
        query = "UPDATE $TABLE_NAME SET $COLS_TABLE $WHERE $CONSTRAINTS"
        query = query.replace("$TABLE_NAME", table)
        query = query.replace("$COLS_TABLE", ",".join(v_variables))
        if len(v_constraints) == 0:
            query = query.replace("$WHERE", "")
            query = query.replace("$CONSTRAINTS", "")
        else:
            query = query.replace("$WHERE", "WHERE")
            query = query.replace("$CONSTRAINTS", " AND ".join(v_constraints))    
        self.__cursor.executemany(query, data)
    
    def executeProcedureOUTCursor(self, procedureName, params = None, returnObject = True):
        if params is None:
            params = []                
        l_cur = self.__cursor.var(cx_Oracle.CURSOR)
        params.append(l_cur)                
        l_query = self.__cursor.callproc(procedureName, params)
        l_results = l_query[-1]
        if returnObject:
            objectsArray = []
            for row in l_results.fetchall():
                c = 0
                objectAux = {}
                for column in row:
                    objectAux[l_results.description[c][0]] = column
                    c += 1                
                objectsArray.append(objectAux)    
            return objectsArray
        else:                        
            return {'data': l_results.fetchall(), 'description': l_results.description}
        
                    