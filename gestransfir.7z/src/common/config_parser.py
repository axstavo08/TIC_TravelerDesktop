'''
Created on 8/5/2015

@author: C16915
'''

import os
from ConfigParser import ConfigParser

def singleton(cls):
    instances = {}
    def getinstance():
        if cls not in instances:
            instances[cls] = cls()
        return instances[cls]
    return getinstance

class ConfigUtils(object):
    
    @staticmethod
    def read_trasnfer_config(section):
        parser = ConfigParser()
        
        filename = os.path.dirname(os.path.realpath(__file__))
        directoryArray = filename.rsplit(os.sep,2)
        filename = os.path.join(directoryArray[0], 'conf', 'transfer.ini')
        parser.read(filename)
        
        transf={}
        if parser.has_section(section):
            items = parser.items(section)
            for item in items:
                transf[item[0]] = item[1]
        else:
            raise Exception('{0} not found in the {1} file'.format(section, filename))
        return transf
    
@singleton
class GlobalConfig:
    def __init__(self):
        self.environment = None    