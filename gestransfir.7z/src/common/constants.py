'''
Created on 8/5/2015

@author: C16915
'''

SEP_WIN='\\'
SEP_UNIX = '/'