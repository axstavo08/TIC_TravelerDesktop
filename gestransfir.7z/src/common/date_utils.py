# encoding: utf-8
'''
Created on 7/5/2015

@author: C16915
'''
from datetime import datetime, timedelta
from enum import Enum
import time
import cx_Oracle

class DateUtils(object):
    
    @staticmethod
    def getDatewithHourSinceNumber(number):
        if type(number).__name__ == 'int':
            number = str(number)
        
        number = number.ljust(10, '0')
            
        date = datetime(year=int(number[0:4]), month=int(number[4:6]), day=int(number[6:8]))
        date += timedelta(hours=int(number[8:10]))
        return date
    
    @staticmethod
    def getDateUntilDaySinceNumber(number):
        if type(number).__name__ == 'int':
            number = str(number)
        number = number.ljust(8, '0')
        
        date = datetime(year=int(number[0:4]), month=int(number[4:6]), day=int(number[6:8]))
        return date
            
    @staticmethod
    def getDatewithDaySinceNumber(number):
        if type(number).__name__ == 'int':
            number = str(number)
            
        date = datetime(year=int(number[0:4]), month=int(number[4:6]), day=int(number[6:8]))        
        return date
        
    @staticmethod
    def convertDateUntilHourToNumber(date):
        number = (date).strftime('%Y%m%d%H')
        return number    
    
    @staticmethod
    def convertDateUntilDayToNumber(date):
        number = (date).strftime('%Y%m%d')
        return number
    
    @staticmethod
    def convertTimestampToNumber(timestamp):
        return (datetime.fromtimestamp(timestamp)).strftime('%Y%m%d%H')
    
    @staticmethod
    def isValidDate(date, formatDate):
        try:
            if type(date) is int:
                date = str(date) 
            time.strptime(date, formatDate)
            return True
        except:
            return False
    
    @staticmethod    
    def addTime(date, dateType, amount ):
        if dateType == DateType.day:
            return date + timedelta(days=amount)
        elif dateType == DateType.hour:
            return date + timedelta(hours=amount)
    
    @staticmethod
    def getDateRange(startDate, endDate, dateType):
        dates = []
        if dateType == DateType.day:
            for n in range( int((endDate - startDate).days) + 1):
                dates.append(startDate + timedelta(n))
        return dates
    
    @staticmethod
    def datetime_range(start, end, delta):
        current = start
        if not isinstance(delta, timedelta):
            delta = timedelta(**delta)
        while current < end:
            yield current
            current += delta
               
    @staticmethod
    def now():
        return datetime.now();
class DateType(Enum):
    hour    = 'HOUR'
    day     = 'DAY'        