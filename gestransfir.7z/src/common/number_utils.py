'''
Created on 21/5/2015

@author: C16915
'''

class NumberUtils(object):
    
    @staticmethod
    def isNumeric(string):
        try:
            int(string)
            return True
        except ValueError:
            pass
        
        try:
            float(string)   
        except (TypeError, ValueError):
            pass
        return False
    
    @staticmethod                
    def toNumber(string):
        try:
            return int(string)            
        except ValueError:
            pass
        
        try:
            return float(string)            
        except (TypeError, ValueError):
            raise