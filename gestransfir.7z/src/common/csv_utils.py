# encoding: utf-8
'''
Created on 7/5/2015

@author: C16915
'''
import csv

class CSVUtils(object):
    
    @staticmethod
    def exportRecordsToCSV(filename, data, header=None, delimiter = ',', quoting = csv.QUOTE_ALL):
        try:
            outputFile = open(filename,'w') # 'wb'
            output = csv.writer(outputFile, quoting= quoting , lineterminator='\n', delimiter= ';')        
            cols = []            
            if header is not None:                
                for col in header:
                    # Si es tupla o string
                    if type(col).__name__ == 'tuple':
                        cols.append(col[0])
                    else:
                        cols.append(col)    
                output.writerow(cols)
            
            for row_data in data:
                output.writerow(row_data)                
            outputFile.close()
        except Exception as e:
            raise Exception(e)    