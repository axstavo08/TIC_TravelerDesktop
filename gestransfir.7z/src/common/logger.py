'''
Created on 5/5/2015

@author: C16915
'''
import os
import logging
from datetime import datetime


class Logger(object):
    
    __startedlevel = logging.DEBUG

    def __init__(self, projName, className, isDevLog = False):                    
        if projName == 'gestransfir':
            className = className.replace('.log','')             
            logger = logging.getLogger(projName)
            logger.setLevel(self.__startedlevel)        
            if not logger.handlers:            
                #directorio de logs            
                logginDirArray = (os.path.dirname(__file__)).rsplit(os.sep, 2)
                logginDir = os.path.join(logginDirArray[0], 'logs_dev')
                #general 
                file_name = os.path.join(logginDir, projName + '.log')
                formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')            
                #File log
                handler = logging.FileHandler(file_name)                        
                handler.setFormatter(formatter)
                handler.setLevel(self.__startedlevel)
                logger.addHandler(handler)
        else:                
            className = className.replace('.log','')
            fileName = projName + '_' + (datetime.now()).strftime('%Y%m%d') 
            if isDevLog:
                logger = logging.getLogger(fileName + '_dev')
            else:    
                logger = logging.getLogger(fileName)
            logger.setLevel(self.__startedlevel)        
            if not logger.handlers:            
                #directorio de logs            
                logginDirArray = (os.path.dirname(__file__)).rsplit(os.sep, 2)
                if isDevLog :                    
                    logginDir = os.path.join(logginDirArray[0], 'logs_dev', projName)
                else:    
                    logginDir = os.path.join(logginDirArray[0], 'logs', projName)
                if not os.path.exists(logginDir):
                    os.makedirs(logginDir)    
                #general 
                file_name = os.path.join(logginDir, fileName + '.log')
                formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')            
                #File log
                handler = logging.FileHandler(file_name)                        
                handler.setFormatter(formatter)
                handler.setLevel(self.__startedlevel)
                logger.addHandler(handler)            
            
        self.__logger = logger        
    
    def getLogger(self):        
        return self.__logger
    
    @staticmethod
    def devErrorLogMessage(logger, info):
        exc_type, exc_obj, exc_tb =  info
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        logger.error("class:" + fname + ", line:" + str(exc_tb.tb_lineno) + ", Exception:" +  exc_type.__name__ + ", Message:" + str(exc_obj))
    
    @staticmethod    
    def devWarningLogMessage(logger, action, value):
        logger.warning("Action:" + action + ", value:" + value)        