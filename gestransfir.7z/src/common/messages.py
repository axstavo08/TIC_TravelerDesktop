# encoding: utf-8
'''
Created on 7/5/2015

@author: C16915
'''
#PROCESOS
PROCESS_GENERAL = "GENERAL"
PROCESS_LOAD = "CARGA"
PROCESS_RELOAD = "RECARGA"
#TIPO DE LOG
LOG_INFO = "INFO"
LOG_WARNING = "ALERTA"
LOG_ERROR = "ERROR"
#STATUS
STATUS_NOT_STARTED = "NO INICIADO"
#MOTIVO
INVALID_DATE = "FECHA INVALIDA"
#ACCIONES
PROBLEM_CLEANNING_FILES  = "No se pudo eliminar los log vacíos"
NO_ACTION   = "No se realizó ninguna acción"
#PLANTILLA DE MENSAJES
SICOSIPTEL_WARNB_MESSAGE = "Proceso:%s, Motivo:%s, Mensaje:%s"
SICOSIPTEL_INFO_COMPLETE_MESSAGE = "Proceso:%s, Tecnología:%s, KPI:%s, File:%s, Inicio:%s, Fin:%s"
SICOSIPTEL_INFO_INCOMPLETE_MESSAGE = "Proceso:%s, Tecnología:%s, KPI:%s, File:%s, Mensaje:%s"
SICOSIPTEL_ERROR_LOG_MESSAGE = "Proceso:%s, Tecnología:%s, KPI:%s, File:%s"
SICOSIPTEL_INCOMPLETE_HOURS = "%s horas encontradas"