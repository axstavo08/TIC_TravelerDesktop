# encoding: utf-8
'''
Created on 10/5/2015
@author: johnPortella
@version: 1.0
'''

import paramiko, os, time
from ftplib import FTP
from operator import itemgetter
from config_parser import ConfigUtils

os.environ['NLS_LANG'] = 'SPANISH_PERU.UTF8'


class PyFileTransfer(object):
    
    def __init__(self, transfName, hostname = None):
        transfConf = ConfigUtils.read_trasnfer_config(transfName)
        
        #hostname
        if hostname is None:
            self.__hostname = transfConf['host']
        else:
            self.__hostname = hostname
        #username
        self.__username = transfConf['user']
        #password
        self.__password = transfConf['password']
        #protocol
        self.__typeProtocol = transfConf['type']        
        
        #so
        if transfConf['so'] == 'unix':
            self.__SEP = '/'
        elif transfConf['so'] == 'win':
            self.__SEP = chr(92)
        #port
        if 'port' in transfConf:
            self.__port = transfConf['port']
        else:
            self.__port = None
        #timeout
        if 'timeout' in transfConf:
            self.__timeout = float(transfConf['timeout'])
        else:
            self.__timeout = None    
            
        #open transfering
        if self.__typeProtocol == 'ftp':
            if self.__port is None:
                self.__port = 21             
            #open
            self.__t = FTP()
            self.__t.connect(self.__hostname, self.__port, self.__timeout)         
            
        elif self.__typeProtocol == 'sftp':    
            if self.__port is None:
                self.__port = 22
            #open
            self.__ssh = paramiko.Transport((self.__hostname, self.__port))
            
        
    def connection(self):
        if self.__typeProtocol == 'ftp':
            self.__t.login(self.__username, self.__password)
            #default directory
            self.__defaultDirectory = self.__t.pwd()
        elif self.__typeProtocol == 'sftp':
            self.__ssh.connect(username = self.__username, password = self.__password)            
            self.__t = paramiko.SFTPClient.from_transport(self.__ssh)
            #default directory
            self.__defaultDirectory = None            
                         
    '''
    def __init__(self, typeProtocol='ftp', hostname = 'localhost', so='unix', port = None, timeout = None):
        #Protocol
        self.__typeProtocol = typeProtocol
        #host
        self.__hostname = hostname
        #so        
        if so == 'unix':
            self.__SEP = '/'
        elif so == 'win':
            self.__SEP = chr(92)   
        #timeout
        self.__timeout = timeout
        #port
        if port:
            self.__port = port
        #open transfering
        if self.__typeProtocol == 'ftp':
            if not port:
                self.__port = 21             
            #open
            self.__t = FTP()
            self.__t.connect(self.__hostname, self.__port, self.__timeout)                                 
        elif self.__typeProtocol == 'sftp':    
            if not port:
                self.__port = 22
            #open
            self.__ssh = paramiko.Transport((self.__hostname, self.__port))
                                                                
    def connection(self, username, password):
        if self.__typeProtocol == 'ftp':
            self.__t.login(username, password)
            #default directory
            self.__defaultDirectory = self.__t.pwd()
        elif self.__typeProtocol == 'sftp':
            self.__ssh.connect(username = username, password = password)            
            self.__t = paramiko.SFTPClient.from_transport(self.__ssh)                                        
            self.__t.sock.settimeout(self.__timeout)
            #default directory
            self.__defaultDirectory = None
    
    '''   
            
    def get(self,  filename, remoteDirectory=None, localDirectory=None, newName=None):
        if localDirectory is None:
            localDirectory = os.path.dirname(os.path.realpath(__file__))
        
        if newName is not None:
            finalName = newName
        else:
            finalName = filename    
                        
        if self.__typeProtocol == 'ftp':
            pwdAux = self.__t.pwd()            
            if remoteDirectory is not None: 
                self.__t.cwd(remoteDirectory)
            localeFile = open(os.path.join(localDirectory, finalName), 'wb')
            writelocaleFile = localeFile.write
            self.__t.retrbinary("RETR " + filename, writelocaleFile)            
            self.__t.cwd(pwdAux)    
            localeFile.close()
        elif self.__typeProtocol == 'sftp':              
            if remoteDirectory is not None:
                self.__t.chdir(remoteDirectory)                
            self.__t.get(filename, os.path.join(localDirectory, finalName))
            self.__t.chdir(None)            
            
    def put(self, filename, remoteDirectory=None, localDirectory=None):        
        
        if localDirectory is None:
            localDirectory = os.path.dirname(os.path.realpath(__file__))
                    
        if self.__typeProtocol == 'ftp':
            pwdAux = self.__t.pwd()            
            if remoteDirectory is not None:
                self.__t.cwd(remoteDirectory)                            
            
            localFile = open(os.path.join(localDirectory,filename), 'r')
            self.__t.storbinary('STOR %s' % filename, localFile)
            self.__t.cwd(pwdAux)
            localFile.close()
                        
        elif self.__typeProtocol == 'sftp':                    
            if remoteDirectory is not None:
                self.__t.chdir(remoteDirectory)                
            self.__t.put(os.path.join(localDirectory, filename), filename)            
            self.__t.chdir(None)
                                
    def disconnect(self):
        if self.__typeProtocol == 'ftp':
            self.__t.quit()       
        elif self.__typeProtocol == 'sftp':
            self.__t.close()
            self.__ssh.close()
          
    def pwd(self):
        if self.__typeProtocol == 'ftp':
            return self.__t.pwd()       
        elif self.__typeProtocol == 'sftp':
            return self.__t.getcwd()
        
    def existDirectory(self, remoteDirectoryName, remoteRoot = None):
        exist = True
        
        #por default la ruta en la que el usuario tiene el acceso inicial
        if remoteRoot == None:
            remoteRoot =  self.__defaultDirectory
        #se guarda la informacion de la ubicacion actual
        cRemoteDict = self.pwd()
        #se va a la ruta remota
        self.cwd(remoteRoot)        
        try:            
            if remoteRoot is not None:                 
                seq = (remoteRoot, remoteDirectoryName); # This is sequence of strings.                                                
                newDirectory = self.__SEP.join(seq)                              
            else:
                newDirectory = remoteDirectoryName                            
            self.cwd(newDirectory)
        except Exception:            
            exist = False        
                                          
        #se vuelve a la ruta inicial
        self.cwd(cRemoteDict)        
        return exist
    
    def mkdir(self, remoteDirectoryName, remoteRoot = None): 
        #por default la ruta en la que el usuario tiene el acceso inicial
        if remoteRoot == None:
            remoteRoot =  self.__defaultDirectory
        #se guarda la informacion de la ubicacion actual
        cRemoteDict = self.pwd()
        #se va a la ruta remota
        self.cwd(remoteRoot)
        if self.__typeProtocol == 'ftp':
            self.__t.mkd(remoteDirectoryName)    
        elif self.__typeProtocol == 'sftp':                            
            self.__t.mkdir(remoteDirectoryName)
        #se vuelve a la ruta inicial
        self.cwd(cRemoteDict)
        
    def cwd(self, remoteDirectory = None):
        if self.__typeProtocol == 'ftp':
            self.__t.cwd(remoteDirectory)      
        elif self.__typeProtocol == 'sftp':
            self.__t.chdir(remoteDirectory) 
    
    def setDefaultDirectory(self):
        if self.__typeProtocol == 'ftp':
            self.__t.cwd(self.__defaultDirectory)    
        elif self.__typeProtocol == 'sftp':
            self.__t.chdir(None)
                
    def remotePathJoin (self, *paths):        
        """Returns separate paths  to string"""        
        if len(paths)== 0:
            return None
        if len(paths)== 1:
            return paths[0]
        else:
            path = paths[0]        
        for i in paths[1:]:
            path += self.__SEP + i          
        return path  
    
    def listFiles(self, remoteDirectory=None, attributes = False, like = None):
        files = [] 
        if self.__typeProtocol == 'ftp':
            self.__t.cwd(remoteDirectory)            
            if attributes :
                data = []
                self.__t.dir(data.append)
                           
                for line in data:
                    col = line.split()                            
                    #name
                    name = col[3]        
                    
                    if like is not None:
                        if like not in name:
                            continue
                    
                    if name not in  ['.','..']:
                        #size
                        size = col[2]
                        #date
                        datestr = ' '.join(line.split()[0:2])
                        st_mtime = int(time.mktime(time.strptime(datestr, '%m-%d-%y %H:%M')))
                        validFile = {'name': name, 'size': size, 'mtime': st_mtime}
                        files.append(validFile)                     
            else:
                for fileName in self.__t.nlst():
                    if like is not None:
                        if like not in fileName:
                            continue
                    
                    files.append(fileName)    
                    
            self.setDefaultDirectory()    
            return files     
        elif self.__typeProtocol == 'sftp':            
            #falta agregar el like
            if attributes:                
                totally = self.__t.listdir_attr(remoteDirectory)                
                files = []                
                for think in totally:                    
                    permission = unicode(think).split()[0]                                                
                    if 'd' not in permission:
                        validFile = {'name': (think.filename).encode('utf8'), 'size': think.st_size, 'mtime': think.st_mtime, 'uid': think.st_uid}
                        files.append(validFile)                                                                
                return files 
            else:
                totally = self.__t.listdir_attr(remoteDirectory)
                files = []
                for think in totally:
                    if 'd' not in str(think).split()[0]:                        
                        files.append(think.filename)                        
                return files
    
    def getLastFile(self, remoteDirectory=None, attributes = False, like = None):
        files = self.listFiles(remoteDirectory, True, like)
        newFiles = sorted(files, key=itemgetter('mtime'), reverse=True)
        if len(newFiles) >= 1:
            if attributes:
                return newFiles[0]
            else: 
                return (newFiles[0])['name']
        else:
            return None
            
            
'''       
                         

t = PyFileTransfer('sftp', 'test.rebex.net', 'unix')
t.connection("demo", "password")
#t.get("WinFormClient.png", '/pub/example')
print t.pwd()
t.cwd('pub/example')
print t.pwd()
t.setDefaultDirectory()
print t.pwd()
t.disconnect()
'''