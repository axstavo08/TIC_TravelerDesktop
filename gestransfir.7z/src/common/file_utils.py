'''
Created on 1/6/2015

@author: C16915
'''

import codecs

class FileUtils(object):
    
    @staticmethod
    def getLinesStartsWith(fileName, stringKeys, diffLists = False,codecN='ISO-8859-1'):        
        rows = []
        rowsfound = []
        with codecs.open(fileName, 'rb', codecN) as f:
            for a in f:
                a = a.encode('utf-8')                
                if type(stringKeys) is list:                    
                    if diffLists:
                        for stringkey in stringKeys:
                            if (a.strip()).startswith(stringkey):
                                rowsfound.append( {'key': stringkey, 'value': a.strip()} )
                    else:
                        for stringkey in stringKeys:
                            if (a.strip()).startswith(stringkey):
                                rows.append(a)
                else:
                    if (a.strip()).startswith(stringKeys):
                        rows.append(a)
        
        if len(rows) > 0:
            return rows
        else:
            realkeys = set() 
            for a in rowsfound:
                realkeys.add(a['key'])
            linesDict = {}
            for realkey in realkeys:
                values = []
                for rowfound in rowsfound:
                    if rowfound['key'] == realkey:
                        values.append(rowfound['value'])
                linesDict[realkey] = values                    
            return linesDict                
        
        '''
        rows = []    
        with codecs.open(fileName, 'rb', codecN) as f:
            alist = f.read().splitlines()
            for a in alist:
                if (a.strip()).startswith(stringKey):
                    rows.append(a) 
        return rows
        '''                                                                                            