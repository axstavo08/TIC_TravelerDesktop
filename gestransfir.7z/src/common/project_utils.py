'''
Created on 8/5/2015

@author: C16915
'''
import os, traceback, sys, ConfigParser
from datetime import timedelta, datetime 
from common import OracleDB
from config_parser import GlobalConfig 

class ProjectUtils(object):
    
    '''
    ROUTES METHODS
    '''
    
    @staticmethod
    def getRootDirectory():                
        return (os.path.dirname(__file__)).rsplit(os.sep, 2)[0] 
    
    @staticmethod
    def getFilesDirectory():                
        return os.path.join((os.path.dirname(__file__)).rsplit(os.sep, 2)[0], 'files')
    
    @staticmethod
    def getConfDirectory():                
        return os.path.join((os.path.dirname(__file__)).rsplit(os.sep, 2)[0], 'conf')
    
    @staticmethod
    def getTMPDirectory():                
        return os.path.join((os.path.dirname(__file__)).rsplit(os.sep, 2)[0], 'tmp')
    
    @staticmethod
    def getBinDirectory():                
        return os.path.join((os.path.dirname(__file__)).rsplit(os.sep, 2)[0], 'bin')
    
    '''
    CONSOLE METHODS
    '''
                    
    @staticmethod    
    def printTerminalMessage(status, message):
        if status is None:
            print "%s" % (message)
        else:    
            print "[%s] %s" % (status, message)
            #print "[%s] %s" % (status, message.decode("utf-8")) 

    '''
    CONFIG METHODS
    '''
    @staticmethod
    def envDB(db, dbLabel):
        gconf = GlobalConfig()
        dbEnv = None
        
        if gconf.environment is None:        
            enviromentFile = os.path.join(ProjectUtils.getConfDirectory(),'enviroment.cfg')
            config = ConfigParser.ConfigParser()
            config.read(enviromentFile)
            dbEnv = config.get("DB", db)            
        else:
            dbEnv = gconf.environment
            
        if dbEnv == "developer":
            dbLabel += '_dev'
        elif dbEnv == "production":
            pass
        return dbLabel
    '''
    LOG METHODS
    '''
    
    @staticmethod    
    def clearEmptyLogFiles():
        listEmptyFiles = []        
        for fileLog in ('logs', 'logs_dev'):
            for root, dirs, files in os.walk(os.path.join(ProjectUtils.getRootDirectory(), fileLog), topdown= True):                        
                for fname in files:
                    filename = os.path.join(root, fname)                    
                    if os.stat(filename).st_size == 0:
                        listEmptyFiles.append(filename)                        
        for emptyfile in listEmptyFiles:
            os.remove(emptyfile)
    
    @staticmethod    
    def removeOldLogFiles(numDays):
        listOldFiles = []        
        limitDate = (datetime.now() - timedelta(days=numDays))
        for fileLog in ('logs', 'logs_dev'):
            for root, dirs, files in os.walk(os.path.join(ProjectUtils.getRootDirectory(), fileLog), topdown= True):                        
                for fname in files:
                    filename = os.path.join(root, fname)
                    fileDate = datetime.fromtimestamp(os.stat(filename).st_mtime)                    
                    if fileDate < limitDate :
                        listOldFiles.append(filename)     
        for oldfile in listOldFiles:
            os.remove(oldfile)
                
    @staticmethod        
    def insertDBLog(project, alarmType, status, message):
        conn = OracleDB(ProjectUtils.envDB("oracle", "db_smart"))
        conn.executeProcedure("PK_GTF.SP_INSERTAR_EVENTO", [project, alarmType, status, message])
    
    @staticmethod            
    def insertWarningFileLog(logger, message):
        logger.warning(message)
    
    @staticmethod            
    def insertInfoFileLog(logger, message):
        logger.info(message)    
    
    @staticmethod            
    def insertErrorFileLog(logger, sys_exc):
        exc_type, exc_obj, exc_tb =  sys_exc        
        filename, lineno, funname, line = traceback.extract_tb(exc_tb)[-1]
        logger.error('{}:{}, method: {}, line: {}, exception: {}, message: {} '.format(filename, lineno, funname, line, exc_type.__name__, str(exc_obj)))
    
    @staticmethod            
    def insertErrorFileLogMessage(logger, message):
        logger.error(message)  
        
    @staticmethod
    def insertLogWarning(logger, loggerDev, project, alarmType, status, message):        
        try:
            ProjectUtils.insertDBLog(project, alarmType, status, message)
            ProjectUtils.insertWarningFileLog(logger, message)
        except:
            ProjectUtils.insertErrorFileLog(loggerDev, sys.exc_info()) 
            
    @staticmethod
    def insertLogInfo(logger, loggerDev, project, alarmType, status, message):        
        try:
            ProjectUtils.insertDBLog(project, alarmType, status, message)
            ProjectUtils.insertInfoFileLog(logger, message)
        except:
            ProjectUtils.insertErrorFileLog(loggerDev, sys.exc_info())
            
    @staticmethod
    def insertLogError(logger, loggerDev, project, alarmType, status, message):        
        try:
            ProjectUtils.insertDBLog(project, alarmType, status, message)
            ProjectUtils.insertErrorFileLogMessage(logger, message)
        except:
            ProjectUtils.insertErrorFileLog(loggerDev, sys.exc_info())                                         