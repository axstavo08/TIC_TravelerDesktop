'''
Created on 21/7/2016

@author: C16915 - John Portella
'''

class ListUtils(object):
    '''
    classdocs
    '''

    @staticmethod
    def merge_lists(l1, l2, key):        
        merged = {}
        for item in l1+l2:
            if item[key] in merged:
                merged[item[key]].update(item)
            else:
                merged[item[key]] = item
        return [val for (_, val) in merged.items()]