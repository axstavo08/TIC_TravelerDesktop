'''
Created on 24/11/2015

@author: C16915 - John Portella
'''

from common import OracleDB, ProjectUtils

class SICOsiptelRepository(object):
    
    def __init__(self):
        self.__conn = OracleDB(ProjectUtils.envDB("oracle", "db_smart"))
        
    #2G HUAWEI
    def getTINE2GHW(self, startDate):            
        return self.__conn.executeProcedureOUTCursor("PK_SICO_CARGAS.SP_TINE_2GHW", [startDate], False)
    
    def getTLLI2GHW(self, startDate):            
        return self.__conn.executeProcedureOUTCursor("PK_SICO_CARGAS.SP_TLLI_2GHW", [startDate], False)
    
    def getTRAF2GHW(self, startDate):
        return self.__conn.executeProcedureOUTCursor("PK_SICO_CARGAS.SP_TRAF_2GHW", [startDate], False)
    
    #2G NOKIA        
    def getTINE2GNSN(self, startDate):            
        return self.__conn.executeProcedureOUTCursor("PK_SICO_CARGAS.SP_TINE_2GNSN", [startDate], False)
    
    def getTLLI2GNSN(self, startDate):            
        return self.__conn.executeProcedureOUTCursor("PK_SICO_CARGAS.SP_TLLI_2GNSN", [startDate], False)
    
    def getTRAF2GNSN(self, startDate):            
        return self.__conn.executeProcedureOUTCursor("PK_SICO_CARGAS.SP_TRAF_2GNSN", [startDate], False)
    
    #3G HUAWEI
    def getTINE3GHW(self, startDate):            
        return self.__conn.executeProcedureOUTCursor("PK_SICO_CARGAS.SP_TINE_3GHW", [startDate], False)
    
    def getTLLI3GHW(self, startDate):            
        return self.__conn.executeProcedureOUTCursor("PK_SICO_CARGAS.SP_TLLI_3GHW", [startDate], False)
    
    def getTRAF3GHW(self, startDate):            
        return self.__conn.executeProcedureOUTCursor("PK_SICO_CARGAS.SP_TRAF_3GHW", [startDate], False)
    
    #RECARGA
    def putEmptyFiles(self, technology, kpi, startdate):
        self.__conn.executeProcedure("PK_SICO_CARGAS.SP_AGREGAR_RECARGA", [technology, kpi, startdate])
        
    def getEmptyFiles(self):
        return self.__conn.executeProcedureOUTCursor("PK_SICO_CARGAS.SP_OBTENER_RECARGAS")
    
    def deleteEmptyFile(self, technology, kpi, startdate):
        self.__conn.executeProcedure("PK_SICO_CARGAS.SP_ELIMINAR_RECARGA", [technology, kpi, startdate])
    