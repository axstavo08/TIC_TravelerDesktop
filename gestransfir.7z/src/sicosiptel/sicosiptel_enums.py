'''
Created on 23/11/2015

@author: C16915 - John Portella
'''

from enum import Enum

class Kpi(Enum):
    tine  = 'TINE'
    tlli  = 'TLLI'
    traf  = 'TRAF'    
    
    @classmethod          
    def getEnum(cls, spName):
        return ([sp[1] for sp in cls.__members__.items() if (sp[1]).value == spName])[0]

class Technology(Enum):
    t2gnsn          = '2G_NSN'
    t2ghw           = '2G_HW'    
    t3ghw           = '3G_HW'    
    
    @classmethod          
    def getEnum(cls, spName):
        return ([sp[1] for sp in cls.__members__.items() if (sp[1]).value == spName])[0]
    
class ProcessType(Enum):
    load            = 'CARGA'
    reload          = 'RECARGA'
        