'''
Created on 24/11/2015

@author: C16915 - John Portella
'''
from common import DateUtils, DateType, Logger
from sicosiptel_repository import SICOsiptelRepository
from sicosiptel_process import SICOsiptelProcess
from sicosiptel_enums import Kpi, Technology, ProcessType

class SICOsiptelBusiness(object):

    def __init__(self):
        self.__loggerDev  = (Logger("sicosiptel", self.__class__.__name__, True)).getLogger()
        
        #inicializacion del repository
        self.__sicosiptelRepository = SICOsiptelRepository()
        pass
    
    def load(self, startDate, endDate):
                
        for date in DateUtils.getDateRange(startDate, endDate, DateType.day):
            #PROCEDIMIENTO 2G HUAWEI - TINE
            procTINE2gHW = SICOsiptelProcess(Technology.t2ghw, Kpi.tine, date)
            procTINE2gHW.run()
            #PROCEDIMIENTO 2G HUAWEI - TLLI
            procTLLI2gHW = SICOsiptelProcess(Technology.t2ghw, Kpi.tlli, date)
            procTLLI2gHW.run()
            #PROCEDIMIENTO 2G HUAWEI - TRAFICO            
            procTRAF2gHW = SICOsiptelProcess(Technology.t2ghw, Kpi.traf, date)
            procTRAF2gHW.run()
            #PROCEDIMIENTO 2G NOKIA - TINE
            procTINE2gNSN = SICOsiptelProcess(Technology.t2gnsn, Kpi.tine, date)
            procTINE2gNSN.run()
            #PROCEDIMIENTO 2G NOKIA - TLLI
            procTLLI2gNSN = SICOsiptelProcess(Technology.t2gnsn, Kpi.tlli, date)
            procTLLI2gNSN.run()
            #PROCEDIMIENTO 2G NOKIA - TRAFICO            
            procTRAF2gNSN = SICOsiptelProcess(Technology.t2gnsn, Kpi.traf, date)
            procTRAF2gNSN.run()
            #PROCEDIMIENTO 3G HUAWEI - TINE
            procTINE3gHW = SICOsiptelProcess(Technology.t3ghw, Kpi.tine, date)
            procTINE3gHW.run()
            #PROCEDIMIENTO 3G HUAWEI - TLLI
            procTLLI3gHW = SICOsiptelProcess(Technology.t3ghw, Kpi.tlli, date)
            procTLLI3gHW.run()
            #PROCEDIMIENTO 2G NOKIA - TRAFICO            
            procTRAF3gHW = SICOsiptelProcess(Technology.t3ghw, Kpi.traf, date)
            procTRAF3gHW.run()
            
    def reload(self):
        for row in self.__sicosiptelRepository.getEmptyFiles():            
            technology = Technology.getEnum(row["TECNOLOGIA"])
            kpi = Kpi.getEnum(row["KPI"])
            startdate = row["FECHAHORA"]
            self.__loggerDev.info(technology.value + " " + kpi.value)
            procKPI = SICOsiptelProcess(technology, kpi, startdate, ProcessType.reload)
            procKPI.run() 