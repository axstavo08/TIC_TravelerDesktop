'''
Created on 24/11/2015

@author: C16915 - John Portella
'''

import sys
from datetime import datetime
from common import Logger
from sicosiptel_repository import SICOsiptelRepository
from sicosiptel_service import SICOsiptelService
from sicosiptel_enums import Technology, Kpi, ProcessType
from sicosiptel_utils import SICOsiptelUtils

class SICOsiptelProcess(object):
    
    def __init__(self, technology, kpi, startdate, processType= ProcessType.load):
        #logger        
        self.__logger     = (Logger("sicosiptel", self.__class__.__name__)).getLogger()
        self.__loggerDev  = (Logger("sicosiptel", self.__class__.__name__, True)).getLogger()   
        
        self.__technology = technology
        self.__kpi = kpi
        self.__startdate = startdate
        self.__processType = processType
        
        #inicializacion del repository
        self.__sicosiptelRepository = SICOsiptelRepository()
        #inicializacion del service
        self.__sicosiptelService = SICOsiptelService()
        
    def run(self):
        #status inicial
        status = 'REALIZADO'
        appStatus = 'INFO'
        #generar la hora de inicio
        startTime = datetime.now()                
        #procesamiento
        kpiInformation = None
        fileName = None        
        hoursAmount = 0
                
        try:             
            #obtener la data    
            if self.__technology == Technology.t2ghw:
                if self.__kpi == Kpi.tine:                                                    
                    kpiInformation = self.__sicosiptelRepository.getTINE2GHW(self.__startdate)                    
                elif self.__kpi == Kpi.tlli:                                                    
                    kpiInformation = self.__sicosiptelRepository.getTLLI2GHW(self.__startdate)                    
                elif self.__kpi == Kpi.traf:                    
                    kpiInformation = self.__sicosiptelRepository.getTRAF2GHW(self.__startdate)                    
            elif self.__technology == Technology.t2gnsn:
                if self.__kpi == Kpi.tine:                                                
                    kpiInformation = self.__sicosiptelRepository.getTINE2GNSN(self.__startdate)
                elif self.__kpi == Kpi.tlli:                    
                    kpiInformation = self.__sicosiptelRepository.getTLLI2GNSN(self.__startdate)
                elif self.__kpi == Kpi.traf:                    
                    kpiInformation = self.__sicosiptelRepository.getTRAF2GNSN(self.__startdate)
            elif self.__technology == Technology.t3ghw:
                if self.__kpi == Kpi.tine:                                            
                    kpiInformation = self.__sicosiptelRepository.getTINE3GHW(self.__startdate)
                elif self.__kpi == Kpi.tlli:                    
                    kpiInformation = self.__sicosiptelRepository.getTLLI3GHW(self.__startdate)                    
                elif self.__kpi == Kpi.traf:                    
                    kpiInformation = self.__sicosiptelRepository.getTRAF3GHW(self.__startdate)
            
            #Generar CSV
            fileName = SICOsiptelUtils.getFileName(self.__technology, self.__kpi, self.__startdate)                        
            #cantidad de horas
            hours = {row[0] for row  in kpiInformation['data']}
            hoursAmount = len(hours)
            if hoursAmount == 24:
                self.__sicosiptelService.createAndSendCSV(fileName, kpiInformation['data'], kpiInformation['description'])
                
                if self.__processType == ProcessType.reload:
                    self.__sicosiptelRepository.deleteEmptyFile(self.__technology.value, self.__kpi.value, self.__startdate)
            elif hoursAmount > 0:                                            
                #Asi este incompleto se general el CSV
                self.__sicosiptelService.createAndSendCSV(fileName, kpiInformation['data'], kpiInformation['description'])
                                                
                status = 'INCOMPLETO' 
                self.__sicosiptelRepository.putEmptyFiles(self.__technology.value, self.__kpi.value, self.__startdate)
            else:                   
                status = 'VACIO' 
                self.__sicosiptelRepository.putEmptyFiles(self.__technology.value, self.__kpi.value, self.__startdate)            
                                    
        except Exception: 
            appStatus = 'ERROR'
            SICOsiptelUtils.insertSICOsiptelLogError(self.__loggerDev, sys.exc_info())
        finally:
            #log de finalizacion del proceso
            endTime = datetime.now()
            
            if appStatus == 'INFO':                
                if status == 'REALIZADO':
                    SICOsiptelUtils.insertSICOsiptelCompLogInfo(self.__logger, self.__loggerDev, status, self.__technology.value, self.__kpi.value, self.__processType.value, fileName, {'startTime': startTime, 'endTime': endTime})
                elif status in ('INCOMPLETO','VACIO'):
                    SICOsiptelUtils.insertSICOsiptelInCompLogInfo(self.__logger, self.__loggerDev, status, self.__technology.value, self.__kpi.value, self.__processType.value, fileName,{'hours' : hoursAmount})
            elif appStatus == 'ERROR':
                SICOsiptelUtils.insertSICOsiptelErrorLog(self.__logger, self.__loggerDev, "FALLIDO", self.__technology.value, self.__kpi.value, self.__processType.value, fileName)
                            