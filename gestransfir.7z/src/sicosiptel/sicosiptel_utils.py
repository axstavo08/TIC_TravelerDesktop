'''
Created on 23/11/2015

@author: C16915 - John Portella
'''
import os
from common import ProjectUtils, DateUtils, messages
from sicosiptel_enums import Technology

class SICOsiptelUtils(object):   

    @staticmethod   
    def insertSICOsiptelLogWarning(logger, loggerDev, status, process, reason, message, startdate = None):           
        compMessage = messages.SICOSIPTEL_WARNB_MESSAGE % (process,reason, message)         
        ProjectUtils.insertLogWarning(logger, loggerDev, "SICOSIPTEL", messages.LOG_WARNING, status, compMessage)        
        ProjectUtils.printTerminalMessage(status, compMessage)
    
    @staticmethod       
    def insertSICOsiptelInCompLogInfo(logger, loggerDev,status, technology, kpi, process, fileName, params ):
        compMessage = messages.SICOSIPTEL_INFO_INCOMPLETE_MESSAGE % (process, technology, kpi , fileName, messages.SICOSIPTEL_INCOMPLETE_HOURS % (params['hours']) )
        ProjectUtils.insertLogInfo(logger, loggerDev, "SICOSIPTEL", "INFO", status, compMessage)
        ProjectUtils.printTerminalMessage(status, compMessage)
        
    @staticmethod       
    def insertSICOsiptelCompLogInfo(logger, loggerDev,status, technology, kpi, process, fileName, params ):
        compMessage = messages.SICOSIPTEL_INFO_COMPLETE_MESSAGE % (process,technology, kpi, fileName, params['startTime'], params['endTime'])            
        ProjectUtils.insertLogInfo(logger, loggerDev, "SICOSIPTEL", "INFO", status, compMessage)
        ProjectUtils.printTerminalMessage(status, compMessage)                        
    
    @staticmethod       
    def insertSICOsiptelErrorLog(logger, loggerDev,status, technology, kpi, process, fileName):
        compMessage = messages.SICOSIPTEL_ERROR_LOG_MESSAGE % (process,technology, kpi, fileName)            
        ProjectUtils.insertLogError(logger, loggerDev, "SICOSIPTEL", "ERROR", status, compMessage)        
        ProjectUtils.printTerminalMessage(status, compMessage)  
    
    @staticmethod
    def insertSICOsiptelLogError(logger, sys_exc):
        ProjectUtils.insertErrorFileLog(logger, sys_exc)
        
    
    @staticmethod
    def getFileName(technology, kpi, date):
        BASE_NAME = 'AMO_XX_YY_ddmmaaaa.csv'
        fileName = BASE_NAME
        
        #tecnologia
        if technology == Technology.t2ghw:
            fileName = fileName.replace('XX', '2G_HUA')
        elif technology == Technology.t2gnsn:
            fileName = fileName.replace('XX', '2G_NOK')
        elif technology == Technology.t3ghw:
            fileName = fileName.replace('XX', '3G_HUA')
            
        #kpi
        fileName = fileName.replace('YY', kpi.value)
                
        #Fechas
        fileName = fileName.replace('ddmmaaaa', DateUtils.convertDateUntilDayToNumber(date))                
        return fileName
    
    @staticmethod
    def getLocalFilesDirectory():
        return os.path.join(ProjectUtils.getFilesDirectory(), 'sicosiptel')