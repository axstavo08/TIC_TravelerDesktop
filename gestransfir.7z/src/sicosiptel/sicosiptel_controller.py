'''
Created on 18/11/2015

@author: C16915 - John Portella
'''

import sys
from datetime import datetime 
from common import messages, Logger, DateUtils, DateType
from sicosiptel_utils import SICOsiptelUtils
from sicosiptel_business import SICOsiptelBusiness


class SICOsiptelController(object):
    
    def __init__(self, params = []):
        #logger                
        self.logger     = (Logger("sicosiptel", self.__class__.__name__)).getLogger()
        self.loggerDev  = (Logger("sicosiptel", self.__class__.__name__, True)).getLogger()                    
        
        #business        
        self.__sicosiptelBusiness = SICOsiptelBusiness()
                        
    def load(self, params = []):
        #parameters        
        nStartDate   = params[0] if 0 < len(params) else None
        nEndDate     = params[1] if 1 < len(params) else None                
        
        #validar fechas
        validDate = True    
        
        if nStartDate is None:             
            startDate = DateUtils.addTime( DateUtils.getDatewithDaySinceNumber((datetime.now()).strftime('%Y%m%d')) , DateType.day , -1)                
        elif nStartDate.isdigit() and len(nStartDate) == 8 and DateUtils.isValidDate(nStartDate, '%Y%m%d'):            
            startDate = DateUtils.getDatewithDaySinceNumber(nStartDate)
        else:            
            validDate = False
        
        if nEndDate is None:
            endDate = startDate
        elif nEndDate.isdigit() and len(nEndDate) == 8 and DateUtils.isValidDate(nEndDate, '%Y%m%d') and nStartDate < nEndDate:            
            endDate = DateUtils.getDatewithDaySinceNumber(nEndDate) 
        else:            
            validDate = False
            
        if not validDate:            
            SICOsiptelUtils.insertSICOsiptelLogWarning(self.logger, self.loggerDev, messages.STATUS_NOT_STARTED, messages.PROCESS_GENERAL, messages.INVALID_DATE, nStartDate + "," + nEndDate)                                                        
            sys.exit()
        
        self.__sicosiptelBusiness.load(startDate, endDate)
                        
    def reload(self):
        self.__sicosiptelBusiness.reload()