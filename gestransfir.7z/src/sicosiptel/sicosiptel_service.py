'''
Created on 24/11/2015

@author: C16915 - John Portella
'''

import os
from sicosiptel_utils import SICOsiptelUtils
from common import CSVUtils, PyFileTransfer

class SICOsiptelService(object):
    
    def createAndSendCSV(self, fileName, data, headers):        
        directoryContainer = 'estadisticas'
        fileCSVDirectory = SICOsiptelUtils.getLocalFilesDirectory()
        CSVUtils.exportRecordsToCSV(os.path.join(fileCSVDirectory, fileName), data, headers)
        #Transferencia via SFTP                        
        #t = PyFileTransfer('ftp_calidad3')
        t = PyFileTransfer('ftp_limftp2')      
        t.connection()        
        if not t.existDirectory(directoryContainer):
            t.mkdir(directoryContainer)      
        t.put(fileName, directoryContainer, fileCSVDirectory)                            
        t.disconnect()       