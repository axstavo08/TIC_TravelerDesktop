'''
Created on 2/10/2017

@author: C16915
'''

import os
from common import ProjectUtils

class SOCUtils(object):
                
    @staticmethod
    def getLocalFilesDirectory():
        return os.path.join(ProjectUtils.getFilesDirectory(), 'soc')
    
    @staticmethod
    def insertFileLogError(logger, sys_exc):
        ProjectUtils.insertErrorFileLog(logger, sys_exc)
    
    @staticmethod
    def insertLog(logger, loggerDev, status, message):
        newMessage = "[%s] %s" % (status, message)
        if status == "REALIZADO":
            alarm = "INFO"
        elif status == 'EXISTENTE':
            alarm = "WARN"
        else:
            alarm = "ERROR"        
        ProjectUtils.insertLogInfo(logger, loggerDev, "SOC", alarm, status, newMessage)        
        print newMessage