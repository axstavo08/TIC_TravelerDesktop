'''
Created on 2/10/2017

@author: C16915 - John Portella
'''
import re, os, csv
from soc_utils import SOCUtils
from soc_enum import Type
from soc_mapping import SOCMapping
from soc_repository import SOCRepository

class SOCService(object):

    def __init__(self):
        self.__socRepository = SOCRepository()        
    
    def getValidFiles(self, dataType):
        directory = SOCUtils.getLocalFilesDirectory()                    
        regex=re.compile("^" + (dataType.value).lower() + "_[0-9]{4}_[0-9]{1,2}\.csv$")
        files = []
        for dfile in os.listdir(directory):
            pathFile = os.path.join(directory, dfile)
            if os.path.isfile(pathFile) and regex.search(dfile):            
                variables = (dfile.replace(".csv","")).split("_")
                files.append({'filename':  dfile, 'file': pathFile, 'year': int(variables[1]), 'week': int(variables[2]) })                
        return files
    
    def getData(self, dataType, dataFile):
        with open(dataFile['file'], 'rb') as f:
            reader = csv.DictReader(f, delimiter=",")
            if dataType == Type.vac:
                data = [dict(item, **{'year':dataFile['year'] , 'week': dataFile['week'], 'vapcount':float(item['vapcount']), 'total_day':float(item['total_day']), 'traffic_day':float(item['traffic_day']) }) for item in list(reader)]
            elif dataType == Type.vap:
                data = [dict(item, **{'year':dataFile['year'] , 'week': dataFile['week'], 'msisdn':float(item['msisdn']), 'AveScore':float(item['AveScore']), 'StreamAveScore':float(item['StreamAveScore']), 'WebAveScore':float(item['WebAveScore']), 'SNAveScore':float(item['SNAveScore']), 'IMAveScore':float(item['IMAveScore']) }) for item in list(reader)]
            elif dataType == Type.cs:                
                data = list(reader)
                for item in data:
                    item.update({'year':dataFile['year'] , 'week': dataFile['week'], \
                        'MOCCHIREDCOUNT':float(item['MOCCHIREDCOUNT']), \
                        'UserNumber':float(item['UserNumber']), 
                        'Priority':int(item['Priority']) if item['Priority'] else None, \
                        'Perceived_Call_Success_Rate': float(item['Perceived Call Success Rate']), \
                        'E2E_Call_Connection_Delay': float(item['E2E Call Connection Delay(ms)']), \
                        'Perceived_Call_Drop_Rate': float(item['Perceived Call Drop Rate']), \
                        'Score1':float(item['Score1']),'Score2':float( item['Score2']), \
                        'Score3':float(item['Score3']), 'Score':float( item['Score']) })
                    item.pop("XPOS")
                    item.pop("YPOS")
                    item.pop("Ranking")   
                    item.pop("Perceived Call Success Rate")
                    item.pop("E2E Call Connection Delay(ms)")
                    item.pop("Perceived Call Drop Rate")
            elif dataType == Type.ps:
                data = list(reader)
                for item in data:
                    item.update({'year':dataFile['year'] , 'week': dataFile['week'], \
                        'TrafficGB':float(item['TrafficGB']), \
                        'UserNumber':float(item['UserNumber']), 
                        'Priority':int(item['Priority']) if item['Priority'] else None, \
                        'Downlink_TCP_Ret_Rate': float(item['Downlink TCP Retransmission Rate']), \
                        'Downlink_TCP_Out_Order_Rate': float(item['Downlink TCP Out-of-Order Rate']), \
                        'Client_Side_RTT': float(item['Client Side Round Trip Time']), \
                        'Client_Side_RTT_LRate': float(item['Client Side RTT Long Rate']), \
                        'Client_S_Up_TCP_PLoss_Rate': float(item['Client Side Uplink TCP Packet Loss Rate']), \
                        'Client_S_Down_TCP_PLoss_Rate': float(item['Client Side Downlink TCP Packet Loss Rate']), \
                        'Downlink_C_Ret_Delay_Rate': float(item['Downlink Continous  Retransmission Delay Rate']), \
                        'Score1':float(item['Score1']),'Score2':float( item['Score2']), \
                        'Score3':float(item['Score3']),'Score4':float( item['Score4']), \
                        'Score5':float(item['Score5']),'Score6':float( item['Score6']), \
                        'Score7':float(item['Score7']), 'Score':float( item['Score']) })
                    item.pop("XPOS")
                    item.pop("YPOS")
                    item.pop("Ranking")   
                    item.pop("Downlink TCP Retransmission Rate")
                    item.pop("Downlink TCP Out-of-Order Rate")
                    item.pop("Client Side Round Trip Time")
                    item.pop("Client Side RTT Long Rate")
                    item.pop("Client Side Uplink TCP Packet Loss Rate")
                    item.pop("Client Side Downlink TCP Packet Loss Rate")
                    item.pop("Downlink Continous  Retransmission Delay Rate")
                    
        return data
    
    def getColumns(self, dataType ):
        if dataType == Type.vac:
            return SOCMapping.columnsDictVac()
        elif dataType == Type.vap:
            return SOCMapping.columnsDictVap()
        elif dataType == Type.cs:
            return SOCMapping.columnsDictCS()
        elif dataType == Type.ps:
            return SOCMapping.columnsDictPS()
    def extraLoad(self, dataType, year, week):
        if dataType == Type.vac:
            self.__socRepository.updateTechnologyVAC(dataType, year, week)
    
    def removeFile(self, filename):
        os.remove(filename)