'''
Created on 2/10/2017

@author: C16915 - John Portella
'''
from soc_enum import Type
from soc_business import SOCBusiness

class SOCController(object):
    
    def __init__(self, params=[]):
        self.__type = Type((params.type).upper())
        self.__socBusiness = SOCBusiness(self.__type)
        self.__socBusiness.load(params.force)        