'''
Created on 3/10/2017

@author: C16915
'''

class InsertDataError(Exception):
    pass