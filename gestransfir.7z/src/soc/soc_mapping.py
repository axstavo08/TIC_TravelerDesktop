'''
Created on 3/10/2017

@author: C16915
'''

class SOCMapping(object):
        
    @staticmethod
    def columnsDictVac():
        listCommands = []
        listCommands.append({ 'ndict': ':year', 'ncol' : 'ANIO' })        
        listCommands.append({ 'ndict': ':week', 'ncol' : 'SEMANA' })
        listCommands.append({ 'ndict': ':cgisai', 'ncol' : 'CGISAI' })
        listCommands.append({ 'ndict': ':cell_name', 'ncol' : 'CELL_NAME' })
        listCommands.append({ 'ndict': ':site_name', 'ncol' : 'SITE_NAME' })
        listCommands.append({ 'ndict': ':vapcount', 'ncol' : 'TOTAL_VAP_USER' })        
        listCommands.append({ 'ndict': ':total_day', 'ncol' : 'VAP_USER_DAY' })
        listCommands.append({ 'ndict': ':traffic_day', 'ncol' : 'TRAFFICMB_DAY' })
        return listCommands
    
    @staticmethod
    def columnsDictVap():
        listCommands = []
        listCommands.append({ 'ndict': ':msisdn', 'ncol' : 'MSISDN' })        
        listCommands.append({ 'ndict': ':AveScore', 'ncol' : 'AVESCORE' })
        listCommands.append({ 'ndict': ':StreamAveScore', 'ncol' : 'STREAMAVESCORE' })
        listCommands.append({ 'ndict': ':WebAveScore', 'ncol' : 'WEBAVESCORE' })
        listCommands.append({ 'ndict': ':SNAveScore', 'ncol' : 'SNAVESCORE' })
        listCommands.append({ 'ndict': ':IMAveScore', 'ncol' : 'IMAVESCORE' })        
        listCommands.append({ 'ndict': ':year', 'ncol' : 'ANIO' })
        listCommands.append({ 'ndict': ':week', 'ncol' : 'SEMANA' })
        return listCommands
    
    @staticmethod
    def columnsDictCS():
        listCommands = []
        listCommands.append({ 'ndict': ':year', 'ncol' : 'ANIO' })        
        listCommands.append({ 'ndict': ':week', 'ncol' : 'SEMANA' })
        listCommands.append({ 'ndict': ':ACCESS_TYPE', 'ncol' : 'TECNOLOGIA' })
        listCommands.append({ 'ndict': ':Priority', 'ncol' : 'PRIORIDAD' })
        listCommands.append({ 'ndict': ':CGISAI', 'ncol' : 'CGISAI' })
        listCommands.append({ 'ndict': ':CELL_NAME', 'ncol' : 'CELL_NAME' })        
        listCommands.append({ 'ndict': ':SITE_NAME', 'ncol' : 'SITE_NAME' })
        listCommands.append({ 'ndict': ':MOCCHIREDCOUNT', 'ncol' : 'MOCCHIREDCOUNT' })
        listCommands.append({ 'ndict': ':UserNumber', 'ncol' : 'USER_NUMBER' })
        listCommands.append({ 'ndict': ':Perceived_Call_Success_Rate', 'ncol' : 'PERCEIVED_CALL_SUCCESS_RATE' })
        listCommands.append({ 'ndict': ':E2E_Call_Connection_Delay', 'ncol' : 'MOBILE_ORIG_CALL_SETUP_DELAY' })
        listCommands.append({ 'ndict': ':Perceived_Call_Drop_Rate', 'ncol' : 'PERCEIVED_CALL_DROP_RATE' })
        listCommands.append({ 'ndict': ':Score1', 'ncol' : 'PERCEIVED_CALL_SUCCESS_SCORE' })
        listCommands.append({ 'ndict': ':Score2', 'ncol' : 'MOB_ORIG_CALL_SET_DELAY_SCORE' })
        listCommands.append({ 'ndict': ':Score3', 'ncol' : 'PERCEIVED_CALL_DROP_SCORE' })
        listCommands.append({ 'ndict': ':Score', 'ncol' : 'TOTAL_SCORE' })
        return listCommands
    
    @staticmethod
    def columnsDictPS():
        listCommands = []
        listCommands.append({ 'ndict': ':year', 'ncol' : 'ANIO' })        
        listCommands.append({ 'ndict': ':week', 'ncol' : 'SEMANA' })
        listCommands.append({ 'ndict': ':ACCESS_TYPE', 'ncol' : 'TECNOLOGIA' })
        listCommands.append({ 'ndict': ':Priority', 'ncol' : 'PRIORIDAD' })
        listCommands.append({ 'ndict': ':CGISAI', 'ncol' : 'CGISAI' })
        listCommands.append({ 'ndict': ':CELL_NAME', 'ncol' : 'CELL_NAME' })        
        listCommands.append({ 'ndict': ':SITE_NAME', 'ncol' : 'SITE_NAME' })
        listCommands.append({ 'ndict': ':TrafficGB', 'ncol' : 'TrafficGB' })
        listCommands.append({ 'ndict': ':UserNumber', 'ncol' : 'USER_NUMBER' })
        listCommands.append({ 'ndict': ':Downlink_TCP_Ret_Rate', 'ncol' : 'DOWNLINK_TCP_RET_RATE' })
        listCommands.append({ 'ndict': ':Downlink_TCP_Out_Order_Rate', 'ncol' : 'DOWNLINK_TCP_OUT_OF_ORDER_RATE' })
        listCommands.append({ 'ndict': ':Client_Side_RTT', 'ncol' : 'CLIENT_SIDE_ROUND_TRIP_TIME' })
        listCommands.append({ 'ndict': ':Client_Side_RTT_LRate', 'ncol' : 'CLIENT_SIDE_RTT_LONG_RATE' })
        listCommands.append({ 'ndict': ':Client_S_Up_TCP_PLoss_Rate', 'ncol' : 'CLIENT_S_UP_TCP_PLOSS_RATE' })
        listCommands.append({ 'ndict': ':Client_S_Down_TCP_PLoss_Rate', 'ncol' : 'CLIENT_S_DOWN_TCP_PLOSS_RATE' })
        listCommands.append({ 'ndict': ':Downlink_C_Ret_Delay_Rate', 'ncol' : 'DOWN_CONT_RET_DELAY_RATE' })        
        listCommands.append({ 'ndict': ':Score1', 'ncol' : 'DOWNLINK_TCP_RET_SCORE' })
        listCommands.append({ 'ndict': ':Score2', 'ncol' : 'DOWNLINK_TCP_OUT_ORDER_SCORE' })
        listCommands.append({ 'ndict': ':Score3', 'ncol' : 'CLIENT_SIDE_RTT_SCORE' })
        listCommands.append({ 'ndict': ':Score4', 'ncol' : 'CLIENT_SIDE_RTT_LONG_SCORE' })
        listCommands.append({ 'ndict': ':Score5', 'ncol' : 'CLIENT_S_UP_TCP_PLOSS_SCORE' })
        listCommands.append({ 'ndict': ':Score6', 'ncol' : 'CLIENT_S_DOWN_TCP_PLOSS_SCORE' })
        listCommands.append({ 'ndict': ':Score7', 'ncol' : 'DOWN_CONT_RET_DELAY_SCORE' })
        listCommands.append({ 'ndict': ':Score', 'ncol' : 'TOTAL_SCORE' })
        return listCommands