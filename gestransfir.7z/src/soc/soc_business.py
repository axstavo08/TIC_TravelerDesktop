'''
Created on 2/10/2017

@author: C16915
'''
import sys
from soc_enum import Type
from soc_service import SOCService 
from soc_repository import SOCRepository
from soc_excep import InsertDataError
from soc_utils import SOCUtils
from common import DateUtils, Logger

class SOCBusiness(object):
    
    def __init__(self, dataType = Type.cs):
        #logger        
        self.logger = (Logger("soc", self.__class__.__name__)).getLogger()
        self.loggerDev  = (Logger("soc", self.__class__.__name__, True)).getLogger()
        #init
        self.__dataType = dataType
        self.__socService =  SOCService()
        self.__socRepository = SOCRepository()

    def load(self, isForce=False):
        files = self.__socService.getValidFiles(self.__dataType)
        for dataFile in files:
            status = 'INICIO' #status inicial        
            startTime = DateUtils.now() #generar la hora de inicio
            try:                
                #Verificar existencia de informacion con el mismo anio y semana y comprobar si se fuerza 
                #el borrado                
                existsData = self.__socRepository.existsData(self.__dataType, dataFile['year'], dataFile['week'])
                if isForce and existsData:
                    self.__socRepository.removeData(self.__dataType, dataFile['year'], dataFile['week'])
                elif not isForce and existsData:
                    raise InsertDataError('Exists Data')
                #obtener la data del csv
                data = self.__socService.getData(self.__dataType, dataFile)                
                #obtener las cabeceras y mapeadas con las tablas de la BD
                columns = self.__socService.getColumns(self.__dataType)
                #Insertar la data en la BD
                self.__socRepository.insertData(self.__dataType, columns, data)
                #Procesos Extras
                self.__socService.extraLoad(self.__dataType, dataFile['year'], dataFile['week'])
                #Eliminar el archivo
                self.__socService.removeFile(dataFile['file'])
                #Finalizado
                status = 'REALIZADO'
            except InsertDataError:
                status = 'EXISTENTE'
            except Exception:
                status = 'FALLIDO'
                SOCUtils.insertFileLogError(self.loggerDev, sys.exc_info())
            finally:
                endTime = DateUtils.now() #log de finalizacion del proceso
                message = "Filename:%s Inicio:%s Fin:%s" % (dataFile['filename'], startTime.strftime('%d/%m/%Y %H:%M:%S'), endTime.strftime('%d/%m/%Y %H:%M:%S'))
                SOCUtils.insertLog(self.logger, self.loggerDev, status, message)