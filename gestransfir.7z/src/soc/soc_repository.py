'''
Created on 3/10/2017

@author: C16915 - John Portella
'''

import cx_Oracle
from common import OracleDB, OracleDBTrans, ProjectUtils

class SOCRepository(object):

    def __init__(self):
        self.__conn = OracleDB(ProjectUtils.envDB("oracle", "db_smart"))
        
    def existsData(self, dataType, year, week):
        return True if self.__conn.callFunction('PK_GTF_SOC.EXISTE_DATA', cx_Oracle.NUMBER, [dataType.value, year, week]) == 1 else 0
    
    def removeData(self, dataType, year, week):
        self.__conn.executeProcedure("PK_GTF_SOC.SP_ELIMINAR_DATA", [dataType.value, year, week])
        
    def __getSOCTable(self, dataType):
        return self.__conn.callFunction('PK_GTF_SOC.OBTENER_TABLA', cx_Oracle.STRING, [dataType.value]) 
    
    def insertData(self, dataType, columns, data):        
        tm = OracleDBTrans(ProjectUtils.envDB("oracle", "db_smart"))
        tm.begin()
        tm.bulkInsertWithDict(self.__getSOCTable(dataType), columns, data)
        tm.commit()
            
    def updateTechnologyVAC(self, dataType , year, week):
        self.__conn.executeProcedure("PK_GTF_SOC.SP_ACT_TECNOLOGIA_VAC", [dataType.value, year, week])