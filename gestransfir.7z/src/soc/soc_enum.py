'''
Created on 2/10/2017

@author: C16915
'''

from enum import Enum

class Type(Enum):
    cs = 'CS'
    ps = 'PS'
    vap = 'VAP'
    vac = 'VAC'