#!/user/bin/env python
# encoding: utf-8
'''
Created on 7/5/2015

@author: C16915 - John Portella
'''

import sys, argparse 
from common import messages, Logger, ProjectUtils
from cmfitel import CMFitelController
from sicosiptel import SICOsiptelController
from dump import DumpController, DumpIntroController
from lbs import LBSController
from soc import SOCController
from planificador import PlanificadorController




#General
logger = (Logger("gestransfir", "main")).getLogger()

HELP_COMMAND = '--help'

#Log general
def insertGeneralLog(alarmType, status, message):    
    try:
        ProjectUtils.insertDBLog("GENERAL", alarmType, status, message)
        ProjectUtils.insertWarningFileLog(logger, message)
    except:
        ProjectUtils.insertErrorFileLog(logger, sys.exc_info()) 
            
#Limpieza de Logs
def removeLogFiles():    
    try:
        ProjectUtils.clearEmptyLogFiles()
        ProjectUtils.removeOldLogFiles(10)
    except:
        insertGeneralLog("ALERTA", "SIGUIENTE", messages.PROBLEM_CLEANNING_FILES)
        ProjectUtils.printTerminalMessage("ALERTA", messages.PROBLEM_CLEANNING_FILES)

def repeat_to_length(string_to_expand, length):
    return (string_to_expand * ((length/len(string_to_expand))+1))[:length]
    

if __name__ == '__main__':    
    #limpiar logs vacios
    removeLogFiles();    
    
    #SubProyectos
    if len(sys.argv) == 1:                
        insertGeneralLog("ALERTA", "FINALIZADO", "No se ha llamado a ningún subproyecto")        
        ProjectUtils.printTerminalMessage("FINALIZADO", messages.NO_ACTION)            
        sys.exit()
        
    subProj = sys.argv[1]
    
    if subProj == 'cmfitel':
        #help
        '''
        if len(sys.argv)  == 3 and sys.argv[2] == HELP_COMMAND:            
            print "\nOpciones:"            
            print "-g   \tGranularidad. Por default hora."
            print "-st  \tTiempo. Para granularidad hora YYYYMMDDHH (default:dos horas atras) y YYYYMMDD (default: dia anterior) para dia."
            print "-set \tTipo de envio"            
            sys.exit()        
        #Carga
        cmFitel = CMFitelController(sys.argv[2:])                              
        cmFitel.process()
        #Recarga
        cmFitel.recharge()
        '''
        #help        
        parser = argparse.ArgumentParser(description="Creacion de reportes de Alarmas y KPIS para FITEL")
        #lista de argumentos        
        parser.add_argument("-sd", "--startdate",  help="Fecha de inicio (Default: YYYYMMDD)", type=int)
        parser.add_argument("-ed", "--enddate",    help="Fecha de cierre. Es necesario una fecha de inicio (Default: YYYYMMDD)", type=int)
        parser.add_argument("-set", "--sendtype",  help="Tipo de Envio (Default: remoto)", choices=["remoto","local"], default="remoto")
        parser.add_argument("-p", "--process",  help="Tipo de proceso (Default: carga)", choices=["carga","recarga"], default="carga")
        parser.add_argument("-u", "--uuid",  help="Id de recarga")
        parser.add_argument("-o", "--only",  help="Solamente un tipo", choices=["kpi","alarm"])
        #poner en minuscula todos los argumentos
        args = parser.parse_args( [s.lower() for s in sys.argv[2:]] )
        #validaciones extras
        if args.enddate <> None and args.startdate == None:
            parser.error("argument -ed/--enddate: it's necessary the -sd/--startdate argument")        
        if args.startdate <> None and len(str(args.startdate)) <> 8 :
            parser.error( "argument -sd/--startdate: invalid len value: {}".format(len(str(args.startdate))) )
        if args.enddate <> None and len(str(args.enddate)) <> 8 :
            parser.error( "argument -ed/--enddate: invalid len value: {}".format(len(str(args.enddate))) )
        if args.enddate <> None and args.startdate <> None and args.startdate > args.enddate:
            parser.error("argument -ed/--enddate: enddate it's less than startdate")
        #Controlador
        cmFitel = CMFitelController(args)                        
    elif subProj == 'dump':        
        parser = argparse.ArgumentParser(usage="Carga Dumps", description="Comandos de las configuraciones huawei 2G/3G/4G. Por default cargan todos los comandos configurados")                            
        #lista de argumentos
        parser.add_argument("-l", "--list",  help="listado de comandos y repositorios disponibles", action="store_true")
        parser.add_argument("-c", "--command",  help="comando a ejecutar")
        parser.add_argument("-g", "--group", help="agrupacion elementos a ejecutar")
        parser.add_argument("-f", "--frequency", choices=["daily","weekly","all","manually"],  default="daily", help="Frecuencia de ejecución del comando")
        parser.add_argument("-e", "--environment", choices=["developer","production"], help="entorno de trabajo de la carga. Por defecto enviroment.cfg")
        args = parser.parse_args( [s.lower() for s in sys.argv[2:]] )
        
        if args.list:
            dumpIntroController = DumpIntroController()
            commands = dumpIntroController.getCommandsDesc()
            
            sources = []
            sources.append({"name":"rncs", "description":"RNC's"})
            sources.append({"name":"bscs", "description":"BSC's"})
            sources.append({"name":"enodesb", "description":"ENODOB's"})
            
            print "\nComandos\n--------"
            for command in commands:
                tabs = 2 if len(command['command']) >= 8 else 3                                            
                print command['command'] + repeat_to_length("\t\t", tabs) + command['freq'] + repeat_to_length("\t\t", tabs) + command['comments']
            print "\nAgrupaciones\n------------"
            for source in sources:
                tabs = 2 if len(source['name']) >= 8 else 3                                            
                print source['name'] + repeat_to_length("\t\t", tabs) + source['description']            
        else:
            dump = DumpController(args)
            dump.loadDumps()
            
    elif subProj == 'sicosiptel':
        #help
        if len(sys.argv)  == 3 and sys.argv[2] == HELP_COMMAND:
            print"\narg1\ttiempo [opcional] YYYYMMDD (default: Dia anterior)"
            sys.exit()            
        sicOsiptel = SICOsiptelController()
        #Carga o Recarga
        if len(sys.argv)  == 3 and (sys.argv[2]).upper() != "CARGA":
            sicOsiptel.reload()
        else:
            sicOsiptel.load(sys.argv[3:])
    elif subProj == 'lbs':
        lbs = LBSController()
        lbs.load()
    elif subProj == 'soc':
        parser = argparse.ArgumentParser(usage="Carga SOC", description="Carga de KQI's provenientes del SOC")
        parser.add_argument("-t", "--type",  choices=["vap","vac","cs",'ps'], default="cs", help="Tipo de carga")        
        parser.add_argument("-f","--force",  action='store_true', help="Sobreescribir asi exista data")
        #poner en minuscula todos los argumentos
        args = parser.parse_args( [s.lower() for s in sys.argv[2:]] )        
        SOCController(args)
    elif subProj == 'planificador':
        #help
        if len(sys.argv)  == 3 and sys.argv[2] == HELP_COMMAND:
            print"imprime algo"
            sys.exit()
        else:
            planificador =  PlanificadorController(sys.argv[2:])       
    else:        
        insertGeneralLog("ALERTA", "FINALIZADO", 'Subproyecto no existe ' + subProj)        
        ProjectUtils.printTerminalMessage("FINALIZADO", messages.NO_ACTION)                
        sys.exit()                  
                            
    