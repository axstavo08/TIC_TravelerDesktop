'''
Created on 28/11/2016

@author: C16915 - John Portella
'''

class Group(object):

    def __init__(self, idGroup, code, label, comments=None):
        self.__idGroup = idGroup
        self.__code = code
        self.__label = label
        self.__comments = comments

    def get_id_group(self):
        return self.__idGroup    

    def get_code(self):
        return self.__code

    def get_label(self):
        return self.__label

    def get_comments(self):
        return self.__comments

    def set_id_group(self, value):
        self.__idGroup = value
    
    def set_code(self, value):
        self.__code = value


    def set_label(self, value):
        self.__label = value


    def set_comments(self, value):
        self.__comments = value


class Command(object):
    def __init__(self, group=None, idCommand=None, code=None, label=None, realCommand=None,table=None, process=None, frequency=None, comments=None, state=None):
        self.__idCommand = idCommand
        self.__group = group
        self.__code = code
        self.__label = label
        self.__realCommand = realCommand
        self.__table = table
        self.__process = process
        self.__frequency = frequency
        self.__comments = comments
        self.__state = state

    def get_real_command(self):
        return self.__realCommand


    def set_real_command(self, value):
        self.__realCommand = value

        
    def get_id_command(self):
        return self.__idCommand


    def get_group(self):
        return self.__group


    def get_code(self):
        return self.__code


    def get_label(self):
        return self.__label


    def get_table(self):
        return self.__table


    def get_process(self):
        return self.__process


    def get_frequency(self):
        return self.__frequency


    def get_comments(self):
        return self.__comments


    def get_state(self):
        return self.__state


    def set_id_command(self, value):
        self.__idCommand = value


    def set_group(self, value):
        self.__group = value


    def set_code(self, value):
        self.__code = value


    def set_label(self, value):
        self.__label = value


    def set_table(self, value):
        self.__table = value


    def set_process(self, value):
        self.__process = value


    def set_frequency(self, value):
        self.__frequency = value


    def set_comments(self, value):
        self.__comments = value


    def set_state(self, value):
        self.__state = value        
                
