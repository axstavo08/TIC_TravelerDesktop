'''
Created on 28/11/2016

@author: C16915
'''

from enum import Enum

class Frequency(Enum):
    
    daily       = 'DAILY'
    weekly      = 'WEEKLY'
    all         = 'ALL'
    manually    = 'MANUALLY'

class Repository(Enum):
    
    rncs        = 'RNCS'
    bscs        = 'BSCS'    
    enodesb     = 'ENODESB'
    
    @classmethod        
    def repositoriesName(cls):        
        return [repositories[0] for repositories in cls.__members__.items()]
    
    @classmethod
    def status(cls):
        status = {}
        for repository in [repositories[1] for repositories in cls.__members__.items()]:
            status[repository] = 0
        return status  
    
    @classmethod
    def list(cls):        
        return [repositories[1] for repositories in cls.__members__.items()]          