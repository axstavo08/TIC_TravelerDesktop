# encoding: utf-8
'''
Created on 21/5/2015

@author: C16915

Este es el unico lugar de cambio de informacion en caso de que los campos de la BD
se modifiquen
'''

#_*_coding:utf-8_*_

from dump_model import Command
from dump_enum import Frequency, Repository

class DumpMapping(object):
    
    @staticmethod
    def convertDumpValidation(listObjs):
        listMapp = []
        for obj in listObjs:
            objMapp = {}
            objMapp['COMANDO'] = obj['COMANDO']
            objMapp['TABLA_SMART'] = obj['TABLA_SMART']
            objMapp['COLUMNA_GESTOR'] = obj['COLUMNA_GESTOR']
            objMapp['COLUMNA_SMART'] = obj['COLUMNA_SMART']
            objMapp['TIPO_DATO'] = obj['TIPO_DATO']
            objMapp['ESTADO'] = obj['ESTADO']
            listMapp.append(objMapp)
        return listMapp
    
    @staticmethod
    def columnsDictDump():
        listCommands = []
        listCommands.append({ 'ndict': ':idCommand', 'ncol' : 'IDDMPCOM' })        
        listCommands.append({ 'ndict': ':column_repo', 'ncol' : 'COLUMNA_GESTOR' })
        listCommands.append({ 'ndict': ':column_table', 'ncol' : 'COLUMNA_SMART' })
        listCommands.append({ 'ndict': ':data_type', 'ncol' : 'TIPO_DATO' })
        listCommands.append({ 'ndict': ':length', 'ncol' : 'LEN_DATO' })
        return listCommands
    
    @staticmethod
    def varUpdateDictDump():
        varsUpd = {}
        varsUpd['constraints'] = [{'column_name': 'IDDMPCOM', 'column_dict':':command'}, {'column_name': 'COLUMNA_GESTOR', 'column_dict':':column_repo'}]
        varsUpd['variables']   = [{'column_name': 'ESTADO', 'column_dict':':status'}]
        return varsUpd
        
    @staticmethod
    def convertNetworkController(listObjs):
        listMapp = []
        for obj in listObjs:
            objMapp = {}
            objMapp['CENTRAL'] = obj['CENTRAL']
            objMapp['IP_ADDRESS'] = obj['IP_ADDRESS']            
            listMapp.append(objMapp)
        return listMapp
    
    @staticmethod
    def convertValidColumns(listObjs):
        dictValidCols = {}
        for obj in listObjs:            
            dictValidCols[obj['CAMPO_DUMP']] = obj['CAMPO_ORACLE']
        return dictValidCols
    
    @staticmethod
    def convertToCommand(listObjs):
        command = None
        for obj in listObjs:
            command = Command()
            command.set_id_command(obj['IDDMPCOM'])
            command.set_code(obj['CODIGO'])
            command.set_label(obj['ETIQUETA'])
            command.set_real_command(obj['COMANDO_REAL']);
            command.set_table(obj['TABLA'])
            command.set_process(obj['PROCESO'])
            command.set_comments(obj['COMENTARIOS'])
            command.set_state((obj['ESTADO']))
            if obj['FRECUENCIA'] == "DIARIO":
                command.set_frequency(Frequency.daily)
            elif obj['FRECUENCIA'] == "SEMANA":                
                command.set_frequency(Frequency.weekly)
            elif obj['FRECUENCIA'] == "MANUAL":
                command.set_frequency(Frequency.manually)  
            command.set_group(Repository[(obj['GRUPO']).lower()])          
        return command
    
    @staticmethod
    def convertToCommandsName(listObjs): 
        commandsName = []
        for obj in listObjs:
            commandsName.append(obj['CODIGO'])
        return commandsName
    
    @staticmethod
    def convertFrequency(frequency):
        if frequency == Frequency.daily:
            return "DIARIO"
        elif frequency == Frequency.weekly:
            return "SEMANAL"
        elif frequency == Frequency.manually:
            return "MANUAL"
        else:
            return None
    
    @staticmethod
    def convertCommandsDesc(listObjs):
        commands = []
        for obj in listObjs:
            command = {}
            command['command'] = obj['COMANDO']
            command['freq'] = obj['FRECUENCIA']
            command['comments'] = obj['COMENTARIOS']
            commands.append(command)
        return commands