import copy_reg, types, json, os, multiprocessing
from common import OrderedSet, NumberUtils
from dump_transform import DumpTransform

def _pickle_method(m):
    if m.im_self is None:
        return getattr, (m.im_class, m.im_func.func_name)
    else:
        return getattr, (m.im_self, m.im_func.func_name)

copy_reg.pickle(types.MethodType, _pickle_method)

class DumpThread():
    
    def __init__(self, dirRepository, dirs, comTMPFolder, command, dictValidColumns):
        self.__dirRepository = dirRepository
        self.__dirs = dirs            
        self.__comTMPFolder= comTMPFolder
        self.__command = command
        self.__dictValidColumns = dictValidColumns        
        self.__dumpTransform = DumpTransform()
        
        self.__validatedColumns = {}
        self.__types = {}
        self.__lengths = {}
        self.__manageWork()        
    
    def getDescColumns(self):        
        return {'validated': self.__validatedColumns, 'types': self.__types, 'lengths': self.__lengths}    
    
    def __manageWork(self):
        #cantidad de procesadores a trabajar        
        cpus = multiprocessing.cpu_count()
        if cpus <= 2 :
            cpus = 1
        else:
            cpus = cpus - 2            
                
        pool = multiprocessing.Pool(processes=cpus, maxtasksperchild=10)
        listColumns = pool.map(self.worker, self.__dirs, chunksize=1)        
        for columns in listColumns:
            if columns is not None:                
                self.__validatedColumns.update(columns['validated'])
                self.__types.update(columns['types'])
                for key, value in columns['lengths'].iteritems():                    
                    if self.__lengths.has_key(key):                    
                        if self.__lengths[key] <= value * 2:
                            self.__lengths[key] = value * 2
                    else:
                        self.__lengths[key] = value * 2        
        pool.close()
        
    def worker(self, fileTXT):
        #print("Command: {} - PID {} - Filetext {}".format(self.__command.get_label(), os.getpid(), fileTXT ))        
        filename = os.path.join(self.__dirRepository, fileTXT)
        data = self.__dumpTransform.transformSource(filename, self.__command)
        validatedColumns = {}
        if data <> None:
            sdata = self.__getStructuredData(data)            
            #validar la existencia de la tabla del comando y de las columnas
            validatedColumns = self.__validateColumns(sdata)            
            #escoger file donde guardar
            fileJson = str(fileTXT) + ".json"
            #agregar info al file                       
            self.__addFile(fileJson, sdata['body'])
            #print 1/0                    
            return {'validated': validatedColumns, 'types': sdata['types'], 'lengths': sdata['lengths']}                                                               
        return None
    
    def __addFile(self, fileTransf, data):
        finalFileTransf = os.path.join(self.__comTMPFolder, fileTransf)        
        with open(finalFileTransf, 'w') as outfile:
            json.dump(data, outfile)
            
    def __getStructuredData(self, rows):        
        #listar el total de campos (sirve asi los campos sean dinamicos)
        keys = OrderedSet()
        types = {}
        lengths = {}
        for row in rows:
            for key in row.keys():                                            
                if not types.has_key(key):                    
                    if not NumberUtils.isNumeric(row[key]):                        
                        lengths[key] = len(row[key])
                    else:
                        lengths[key] = 0
                    keys.add(key)
                    types[key] = type(row[key])  
                else:
                    if not NumberUtils.isNumeric(row[key]):                        
                        if lengths[key] < len(row[key]):
                            lengths[key] = len(row[key])
                        
                    if not isinstance(types[key], str) and isinstance(type(row[key]), str) :
                        types[key] = type(row[key])
                        
                                                    
        return {'head' : keys, 'types': types, 'body' : rows, 'lengths': lengths}   
    
    def __validateColumns(self, data):        
        columnsRepo = data['head']                    
        validatedColumns = self.__transformColumnsName(columnsRepo)        
        return validatedColumns
    
    def __transformColumnsName(self, columnsRepo):
        columnsDict = {}
        for column in columnsRepo:
            newColumn = column.replace(" ", "_")            
            columnsDict[column] = newColumn.upper()
            #cambiar campos reservados            
            if self.__dictValidColumns.has_key(column):
                columnsDict[column] = self.__dictValidColumns[column]            
        return columnsDict 
        