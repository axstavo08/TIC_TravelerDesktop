'''
Created on 11/6/2015

@author: C16915
'''

import multiprocessing, os, collections
import xml.etree.ElementTree as ET
from common import NumberUtils, FileUtils, ListUtils
from itertools import repeat
from collections import defaultdict
from dump_commands import Command
from dump_enum import Repository
from fileinput import filename

def ltecellTransform(filename):   
    try:                         
        rootEnodeb = None
        if os.name == "nt":
            #abrir el XML                
            tree = ET.parse(filename)
            rootEnodeb = tree.getroot().find("configData").find("class[@name='BTS3900']")    
            root = rootEnodeb.find("object")
        else:
            tree = ET.parse(filename)
            root = tree.getroot()
        #COMANDO ENODEBFUNCTION_BTS3900 NIVEL ENODOB                
        command = root.find("class[@name='ENODEBFUNCTION_BTS3900']")                       
        objectpar = command.find("object")
        if objectpar is None:
            return None
        parameters = collections.OrderedDict()                   
        for parameter in objectpar.iter("parameter"):
            att = parameter.attrib
            if NumberUtils.isNumeric(att['value']) :
                parameters[att['name']] = NumberUtils.toNumber(att['value'])
            else:    
                parameters[att['name']] = att['value']
        atsEnodeBFunction = parameters                   
        #COMANDO OMCH_BTS3900 NIVEL ENODOB    
        command = root.find("class[@name='OMCH_BTS3900']")        
        if command is not None:        
            objectpar = command.find("object")
            parameters = collections.OrderedDict()
            for parameter in objectpar.iter("parameter"):
                att = parameter.attrib
                if NumberUtils.isNumeric(att['value']) :
                    parameters[att['name']] = NumberUtils.toNumber(att['value'])
                else:    
                    parameters[att['name']] = att['value']
        atsOMCH = parameters    
        #COMANDO CNOPERATORTA_BTS3900 NIVEL ENODOB    
        command = root.find("class[@name='CNOPERATORTA_BTS3900']")        
        objectpar = command.find("object")
        parameters = collections.OrderedDict()
        if objectpar is not None:
            for parameter in objectpar.iter("parameter"):
                att = parameter.attrib
                if NumberUtils.isNumeric(att['value']) :
                    parameters[att['name']] = NumberUtils.toNumber(att['value'])
                else:    
                    parameters[att['name']] = att['value']
        atsCnope = parameters  
        #COMANDO CELL_BTS3900 NIVEL DE CELDA
        atsCells = []
        command = root.find("class[@name='CELL_BTS3900']")
        for objectpar in  command.findall("object"):
            parameters = collections.OrderedDict()
            for parameter in objectpar.iter("parameter"):
                att = parameter.attrib
                if NumberUtils.isNumeric(att['value']) :
                    parameters[att['name']] = NumberUtils.toNumber(att['value'])
                else:    
                    parameters[att['name']] = att['value']
            atsCells.append(parameters)                                                     
        #UNION DE ATTRIBUTOS
        for dictCell in atsCells:                        
            dictCell.update(atsEnodeBFunction)   
            dictCell.update(atsCnope)
            dictCell.update(atsOMCH)    
        return atsCells
    except Exception as e:
        if os.name == "nt":
            if rootEnodeb is not None:
                raise e            
        return None
    
def ltepdschcfgTransform(filename):                        
    try:        
        rootEnodeb = None
        if os.name == "nt":
            #abrir el XML                
            tree = ET.parse(filename)
            rootEnodeb = tree.getroot().find("configData").find("class[@name='BTS3900']")    
            root = rootEnodeb.find("object")
        else:
            tree = ET.parse(filename)
            root = tree.getroot()   
        #COMANDO PDSCHCFG_BTS3900 NIVEL CELDA                
        atsCells = []
        command = root.find("class[@name='PDSCHCFG_BTS3900']")
        for objectpar in  command.findall("object"):
            parameters = collections.OrderedDict()
            for parameter in objectpar.iter("parameter"):
                att = parameter.attrib
                if NumberUtils.isNumeric(att['value']) :
                    parameters[att['name']] = NumberUtils.toNumber(att['value'])
                else:    
                    parameters[att['name']] = att['value']
            atsCells.append(parameters)                                  
        return atsCells
    except Exception as e:
        if os.name == "nt":
            if rootEnodeb is not None:
                raise e            
        return None

def ltelevelCellTransform(filename, xmlCommand):                        
    try:        
        rootEnodeb = None
        if os.name == "nt":
            #abrir el XML                
            tree = ET.parse(filename)
            rootEnodeb = tree.getroot().find("configData").find("class[@name='BTS3900']")    
            root = rootEnodeb.find("object")
        else:
            tree = ET.parse(filename)
            root = tree.getroot()                   
        #COMANDO ENODEBFUNCTION_BTS3900 NIVEL ENODOB                
        command = root.find("class[@name='ENODEBFUNCTION_BTS3900']")                       
        objectpar = command.find("object")
        if objectpar is None:
            return None
        parameters = collections.OrderedDict()                   
        for parameter in objectpar.iter("parameter"):
            att = parameter.attrib
            if att['name'] in ['ENODEBID','ENODEBFUNCTIONNAME']:
                if NumberUtils.isNumeric(att['value']) :
                    parameters[att['name']] = NumberUtils.toNumber(att['value'])
                else:    
                    parameters[att['name']] = att['value']
        atsEnodeBFunction = parameters  
        #COMANDO PDSCHCFG_BTS3900 NIVEL CELDA                
        atsCells = []
        command = root.find("class[@name='" + xmlCommand  + "']")
        for objectpar in  command.findall("object"):
            parameters = collections.OrderedDict()
            for parameter in objectpar.iter("parameter"):
                att = parameter.attrib
                if NumberUtils.isNumeric(att['value']) :
                    parameters[att['name']] = NumberUtils.toNumber(att['value'])
                else:    
                    parameters[att['name']] = att['value']
            atsCells.append(parameters)   
        #UNION DE ATTRIBUTOS
        for dictCell in atsCells:                        
            dictCell.update(atsEnodeBFunction)  
        return atsCells
    except Exception as e:
        if os.name == "nt":
            if rootEnodeb is not None:
                raise e            
        return None

def ltelevelEnodeTransform(filename, xmlCommand):                        
    try:        
        rootEnodeb = None
        if os.name == "nt":
            #abrir el XML                
            tree = ET.parse(filename)
            rootEnodeb = tree.getroot().find("configData").find("class[@name='BTS3900']")    
            root = rootEnodeb.find("object")
        else:
            tree = ET.parse(filename)
            root = tree.getroot()                   
        #COMANDO ENODEBFUNCTION_BTS3900 NIVEL ENODOB                
        command = root.find("class[@name='ENODEBFUNCTION_BTS3900']")                       
        objectpar = command.find("object")
        if objectpar is None:
            return None
        parameters = collections.OrderedDict()                   
        for parameter in objectpar.iter("parameter"):
            att = parameter.attrib
            if att['name'] in ['ENODEBID']:
                if NumberUtils.isNumeric(att['value']) :
                    parameters[att['name']] = NumberUtils.toNumber(att['value'])
                else:    
                    parameters[att['name']] = att['value']
        atsEnodeBFunction = parameters  
        #COMANDO PDSCHCFG_BTS3900 NIVEL CELDA                
        atsCells = []
        command = root.find("class[@name='" + xmlCommand  + "']")
        for objectpar in  command.findall("object"):
            parameters = collections.OrderedDict()
            for parameter in objectpar.iter("parameter"):
                att = parameter.attrib
                if NumberUtils.isNumeric(att['value']) :
                    parameters[att['name']] = NumberUtils.toNumber(att['value'])
                else:    
                    parameters[att['name']] = att['value']
            atsCells.append(parameters)   
        #UNION DE ATTRIBUTOS
        for dictCell in atsCells:                        
            dictCell.update(atsEnodeBFunction)  
        return atsCells
    except Exception as e:
        if os.name == "nt":
            if rootEnodeb is not None:
                raise e            
        return None    
      
def lteeintrafcellTransform(filename):
    try:            
        #abrir el XML                
        tree = ET.parse(filename)
        rootEnodeb = tree.getroot().find("configData").find("class[@name='BTS3900']")    
        root = rootEnodeb.find("object")   
        #COMANDO ENODEBFUNCTION_BTS3900 NIVEL ENODOB                   
        variables = [{'oldValue': 'ENODEBFUNCTIONNAME' , 'newValue' : 'LOCALENODEBFUNCTIONNAME'}, 
                     {'oldValue': 'ENODEBID' ,           'newValue' : 'LOCALENODEBID'}]
        command = root.find("class[@name='ENODEBFUNCTION_BTS3900']")                       
        objectpar = command.find("object")
        if objectpar is None:
            return None
        parameters = collections.OrderedDict()                   
        for parameter in objectpar.iter("parameter"):
            att = parameter.attrib                        
            if att['name'] in [variable['oldValue'] for variable in variables]:
                #cambia el antiguo nombre por el nuevo
                att['name'] = (filter(lambda variable: variable['oldValue'] == att['name'] , variables)[0])['newValue']
                if NumberUtils.isNumeric(att['value']) :
                    parameters[att['name']] = NumberUtils.toNumber(att['value'])
                else:    
                    parameters[att['name']] = att['value']  
                    
        atsEnodeBFunction = parameters  
        #COMANDO EUTRANINTRAFREQNCELL_BTS3900 NIVEL CELDA
        atsEIntraFreq = []   
        variables = [{'oldValue': 'LOCALCELLID' , 'newValue' : 'LOCALNCELLID'}]             
        command = root.find("class[@name='EUTRANINTRAFREQNCELL_BTS3900']")                        
        for objectpar in  command.findall("object"):
            parameters = collections.OrderedDict()                   
            for parameter in objectpar.iter("parameter"):
                att = parameter.attrib
                #cambia unicamente los valores que se encuentran en el array variables
                if att['name'] in [variable['oldValue'] for variable in variables]:
                    att['name'] = (filter(lambda variable: variable['oldValue'] == att['name'] , variables)[0])['newValue']
                if NumberUtils.isNumeric(att['value']) :
                    parameters[att['name']] = NumberUtils.toNumber(att['value'])
                else:    
                    parameters[att['name']] = att['value']  
            atsEIntraFreq.append(parameters)               
        #COMANDO CELL_BTS3900 NIVEL DE CELDA
        atsCells = []
        variables = [{'oldValue': 'LOCALCELLID' , 'newValue' : 'LOCALNCELLID'}, 
                     {'oldValue': 'CELLID' ,      'newValue' : 'LOCALCELLID'},
                     {'oldValue': 'CELLNAME' ,    'newValue' : 'LOCALCELLNAME'}]
        command = root.find("class[@name='CELL_BTS3900']")
        for objectpar in  command.findall("object"):
            parameters = collections.OrderedDict()
            for parameter in objectpar.iter("parameter"):
                att = parameter.attrib
                if att['name'] in [variable['oldValue'] for variable in variables]:
                    #cambia el antiguo nombre por el nuevo
                    att['name'] = (filter(lambda variable: variable['oldValue'] == att['name'] , variables)[0])['newValue']
                    if NumberUtils.isNumeric(att['value']) :
                        parameters[att['name']] = NumberUtils.toNumber(att['value'])
                    else:    
                        parameters[att['name']] = att['value']
                        
            atsCells.append(parameters) 
        
        #UNION DE ATRIBUTOS        
        for dictCell in atsCells:
            dictCell.update(atsEnodeBFunction) 
        newatsEIntraFreq = []                                     
        for hocell in atsEIntraFreq:
            moreAtts = collections.OrderedDict() 
            moreAtts.update((filter(lambda atsCell: atsCell['LOCALNCELLID'] == hocell['LOCALNCELLID'] , atsCells)[0])) 
            moreAtts.update(hocell)                                        
            newatsEIntraFreq.append(moreAtts)
                
        return newatsEIntraFreq
    except Exception as e:
        if rootEnodeb is not None:
            raise e            
        return None
         
def gcellTransform(fileData):
    #CELDAS
    attsCells = DumpTransform.transfToDictNetContr(fileData['ADD GCELL:'])
    #CELDAS BLOQUEADAS
    if fileData.has_key('SET GCELLADMSTAT:') :
        attsCellsAdm = DumpTransform.transfToDictNetContr(fileData['SET GCELLADMSTAT:'])            
    else:
        attsCellsAdm = defaultdict(dict)            
    # ATTS DE BSC
    variables = [{'oldValue': 'SYSOBJECTID' , 'newValue' : 'BSC'}]
    attsBscName = DumpTransform.transfToDictNetContr(fileData['SET SYS:'], False)
    DumpTransform.changeVariablesDict(attsBscName, variables)   
    #CAMBIAR NOMBRE DE LAS BSC QUE TIENEN NAME DIFERENTE
    if attsBscName['BSC'] == 'WBSC2':
        attsBscName['BSC'] ='BSC02-LCLS'  
    elif attsBscName['BSC'] == 'HBSC01':
        attsBscName['BSC'] ='BSC01'
    # ATTS ADDRESS DE BSC    
    variables = [{'oldValue': 'OMUIP' , 'newValue' : 'IP_BSC'}]
    attsBscAddress = DumpTransform.transfToDictNetContr(fileData['ADD EMSIP:'], False)
    DumpTransform.changeVariablesDict(attsBscAddress, variables)                
    
    #UNION DE ATRIBUTOS
    localCells = defaultdict(dict)
    for l in (attsCells, attsCellsAdm):
        for elem in l:
            if not elem.has_key('ADMSTAT'):
                elem['ADMSTAT'] = 'UNLOCK'                    
            localCells[elem['CELLID']].update(elem)
            localCells[elem['CELLID']].update(attsBscName)
            localCells[elem['CELLID']].update(attsBscAddress)    
    return localCells.values()

def gbtsTransform1(fileData):
    #BTS
    attsBtss = DumpTransform.transfToDictNetContr(fileData['ADD BTS:'])
    #BTSTRANS
    attsBtssTrans = DumpTransform.transfToDictNetContr(fileData['SET BTSTRANS:'])
    #ATTS DE BSC
    variables = [{'oldValue': 'SYSOBJECTID' , 'newValue' : 'BSC'}]
    attsBscName = DumpTransform.transfToDictNetContr(fileData['SET SYS:'], False)
    DumpTransform.changeVariablesDict(attsBscName, variables)   
    #CAMBIAR NOMBRE DE LAS BSC QUE TIENEN NAME DIFERENTE
    if attsBscName['BSC'] == 'WBSC2':
        attsBscName['BSC'] ='BSC02-LCLS'  
    elif attsBscName['BSC'] == 'HBSC01':
        attsBscName['BSC'] ='BSC01'
    # JOIN DE ATRIBUTOS
    auxAtts = {d['BTSID'] : d for d in attsBtssTrans} 
    for d in attsBtss:
        if d['BTSID'] in auxAtts:    
            d.update(auxAtts[d['BTSID']])
        d.update(attsBscName)
    return attsBtss

def gcellTemplateTransform(fileData, mainCommand):
    #MAINROWS
    atts = DumpTransform.transfToDictNetContr(fileData[mainCommand])
    # ATTS DE BSC
    variables = [{'oldValue': 'SYSOBJECTID' , 'newValue' : 'BSC'}]
    attsBscName = DumpTransform.transfToDictNetContr(fileData['SET SYS:'], False)
    DumpTransform.changeVariablesDict(attsBscName, variables)   
    #CAMBIAR NOMBRE DE LAS BSC QUE TIENEN NAME DIFERENTE
    if attsBscName['BSC'] == 'WBSC2':
        attsBscName['BSC'] ='BSC02-LCLS'  
    elif attsBscName['BSC'] == 'HBSC01':
        attsBscName['BSC'] ='BSC01'                                            
    #UNION DE ATRIBUTOS
    for dictCell in atts:
        dictCell.update(attsBscName)                                           
    return atts

def gbtsTransform(filesData):
    btss = []
    for fileData in filesData:
        #BTS
        attsBtss = DumpTransform.transfToDictNetContr(fileData['ADD BTS:'])
        #BTSTRANS
        attsBtssTrans = DumpTransform.transfToDictNetContr(fileData['SET BTSTRANS:'])
        #ATTS DE BSC
        variables = [{'oldValue': 'SYSOBJECTID' , 'newValue' : 'BSC'}]
        attsBscName = DumpTransform.transfToDictNetContr(fileData['SET SYS:'], False)
        DumpTransform.changeVariablesDict(attsBscName, variables)   
        #CAMBIAR NOMBRE DE LAS BSC QUE TIENEN NAME DIFERENTE
        if attsBscName['BSC'] == 'WBSC2':
            attsBscName['BSC'] ='BSC02-LCLS'  
        elif attsBscName['BSC'] == 'HBSC01':
            attsBscName['BSC'] ='BSC01'
        # JOIN DE ATRIBUTOS
        auxAtts = {d['BTSID'] : d for d in attsBtssTrans} 
        for d in attsBtss:
            if d['BTSID'] in auxAtts:    
                d.update(auxAtts[d['BTSID']])
            d.update(attsBscName)
        btss.extend(attsBtss)
    return btss

def cellbind2btsTransform(filesData):
    cells = []
    for fileData in filesData:
        #TRXS
        attsCells = DumpTransform.transfToDictNetContr(fileData['ADD CELLBIND2BTS:'])
        # ATTS DE BSC
        variables = [{'oldValue': 'SYSOBJECTID' , 'newValue' : 'BSC'}]
        attsBscName = DumpTransform.transfToDictNetContr(fileData['SET SYS:'], False)
        DumpTransform.changeVariablesDict(attsBscName, variables)   
        #CAMBIAR NOMBRE DE LAS BSC QUE TIENEN NAME DIFERENTE
        if attsBscName['BSC'] == 'WBSC2':
            attsBscName['BSC'] ='BSC02-LCLS'  
        elif attsBscName['BSC'] == 'HBSC01':
            attsBscName['BSC'] ='BSC01'                                            
        #UNION DE ATRIBUTOS
        for dictCell in attsCells:
            dictCell.update(attsBscName)                                           
        cells.extend(attsCells)
    return cells

def ucellsetupTransform(fileData):
    #CELDAS
    attsCells = DumpTransform.transfToDictNetContr(fileData['ADD UCELLSETUP:'])
    for attsCell in attsCells:
        if attsCell.has_key('LOGICRNCID'): 
            attsCell['ID'] = str(attsCell['LOGICRNCID']) + str((attsCell['CELLID']))
        else:
            attsCell['ID'] = attsCell['CELLID']
        attsCell['LAC_FINAL'] = int((attsCell['LAC']).strip("H'"), 16)
        attsCell['RAC'] = int((attsCell['RAC']).strip("H'"), 16)
        attsCell['SAC'] = int((attsCell['SAC']).strip("H'"), 16)
    #CELDAS ACTIVAS
    if fileData.has_key('ACT UCELL:') :        
        attsActCells = DumpTransform.transfToDictNetContr(fileData['ACT UCELL:'])
        for attActCells in attsActCells:
            if attActCells.has_key('LOGICRNCID'): 
                attActCells['ID'] = str(attActCells['LOGICRNCID']) + str((attActCells['CELLID'])) 
            else:
                attActCells['ID'] = attActCells['CELLID']
            
            attActCells.update({'ACTSTATUS': 'ACTIVATED'})         
    else:
        attsActCells = []
    # ATTS DE RNC
    variables = [{'oldValue': 'SYSOBJECTID' , 'newValue' : 'RNC'}]
    attsRncName = DumpTransform.transfToDictNetContr(fileData['SET SYS:'], False)
    DumpTransform.changeVariablesDict(attsRncName, variables)   
    # ATTS ADDRESS DE RNC    
    variables = [{'oldValue': 'OMUIP' , 'newValue' : 'IP_RNC'}]
    attsRncAddress = DumpTransform.transfToDictNetContr(fileData['ADD EMSIP:'], False)
    DumpTransform.changeVariablesDict(attsRncAddress, variables) 
    # ATTS RNC
    attsRncBasic = DumpTransform.transfToDictNetContr(fileData['ADD URNCBASIC:'])
    mainRnc = {}
    for attRncBasic in attsRncBasic:
        if attRncBasic['LOADSHARINGTYPE'] == 'MASTER':
            mainRnc = attRncBasic    
            break                    
                       
    #UNION DE ATRIBUTOS
    mergeCells = ListUtils.merge_lists(attsCells, attsActCells, 'ID')
            
    for dictCell in mergeCells:
        dictCell.update(attsRncName)   
        dictCell.update(attsRncAddress)
        dictCell.update(mainRnc)            
        
        if dictCell.has_key('LOGICRNCID'):
            for attRncBasic in attsRncBasic:
                if dictCell['LOGICRNCID'] == attRncBasic['RNCID']:
                    dictCell.update({'LOADSHARINGTYPE':attRncBasic['LOADSHARINGTYPE']})  
                    dictCell.update({'REDUNDANCYTYPE':attRncBasic['REDUNDANCYTYPE']})
                    break                                                                                            
        if not dictCell.has_key('ACTSTATUS'):
            dictCell['ACTSTATUS'] = 'DEACTIVATED'
        del dictCell['ID']    
    return mergeCells    

def ippathTransform(fileData):    
    if fileData.has_key('ADD IPPATH:'):                         
        #IPS
        attsIps = DumpTransform.transfToDictNetContr(fileData['ADD IPPATH:'])                
        # ATTS DE RNC
        variables = [{'oldValue': 'SYSOBJECTID' , 'newValue' : 'RNC'}]
        attsRncName = DumpTransform.transfToDictNetContr(fileData['SET SYS:'], False)
        DumpTransform.changeVariablesDict(attsRncName, variables)   
        # ATTS ADDRESS DE RNC    
        variables = [{'oldValue': 'OMUIP' , 'newValue' : 'IP_RNC'}]
        attsRncAddress = DumpTransform.transfToDictNetContr(fileData['ADD EMSIP:'], False)
        DumpTransform.changeVariablesDict(attsRncAddress, variables) 
        # ATTS RNC
        attsRncBasic = DumpTransform.transfToDictNetContr(fileData['ADD URNCBASIC:'])
        mainRnc = {}
        for attRncBasic in attsRncBasic:
            if attRncBasic['LOADSHARINGTYPE'] == 'MASTER':
                mainRnc = attRncBasic    
                break
                
        #UNION DE ATRIBUTOS
        for dictIp in attsIps:
            dictIp.update(attsRncName)   
            dictIp.update(attsRncAddress)
            dictIp.update(mainRnc)
            
            if dictIp.has_key('LOGICRNCID'):
                for attRncBasic in attsRncBasic:
                    if dictIp['LOGICRNCID'] == attRncBasic['RNCID']:
                        dictIp.update({'LOADSHARINGTYPE':attRncBasic['LOADSHARINGTYPE']})  
                        dictIp.update({'REDUNDANCYTYPE':attRncBasic['REDUNDANCYTYPE']})
                        break 
            
        return attsIps
    return None

def adjnodeTransform(fileData):
    if fileData.has_key('ADD ADJNODE:'):                    
        #IPS
        attsAdys = DumpTransform.transfToDictNetContr(fileData['ADD ADJNODE:'])                
        # ATTS DE RNC
        variables = [{'oldValue': 'SYSOBJECTID' , 'newValue' : 'RNC'}]
        attsRncName = DumpTransform.transfToDictNetContr(fileData['SET SYS:'], False)
        DumpTransform.changeVariablesDict(attsRncName, variables)   
        # ATTS ADDRESS DE RNC    
        variables = [{'oldValue': 'OMUIP' , 'newValue' : 'IP_RNC'}]
        attsRncAddress = DumpTransform.transfToDictNetContr(fileData['ADD EMSIP:'], False)
        DumpTransform.changeVariablesDict(attsRncAddress, variables) 
        # ATTS RNC
        attsRncBasic = DumpTransform.transfToDictNetContr(fileData['ADD URNCBASIC:'])
        mainRnc = {}
        for attRncBasic in attsRncBasic:
            if attRncBasic['LOADSHARINGTYPE'] == 'MASTER':
                mainRnc = attRncBasic    
                break
             
        #UNION DE ATRIBUTOS
        for dictAdy in attsAdys:
            dictAdy.update(attsRncName)   
            dictAdy.update(attsRncAddress)
            dictAdy.update(mainRnc)
            
            if dictAdy.has_key('LOGICRNCID'):
                for attRncBasic in attsRncBasic:
                    if dictAdy['LOGICRNCID'] == attRncBasic['RNCID']:
                        dictAdy.update({'LOADSHARINGTYPE':attRncBasic['LOADSHARINGTYPE']})  
                        dictAdy.update({'REDUNDANCYTYPE':attRncBasic['REDUNDANCYTYPE']})
                        break             
        return attsAdys

def gucellTemplateTransform(fileData, mainCommand):
    if fileData.has_key(mainCommand):
        #CELDAS
        attsCells = DumpTransform.transfToDictNetContr(fileData[mainCommand])
        # ATTS DE RNC
        attsRncName = DumpTransform.transfToDictNetContr(fileData['SET SYS:'], False)        
        #UNION DE ATTRIBUTOS
        for dictCell in attsCells:
            dictCell.update({'RNC_NAME': attsRncName['SYSOBJECTID']})
        return attsCells
    return None

class DumpTransform(object):
    
    '''
    TRANSFORMACION
    '''
    def transformSource(self, filename, command):              
        if command.get_group() == Repository.enodesb:            
            fileData = self.__getLTETransform(filename, command)        
        elif command.get_group() == Repository.bscs:
            fileData = self.__getGSMTransform(filename, command)            
        elif command.get_group() == Repository.rncs:        
            fileData = self.__getUMTSTransform(filename, command)
        return fileData
    
    '''
    ENODESB COMMANDS
    '''    
    
    def enodesBProcess(self, dirs, dirRepository, command):
        print("entra")
        try:
            cpus = multiprocessing.cpu_count()
            if cpus > 4 :
                cpus -= 2
        except:
            cpus = 2
        pool = multiprocessing.Pool(processes = cpus, maxtasksperchild=20)     
        
        if command == Command.ltecell:       
            total = pool.map(ltecellTransform, zip(dirs,repeat(dirRepository)))
        #elif command == Command.lteeintrafcell:            
        #    total = pool.map(lteeintrafcellTransform, zip(dirs,repeat(dirRepository)))
        elif command == Command.ltepdschcfg:            
            total = pool.map(ltepdschcfgTransform, zip(dirs,repeat(dirRepository)))                    
        pool.close()
        total = [ent for sublist in total if sublist is not None for ent in sublist  ]                            
        return total
    
    '''
    BSCS y RNCS COMMAND
    '''
    
    def __getLTETransform(self, filename, command):
        
        if command.get_process() == "ENODESB_CELL_TRANSFORM":            
            return ltecellTransform(filename)
        elif command.get_process() == "ENODESB_PDSCHCFG_TRANSFORM":                      
            return ltepdschcfgTransform(filename)
        elif command.get_process() == "ENODESB_EUTRANINTRAFREQNCELL_TRANSFORM":
            return lteeintrafcellTransform(filename)       
        elif command.get_process() == "ENODESB_GEN_CELL_TRANSFORM":
            mainCommand = command.get_real_command()
            return ltelevelCellTransform(filename, mainCommand)
        elif command.get_process() == "ENODESB_GEN_ENODEB_TRANSFORM":                
            mainCommand = command.get_real_command()
            return ltelevelEnodeTransform(filename, mainCommand)
        else:
            raise Exception("Invalid process:" + command.get_process())
        
    def __getGSMTransform(self, filename, command):
        if command.get_process() == "BSC_GCELL_TRANSFORM":
            #COMANDOS
            commandString = ['ADD GCELL:', 'SET GCELLADMSTAT:', 'ADD EMSIP:', 'SET SYS:']            
            fileData = self.__extCommDataNetContr1(commandString, filename)            
            return gcellTransform(fileData)
        elif command.get_process() == "BSC_GBTS_TRANSFORM":
            #COMANDOS
            commandString = ['ADD BTS:','SET BTSTRANS:', 'SET SYS:']
            fileData = self.__extCommDataNetContr1(commandString, filename)
            return gbtsTransform1(fileData)
        elif command.get_process() == "BSC_GEN_TRANSFORM":
            #COMANDOS
            mainCommand = command.get_real_command()
            commandString = [mainCommand, 'SET SYS:']
            fileData = self.__extCommDataNetContr1(commandString, filename)
            return gcellTemplateTransform(fileData, mainCommand)
        else:
            raise Exception("Invalid process:" + command.get_process())
                            
    def __getUMTSTransform(self, filename, command):
        if command.get_process() == "RNC_UCELLSETUP_TRANSFORM":
            #COMANDOS
            commandString = ['ADD UCELLSETUP:', 'ACT UCELL:', 'ADD EMSIP:', 'SET SYS:', 'ADD URNCBASIC:']
            fileData = self.__extCommDataNetContr1(commandString, filename)
            return ucellsetupTransform(fileData)
        
        elif command.get_process() == "RNC_IPPATH_TRANSFORM":
            #COMANDOS
            commandString = ['ADD IPPATH:', 'ADD EMSIP:', 'SET SYS:', 'ADD URNCBASIC:']
            fileData = self.__extCommDataNetContr1(commandString, filename)
            return ippathTransform(fileData)        
        elif command.get_process() == "RNC_ADJNODE_TRANSFORM":
            #COMANDOS
            commandString = ['ADD ADJNODE:', 'ADD EMSIP:', 'SET SYS:', 'ADD URNCBASIC:']
            fileData = self.__extCommDataNetContr1(commandString, filename)
            return adjnodeTransform(fileData) 
        elif command.get_process() == "RNC_GEN_TRANSFORM":
            #COMANDOS
            mainCommand = command.get_real_command()
            commandString = [mainCommand, 'SET SYS:']
            fileData = self.__extCommDataNetContr1(commandString, filename)
            return gucellTemplateTransform(fileData, mainCommand)
        else:
            raise Exception("Invalid process:" + command.get_process())
        
    def __extCommDataNetContr1(self, commandStrings, filename):                           
        #obtener las lineas en una lista 
        cellsWithoutFormat = FileUtils.getLinesStartsWith(filename, commandStrings, True)                
        return cellsWithoutFormat
    
    def __extCommDataNetContr(self, command, commandStrings, dirRepository):                   
        dirs = os.listdir(dirRepository)            
        #obtener la data para cada archivo
        cells = []
        for fileTXT in dirs:
            filename = os.path.join(dirRepository, fileTXT)
            #obtener las lineas en una lista 
            cellsWithoutFormat = FileUtils.getLinesStartsWith(filename, commandStrings, True)                
            cells.append(cellsWithoutFormat)         
        return cells       
    
    @staticmethod
    def transfToDictNetContr(cellsWithoutFormat, isList = True):
        #darle formato a las lineas
        atsCells = []            
        for cell in cellsWithoutFormat: 
            #formato general
            #cell = cell.upper();
            cell = ((cell.split(':'))[1]).strip()
            cell = cell.strip(";")
            #descomponer parametros            
            parameters = collections.OrderedDict() 
            for attCell in cell.split(","):
                attCellArray = attCell.split("=")
                attname = ((attCellArray[0]).strip()).upper() 
                attvalue = ((attCellArray[1]).strip('\"')).strip()
                #parameters[attname] = attvalue
                if NumberUtils.isNumeric(attvalue) :
                    parameters[attname] = NumberUtils.toNumber(attvalue)
                else:    
                    parameters[attname] = attvalue     
            atsCells.append(parameters)            
        
        if isList:            
            return atsCells
        else:
            if len(atsCells) > 0:
                return atsCells[0]
            else:
                return []     
        
    @staticmethod
    def changeVariablesDict(dictVar, variables):
        for variable in variables:
            valueAtt = dictVar[variable['oldValue']]
            del dictVar[variable['oldValue']]
            dictVar[variable['newValue']] = valueAtt        