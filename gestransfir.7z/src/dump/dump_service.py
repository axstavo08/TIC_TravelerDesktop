# encoding: utf-8
'''
Created on 18/5/2015

@author: C16915
'''

import os, shutil, gzip, zipfile, re, json, subprocess, shlex
from dump_utils import DumpUtils
from common import ProjectUtils, PyFileTransfer, OrderedSet, NumberUtils, Logger
from dump_repository import DumpRepository
from dump_transform import DumpTransform
from dump_thread import DumpThread
from dump_enum import Repository

class DumpService(object):
        
    def __init__(self):
        #logger        
        self.__logger = (Logger("dump", self.__class__.__name__)).getLogger()
        self.__loggerDev  = (Logger("dump", self.__class__.__name__, True)).getLogger()        
        #repository
        self.__dumpRepository = DumpRepository() 
        self.__dumpTransform = DumpTransform()
                
    def __repositoryDirectory(self, repository):
        return os.path.join(ProjectUtils.getFilesDirectory(),'dump', repository.value)        
    
    '''
    EXTRACCION DE DATA
    '''
    def loadRepository(self, repository, clean = False):
        
        #Verifica si el directorio del repositorio existe, en caso de que no lo crea
        repositoryDirectory = self.__repositoryDirectory(repository)        
        if not os.path.exists(repositoryDirectory):
            os.makedirs(repositoryDirectory)
            os.chmod(repositoryDirectory, 0777)
        if repository == Repository.enodesb:
            #list enodosB 
            #enodesB = [i['ENODOB'] for i in self.__dumpRepository.listEnodesB()]                                
            #ftp al U2000            
            t = PyFileTransfer('ftp_u2000')
            t.connection()
            remoteDirectory = "/export/home/sysm/opt/oss/server/var/fileint/cm/GExport"
            listFilesRemotes = t.listFiles(remoteDirectory, True)
            #formato de los files validos             
            regex=re.compile("^GExport_([A-Z]{2}[T|L][0-9]{4}|MBTS)_.*_\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}_\d{14}\.xml\.gz$")                                                            
            #listar solo los files validos, creacion de un diccionario con los enodosb encontrados en el repositorio
            dictFiles = {}            
            for l in listFilesRemotes:
                if regex.search(l['name']):
                    ip = re.search('\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}',l['name']).group(0)
                    if ip in dictFiles:
                        if dictFiles[ip]['mtime'] < l['mtime']:
                            dictFiles[ip] = l
                    else:
                        dictFiles[ip] = l                                            
            #limpiar el directorio local
            shutil.rmtree(repositoryDirectory)
            os.makedirs(repositoryDirectory)
            #Pasar los archivos remotes al directorio local            
            for nodebfile in dictFiles:                                            
                #pasar el empaquetado
                t.get(dictFiles[nodebfile]['name'], remoteDirectory, repositoryDirectory)
                #desempaquetar
                fileNamePack = os.path.join(repositoryDirectory, dictFiles[nodebfile]['name'])
                fileName     = os.path.join(repositoryDirectory, nodebfile + ".xml")                
                inPck = gzip.GzipFile(fileNamePack, 'rb')
                s = inPck.read()
                inPck.close()                
                outPck = open(fileName, 'wb')
                outPck.write(s)
                outPck.close()                
                #eliminar paquete
                os.remove(fileNamePack) 
                #aligerar xml
                if os.name == "posix" and clean :                    
                    shXML = os.path.join(ProjectUtils.getBinDirectory(),'clearLTExml.sh')
                    subprocess.call(shlex.split(shXML + ' ' + fileName ))
                                        
            t.disconnect()                
        elif repository == Repository.bscs:
            controllers = self.__dumpRepository.get2GHWControllers()
            self.__extractNetController(repository, controllers, repositoryDirectory)            
        elif repository == Repository.rncs:
            controllers = self.__dumpRepository.get3GHWControllers()
            self.__extractNetController(repository, controllers, repositoryDirectory)                      
               
    def __extractNetController(self, repository, controllers, repositoryDirectory):                
        #agregar info de cada controlador
        for controller in controllers:
            try:
                #ftp al controlador  
                t = PyFileTransfer('ftp_centrales', controller['IP_ADDRESS'])
                t.connection()
                remoteDirectories = ["/bam/version_a/ftp/export_cfgmml","/bam/version_b/ftp/export_cfgmml"]                
                countNExistRemoteDirs = 0
                for remoteDirectory in remoteDirectories:                    
                    try:
                        #obtener el ultimo archivo
                        lastFile = t.getLastFile(remoteDirectory, True, "CFGMML")                
                        if lastFile is not None :
                            #enviar el archivo zip al repositorio local
                            t.get(lastFile['name'], remoteDirectory, repositoryDirectory)                
                            #descomprimir
                            fileNameZip = os.path.join(repositoryDirectory, lastFile['name'])
                            fileName    = os.path.join(repositoryDirectory, controller['CENTRAL'] + '__' + str(lastFile['mtime']) + '.txt')
                            with zipfile.ZipFile(fileNameZip) as z:
                                with open(fileName, 'wb') as f:
                                    f.write(z.read(z.namelist()[0]))                            
                            #eliminar zip
                            os.remove(fileNameZip)
                    except Exception as e:
                        if str(e).find("not a directory") == -1:
                            DumpUtils.insertDumpLogWarningStatus(self.__logger, self.__loggerDev, "SIGUIENTE",(repository.value).upper(), 'FALLIDO', 'EXTRACCION', 'Transferencia - Controller:' + controller['CENTRAL'] + ' Ip:' +controller['IP_ADDRESS'] + ' Message:' + str(e))
                        else:
                            countNExistRemoteDirs +=1
                if countNExistRemoteDirs == 2:
                    DumpUtils.insertDumpLogWarningStatus(self.__logger, self.__loggerDev, "SIGUIENTE",(repository.value).upper(), 'FALLIDO', 'EXTRACCION', 'Transferencia - Controller:' + controller['CENTRAL'] + ' Ip:' +controller['IP_ADDRESS'] + ' Message: not found a directory')
                #desconexion del ftp
                t.disconnect()
                #listar todos los files del controlador en el repositorio
                localfilesController = [fileR for fileR in os.listdir(repositoryDirectory) if fileR.startswith(controller['CENTRAL'])]
                localfilesController.sort(key=lambda x: x, reverse= True)                
                #eliminar el resto
                for otherFileController in localfilesController[1:]:
                    os.remove(os.path.join(repositoryDirectory, otherFileController))                
            except Exception as e:                
                DumpUtils.insertDumpLogWarningStatus(self.__logger, self.__loggerDev, "SIGUIENTE",(repository.value).upper(), 'FALLIDO', 'EXTRACCION', 'Transferencia - Controller:' + controller['CENTRAL'] + ' Ip:' +controller['IP_ADDRESS'] + ' Message:' + str(e))
                
        #eliminar info de controladores no encendidos
        for fileRepository in os.listdir(repositoryDirectory):
            exists = False
            for controller in controllers:
                if fileRepository.startswith(controller['CENTRAL']):
                    exists = True            
            if not exists:
                os.remove(os.path.join(repositoryDirectory, fileRepository))        
                    
    '''
    TRANSFORMACION Y CARGA DE DATA
    '''    
    def transformCommand(self, command, idProcess):        
        #Verifica si existe la tabla temporal en el proyecto
        tmpFolder = ProjectUtils.getTMPDirectory()
        if not os.path.exists(tmpFolder):
            os.makedirs(tmpFolder)
        #Crea la tabla temporal para el comando
        comTMPFolder = os.path.join(tmpFolder, idProcess)
        os.makedirs(comTMPFolder)            
        #Obtener las columnas a transformar
        dictValidColumns = self.__dumpRepository.getTransfColumns()
        #obtener directorio de archivos
        dirRepository = self.__repositoryDirectory(command.get_group())
        dirs = os.listdir(dirRepository)            
        #Cargar los hilos multiproceso        
        dumpThread = DumpThread(dirRepository, dirs, comTMPFolder, command, dictValidColumns)
        return dumpThread.getDescColumns()
    
    def loadCommand(self, idProcess, command, descColumns):        
        tmpFolder = ProjectUtils.getTMPDirectory()
        comTMPFolder = os.path.join(tmpFolder, idProcess)
        tm = self.__dumpRepository.getTransactionManager()        
        try:                    
            tm.begin()
            isFirstLoad = True
            #actualizar columnas
            self.__updateColumns(tm, command, descColumns)     
            #actualizar status de los campos                          
            self.__validateStatusColumns(tm, command, descColumns['validated'])
            #cargar informacion                     
            for fileTXT in os.listdir(comTMPFolder):
                #Abrir cada archivo json generado en la etapa de transformacion
                fileName = os.path.join(comTMPFolder, fileTXT)            
                if os.path.isfile(fileName):
                    with open(fileName) as data_file:    
                        data = json.load(data_file)
                        #guardar la data en la BD                        
                        self.__dumpRepository.loadData(tm, command.get_code(), data, descColumns['validated'], isFirstLoad) 
                        if isFirstLoad:
                            isFirstLoad = False
            #eliminar tabla temporal
            if os.path.exists(comTMPFolder):
                shutil.rmtree(comTMPFolder)
            tm.commit()
         
        except Exception as e:
            if os.path.exists(comTMPFolder):
                shutil.rmtree(comTMPFolder)
            tm.rollback()
            raise e
            
    def __updateColumns(self, tm, command, descColumns):
        columnsRepo = (descColumns['types'] ).keys()
        columnsTypeRepo =  descColumns['types']
        columnsLengthRepo = descColumns['lengths']
        validatedColumns = descColumns['validated']
        #columnas de la BD
        columns =  self.__dumpRepository.getColumnsDumpByCommandName(command.get_code(), tm)        
        columnsName = [a['COLUMNA_GESTOR'] for a in columns]        
        #Agregar columnas nuevas y actualizar estado
        newColumns =  [a for a in columnsRepo if a not in columnsName]            
        newColumnsA = []
        for newColumn in newColumns:            
            if (columnsTypeRepo[newColumn]).__name__ in ('str','unicode'):
                typeC = 'VARCHAR'
            else: 
                typeC = 'NUMBER'                                
            newColumnsA.append({ 'idCommand': command.get_id_command() ,'column_repo': newColumn, 'column_table': validatedColumns[newColumn], 'data_type': typeC, 'length': columnsLengthRepo[newColumn] })                                    
        self.__dumpRepository.updateColumnsDump(tm,command.get_code(), newColumnsA)         
        return validatedColumns
    
    def __getStructuredData(self, rows):        
            #listar el total de campos (sirve asi los campos sean dinamicos)
            keys = OrderedSet()
            types = {}
            for row in rows:
                for key in row.keys():                                
                    if types.has_key(key):
                        if not NumberUtils.isNumeric(row[key]):
                            types[key] = type(row[key])
                    else:    
                        keys.add(key)
                        types[key] = type(row[key])                        
            
            return {'head' : keys, 'types': types, 'body' : rows}      
                                                
    #Validacion  
    def __validateColumns(self, tm, commandName, data):        
        columnsRepo = data['head']        
        columnsTypeRepo = data['types']        
        validatedColumns = self.__transformColumnsName(columnsRepo)
        #columnas de la BD
        columns =  self.__dumpRepository.getColumnsDumpByCommandName(commandName, tm)
        columnsName = [a['COLUMNA_GESTOR'] for a in columns]        
        #Agregar columnas nuevas y actualizar estado
        newColumns =  [a for a in columnsRepo if a not in columnsName]            
        newColumnsA = []
        for newColumn in newColumns:
            if (columnsTypeRepo[newColumn]).__name__ in ('str','unicode'):
                typeC = 'VARCHAR'
            else: 
                typeC = 'NUMBER'                    
            newColumnsA.append({ 'column_repo': newColumn, 'column_table': validatedColumns[newColumn], 'data_type': typeC})                    
        self.__dumpRepository.updateColumnsDump(tm,commandName, newColumnsA)
        return validatedColumns
                 
    def __validateStatusColumns(self, tm, command, validatedColumns):        
        #columnas actuales del comando
        columnsRepo = validatedColumns.keys()
        #columnas de la BD
        columns =  self.__dumpRepository.getColumnsDumpByCommandName(command.get_code(), tm)
        columnsName = [a['COLUMNA_GESTOR'] for a in columns]        
        offColumns =  [a for a in columnsName if a not in columnsRepo]
        onColumns = []        
        for column in columns:            
            if column['ESTADO'] == '0' and column['COLUMNA_GESTOR'] in columnsRepo:
                onColumns.append(column['COLUMNA_GESTOR'])        
        self.__dumpRepository.updateStatusColumnsDump(tm, command.get_id_command(), offColumns, onColumns)       
                
    def __transformColumnsName(self, columnsRepo):
        columnsDict = {}
        for column in columnsRepo:
            newColumn = column.replace(" ", "_")            
            columnsDict[column] = newColumn.upper()
            #cambiar campos reservados
            dictValidColumns = self.__dumpRepository.getTransfColumns()
            if dictValidColumns.has_key(column):
                columnsDict[column] = dictValidColumns[column]            
        return columnsDict           