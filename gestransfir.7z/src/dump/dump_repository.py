# encoding: utf-8
'''
Created on 18/5/2015

@author: C16915
'''

from common import OracleDB, OracleDBTrans, ProjectUtils
from dump_mapping import DumpMapping
import cx_Oracle

class DumpRepository(object):
    
    def __init__(self):
        self.__conn = OracleDB(ProjectUtils.envDB("oracle", "db_smart"))
        self.__dumpTable = self.__conn.callFunction('PK_DUMP.OBTENER_TABLA_DUMP', cx_Oracle.STRING)
                
    def listEnodesB(self):                                    
        return self.__conn.executeProcedureOUTCursor("PK_DUMP.SP_LISTAR_ENODOSB_ACTIVOS")
        
    '''
        Tablas Mapeadas
    '''
   
    def getCommandByName(self, commandName):
        listDB = self.__conn.executeProcedureOUTCursor("PK_DUMP.SP_OBTENER_COMANDO", [commandName])
        return DumpMapping.convertToCommand(listDB)
    
    def getCommandsByRepAndFreq(self, repository, frequency ):                
        listDB = self.__conn.executeProcedureOUTCursor("PK_DUMP.SP_OBTENER_COMANDOS", [repository, frequency])
        commandsName = DumpMapping.convertToCommandsName(listDB)        
        commands = []
        for commandName in commandsName:
            commands.append(self.getCommandByName(commandName))
        return commands
    
    def getCommandsByFreq(self, frequency ):
        listDB = self.__conn.executeProcedureOUTCursor("PK_DUMP.SP_OBTENER_COMANDOS", [None, frequency])
        commandsName = DumpMapping.convertToCommandsName(listDB)        
        commands = []
        for commandName in commandsName:
            commands.append(self.getCommandByName(commandName))
        return commands
    
    def getCommandsDesc(self):
        listDB = self.__conn.executeProcedureOUTCursor("PK_DUMP.SP_OBTENER_COMANDOS_DESC")        
        return DumpMapping.convertCommandsDesc(listDB)
        
    def getColumnsDumpByCommandName(self, commandName, tm = None):
        if tm is None:
            listDB = self.__conn.executeProcedureOUTCursor("PK_DUMP.SP_LISTAR_COLUMNAS", [commandName])
        else:
            listDB = tm.executeProcedureOUTCursor("PK_DUMP.SP_LISTAR_COLUMNAS", [commandName])        
        return DumpMapping.convertDumpValidation(listDB)
    
    def get2GHWControllers(self):
        listDB = self.__conn.executeProcedureOUTCursor("PK_DUMP.SP_LISTAR_BSCS_ACTIVOS")
        return DumpMapping.convertNetworkController(listDB)     
    
    def get3GHWControllers(self):
        listDB = self.__conn.executeProcedureOUTCursor("PK_DUMP.SP_LISTAR_RNCS_ACTIVOS")
        return DumpMapping.convertNetworkController(listDB)
    
    def getTransfColumns(self, tm = None):                
        if tm is None:
            listDB = self.__conn.executeProcedureOUTCursor("PK_DUMP.SP_LISTAR_CAMPOS_TRANSF")
        else:
            listDB = tm.executeProcedureOUTCursor("PK_DUMP.SP_LISTAR_CAMPOS_TRANSF")
        return DumpMapping.convertValidColumns(listDB)

    '''
        Procesos Transaccionales
    '''
   
    def getTransactionManager(self):
        return  OracleDBTrans(ProjectUtils.envDB("oracle", "db_smart"))
                
    def updateColumnsDump(self, tm, commandName, newColumns):        
        existsCT = True if self.__conn.callFunction('PK_DUMP.EXISTE_TABLA_COMANDO', cx_Oracle.NUMBER, [commandName]) == 1 else False
        commandTable = self.__conn.callFunction('PK_DUMP.OBTENER_TABLA_COMANDO', cx_Oracle.STRING, [commandName])                        
        try:        
            if len(newColumns) != 0:                
                #agregar las nuevas columnas a su tabla correspondiente
                listnColumns = []
                for column in newColumns:
                    listnColumns.append({'column_name' : column['column_table'], 'column_type': column['data_type'], 'column_length': column['length']})                
                if  not existsCT:                                                            
                    tm.createTable(commandTable, listnColumns)                    
                else:
                    tm.newColumnsTable(commandTable, listnColumns)                                                                         
                columnsDict = DumpMapping.columnsDictDump()                                                        
                tm.bulkInsertWithDict(self.__dumpTable, columnsDict, newColumns)                                                     
        except Exception as e:
            newExistsCT = True if self.__conn.callFunction('PK_DUMP.EXISTE_TABLA_COMANDO', cx_Oracle.NUMBER, [commandName]) == 1 else False            
            if not existsCT and newExistsCT :
                tm.dropTable(commandTable)            
            raise e
    
    def loadData(self, tm, commandName, data, validatedColumns, isFirstLoad = False):        
        commandTable = self.__conn.callFunction('PK_DUMP.OBTENER_TABLA_COMANDO', cx_Oracle.STRING, [commandName])
        columnsCommandTable = self.getColumnsDumpByCommandName(commandName, tm)                
        typeColumnsCommand = {}
        for column in columnsCommandTable:
            typeColumnsCommand[column['COLUMNA_GESTOR']] = column['TIPO_DATO']         
        #limpiar tabla
        if isFirstLoad:
            tm.clearTable(commandTable)                        
        #insertar cada campo
        columns = []
        transfRows = []                
        for key in validatedColumns:
            columns.append({'ncol' : validatedColumns[key], 'ndict': ':' + validatedColumns[key]})                    
        for row in data:                                    
            transfRow = dict.fromkeys(validatedColumns.values())                 
            for key in row:                                              
                typeColumn = typeColumnsCommand[key]                                    
                    
                if typeColumn == "VARCHAR":                                        
                    if isinstance( row[key], int ):
                        row[key] = str(row[key])
                    transfRow[validatedColumns[key]] = row[key]                    
                else:
                    transfRow[validatedColumns[key]] = row[key]                
            transfRows.append(transfRow)                                    
        tm.bulkInsertWithDict(commandTable, columns, transfRows)        
                                      
    def updateStatusColumnsDump(self, tm, idCommand, offColumns, onColumns):
        #Actualizar Estados            
        varsUpdate = DumpMapping.varUpdateDictDump()  
        if len(onColumns) != 0:
            data = []
            for onColumn in onColumns:
                data.append({'command' : idCommand, 'column_repo': onColumn, 'status': 1})              
            tm.bulkUpdateWithDict(self.__dumpTable, varsUpdate['variables'], data, varsUpdate['constraints'])    
        if len(offColumns) != 0:
            data = []
            for offColumn in offColumns:
                data.append({'command' : idCommand, 'column_repo': offColumn, 'status': 0})
            tm.bulkUpdateWithDict(self.__dumpTable, varsUpdate['variables'], data, varsUpdate['constraints'])
    
    def insertCommandExecStat(self, idCommand, startDate, endDate):
        self.__conn.executeProcedure("PK_DUMP.SP_INSERTAR_ESTAD_COMANDO", [idCommand, startDate, endDate])         