# encoding: utf-8
'''
Created on 15/5/2015

@author: C16915
'''

import sys
from dump_business import DumpBusiness
from dump_repository import DumpRepository
from dump_utils import DumpUtils
from dump_enum import Frequency, Repository
from common import Logger, messages, ProjectUtils, GlobalConfig

class DumpIntroController(object):
    def __init__(self, params=[]):
        self.__dumpRepository = DumpRepository()
    
    def getCommandsDesc(self):
        return self.__dumpRepository.getCommandsDesc()

class DumpController(object):

    def __init__(self, params=[]):
        #logger                
        self.logger     = (Logger("dump", self.__class__.__name__)).getLogger()
        self.loggerDev  = (Logger("dump", self.__class__.__name__, True)).getLogger()
        #business
        self.__dumpBusiness = DumpBusiness()   
        
        #validar argumentos
                
        #command        
        if params.command is None:
            self.__command = None
        else:            
            self.__command = self.__dumpBusiness.getCommandByName(params.command)                                                      
            if self.__command is None:
                DumpUtils.insertDumpLogWarning(self.logger, self.loggerDev, "FINALIZADO", "Comando no existente: " + params.command)
                ProjectUtils.printTerminalMessage("FINALIZADO", messages.NO_ACTION)                                               
                sys.exit()
        #group
        if params.group is None:
            self.__repository = None
        else:
            if params.group not in Repository.repositoriesName():                                
                DumpUtils.insertDumpLogWarning(self.logger, self.loggerDev, "FINALIZADO", "Repositorio no existente: " + params.group)
                ProjectUtils.printTerminalMessage("FINALIZADO", messages.NO_ACTION)                                               
                sys.exit()    
            else:
                self.__repository = Repository[params.group]  
        
        #frequency
        self.__frequency = Frequency[(params.frequency).lower()]
        
        if self.__command is None:                                
            if self.__frequency is None:
                DumpUtils.insertDumpLogWarning(self.logger, self.loggerDev, "FINALIZADO", "Frecuencia incorrecta: " + params.frequency)
                ProjectUtils.printTerminalMessage("FINALIZADO", messages.NO_ACTION)                                               
                sys.exit()        
        #configuracion general
        if params.environment is not None:
            conf = GlobalConfig()
            conf.environment = params.environment            
                
        
    def loadDumps(self):
        if self.__command is not None:
            self.__dumpBusiness.loadCommand(self.__command)
        elif self.__repository is not None:            
            self.__dumpBusiness.loadRepository(self.__repository, self.__frequency)
        else:
            self.__dumpBusiness.loadAllCommands(self.__frequency)                  