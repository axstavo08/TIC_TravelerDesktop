# encoding: utf-8
'''
Created on 18/5/2015

@author: C16915
'''

from enum import Enum

class Command(Enum):    
                        
            
    def repository(self):                    
        for repository in Repository.list():                       
            for command in (repository).commands():
                if self == command:
                    return repository
             
    @classmethod        
    def commandsName(cls):        
        return [command[0] for command in cls.__members__.items()]
           
    @classmethod
    def list(cls):
        return [command[1] for command in cls.__members__.items()]
    
    @classmethod
    def status(cls):
        status = {}
        for command in [commands[1] for commands in cls.__members__.items()]:
            status[command] = 0
        return status    
        
class Repository(Enum):
    
    rncs        = 'rncs'
    bscs        = 'bscs'    
    enodesb     = 'enodesb'
            
    def commands(self):
        commandsArray = []        
        if self == Repository.enodesb :
            commandsArray.append(Command.ltecell)
            #commandsArray.append(Command.lteeintrafcell)
            commandsArray.append(Command.ltepdschcfg)
            commandsArray.append(Command.ltecellalgoswitch)
            commandsArray.append(Command.ltecelldrxpara)            
            return commandsArray
        elif self == Repository.rncs :            
            commandsArray.append(Command.ucellsetup)
            commandsArray.append(Command.upcpich)
            commandsArray.append(Command.ippath)
            commandsArray.append(Command.adjnode)
            commandsArray.append(Command.u2gncell)
            #commandsArray.append(Command.uext2gcell)
            #commandsArray.append(Command.uinterfreqncell)
            #commandsArray.append(Command.uintrafreqncell)
            #commandsArray.append(Command.uext3gcell)
            #commandsArray.append(Command.ultencell)
            #commandsArray.append(Command.ultecell)
            return commandsArray
        elif self == Repository.bscs :                
            commandsArray.append(Command.gcell)
            commandsArray.append(Command.gtrx)
            commandsArray.append(Command.gtrxdev)
            commandsArray.append(Command.gtrxchan)
            commandsArray.append(Command.gcellgprs)
            commandsArray.append(Command.ptpbvc)
            commandsArray.append(Command.gbts)
            commandsArray.append(Command.cellbind2bts)            
            #commandsArray.append(Command.g2gncell)
            #commandsArray.append(Command.gext2gcell)
            #commandsArray.append(Command.g3gncell)
            #commandsArray.append(Command.gext3gcell)
            return commandsArray
            
    @classmethod        
    def repositoriesName(cls):        
        return [repositories[0] for repositories in cls.__members__.items()]
    
    @classmethod
    def list(cls):        
        return [repositories[1] for repositories in cls.__members__.items()]
    
    @classmethod
    def status(cls):
        status = {}
        for repository in [repositories[1] for repositories in cls.__members__.items()]:
            status[repository] = 0
        return status    