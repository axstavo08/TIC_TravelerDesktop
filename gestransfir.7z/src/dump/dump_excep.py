'''
Created on 20/5/2015

@author: C16915
'''

class RepositoryError(Exception):
    
    def __init__(self):            
        self.message = 'EXTRACCION'