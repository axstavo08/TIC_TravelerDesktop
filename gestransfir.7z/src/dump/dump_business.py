# encoding: utf-8
'''
Created on 15/5/2015

@author: C16915
'''

import sys, uuid
from dump_commands import Command
from dump_service import DumpService
from dump_excep import RepositoryError
from dump_utils import DumpUtils
from dump_repository import DumpRepository
from common import Logger
from datetime import datetime
from dump_enum import Repository
from dump_mapping import DumpMapping  

class DumpBusiness(object):
    
    def __init__(self):        
        #logger        
        self.logger = (Logger("dump", self.__class__.__name__)).getLogger()
        self.loggerDev  = (Logger("dump", self.__class__.__name__, True)).getLogger()
        #status
        self.__statusRep = Repository.status()
        self.__statusCom = Command.status()
        #repository
        self.__dumpRepository = DumpRepository()
        #service
        self.__dumpService = DumpService()
        #Error
        self.__errorExtract = ""     
       
    '''
    Metodos publicos
    ----------------
    Auxiliares
    ''' 
    
    def getCommandByName(self, commandName):
        return self.__dumpRepository.getCommandByName(commandName)
    
    def getCommandsByRepAndFreq(self, repository, frequency):
        realFrequency = DumpMapping.convertFrequency(frequency)
        return self.__dumpRepository.getCommandsByRepAndFreq(repository.value, realFrequency)
    
    def getCommandsByFreq(self, frequency):
        realFrequency = DumpMapping.convertFrequency(frequency)
        return self.__dumpRepository.getCommandsByFreq(realFrequency)
    
    '''
    Metodos publicos
    ----------------
    Cantidad de comandos a ejecutar
    '''
    def loadAllCommands(self, frequency):
        #extraer todos los repositorio
        for repository in Repository.list():
            self.__extract(repository)             
        #sys.exit()
        # revisar cada comando    
        commands = self.getCommandsByFreq(frequency)
        for command in commands:
            self.__transformLoad(command)
                    
    def loadRepository(self, repository, frequency):                                
        #extraer el repositorio del comando
        self.__extract(repository)
        #transformacion y carga        
        commands = self.getCommandsByRepAndFreq(repository, frequency)                
        for command in commands:
            self.__transformLoad(command)        
    def loadCommand(self, command):                      
        #extraer el repositorio del comando
        self.__extract(command.get_group())        
        #transformacion y carga
        self.__transformLoad(command)
    
    '''
    Metodos privados
    ----------------
    niveles ETL 
    La extraccion es a nivel de repositorio, la transformacion y carga a nivel de comando
    '''            
    def __extract(self, repository):
        try:
            self.__dumpService.loadRepository(repository, True)           
            self.__statusRep[repository] = 2
        except:
            self.__statusRep[repository] = 1
            self.__errorExtract = sys.exc_info()  
            self.loggerDev.error(self.__errorExtract)      
                                
    def __transformLoad(self, command):    
        #status inicial
        status = 'REALIZADO'             
        #generar la hora de inicio
        startTime = datetime.now()
        level = "EXTRACCION"
        try:             
            if self.__statusRep[command.get_group()] == 1:
                raise RepositoryError        
            level = 'TRANSFORMACION'
            idProcess = str(uuid.uuid1())                    
            descColumns = self.__dumpService.transformCommand(command, idProcess)                      
            level = 'CARGA'
            self.__dumpService.loadCommand(idProcess, command, descColumns)                               
        except RepositoryError:                                    
            status = 'FALLIDO'
            level  = 'EXTRACCION'            
            DumpUtils.insertDumpLogError(self.loggerDev, self.__errorExtract)                        
        except Exception:
            status = 'FALLIDO'            
            DumpUtils.insertDumpLogError(self.loggerDev, sys.exc_info())            
        finally:
            #log de finalizacion del proceso
            endTime = datetime.now()
            if status == 'FALLIDO':
                appStatus = "ERROR"
            else:
                appStatus = "INFO" 
                self.__dumpRepository.insertCommandExecStat(command.get_id_command(), startTime.strftime('%Y%m%d%H%M%S'), endTime.strftime('%Y%m%d%H%M%S'))               
            message = "Inicio:%s Fin:%s" % (startTime.strftime('%d/%m/%Y %H:%M:%S'), endTime.strftime('%d/%m/%Y %H:%M:%S'))
            DumpUtils.insertDumpLogInfo(self.logger, self.loggerDev, command.get_code(), appStatus, status, level, message)      