'''
Created on 7/5/2015

@author: C16915
'''

from common import OracleDB, ProjectUtils
import cx_Oracle

class CMFitelRepository(object):
    

    def __init__(self):        
        self.__conn = OracleDB(ProjectUtils.envDB("oracle", "db_smart"))
            
    def getKpis2GHW(self, currentDate, nextDate, subproject):                
        return self.__conn.executeProcedureOUTCursor("PK_CMF_CARGAS.SP_2GHW_KPI", [currentDate, nextDate, subproject], False)
    
    def getAlarms2GHW(self, currentDate, nextDate, subproject):                    
        return self.__conn.executeProcedureOUTCursor("pk_cmf_cargas.SP_2GHW_ALARM_HIST", [currentDate, nextDate, subproject], False)        
              
    ''' Recarga de fechas vacias '''
    def putEmptyFiles(self, project, currentDate, technology, dataType, sendType, uuid):
        self.__conn.executeProcedure("pk_cmf_cargas.SP_AGREGAR_RECARGA", [project, technology, dataType, currentDate, sendType, uuid])
    
    def getEmptyFiles(self, sendType, localId):
        return self.__conn.executeProcedureOUTCursor("pk_cmf_cargas.SP_OBTENER_RECARGAS", [sendType, localId])
    
    def deleteEmptyFile(self, project, currentDate, technology, dataType, sendType, uuid):
        self.__conn.executeProcedure("pk_cmf_cargas.sp_eliminar_recarga", [project, technology, dataType, currentDate, sendType, uuid])

    ''' Cambio de nombre a Columnas '''
    def getColumnNameController(self, technology, dataType, column):
        return self.__conn.callFunction("pk_cmf_cargas.FUNC_OBTENER_NOMBRECOLUMNA", cx_Oracle.STRING, [column, technology, dataType])