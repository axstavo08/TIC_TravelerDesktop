'''
Created on 8/5/2015

@author: C16915
'''

import os
from common import CSVUtils, PyFileTransfer
from cmfitel_repository import CMFitelRepository
from cmfitel_utils import CMFitelUtils

class CMFitelService(object):
                
    def changeColumnName(self, dateType, technology, columns):
        
        cmfitelRepository = CMFitelRepository()   
                            
        newColumns = []
        for column in columns:
            newColumns.append( cmfitelRepository.getColumnNameController(technology, dateType, column))  
        return newColumns
    
    def createAndSendCSV(self, technology, fileName, data, headers):
        directoryContainer = ('nokia' if not 'HW' in technology else 'huawei')
        fileCSVDirectory = os.path.join(CMFitelUtils.getLocalFilesDirectory() , directoryContainer)
        CSVUtils.exportRecordsToCSV(os.path.join(fileCSVDirectory, fileName), data, headers)        
        #Transferencia via SFTP                        
        t = PyFileTransfer('ftp_calidad3')
        #t = PyFileTransfer('ftp_fitel')            
        t.connection()        
        if not t.existDirectory(directoryContainer):
            t.mkdir(directoryContainer)      
        t.put(fileName, directoryContainer, fileCSVDirectory)                            
        t.disconnect()
        
    def createLocalCSV(self, technology, uuid, fileName, data, headers):
        directoryContainer = ('nokia' if not 'HW' in technology else 'huawei')
        technologyDirectory = os.path.join(CMFitelUtils.getLocalFilesDirectory() , directoryContainer)
        fileCSVDirectory = os.path.join(technologyDirectory,uuid)
        #Crear Carpeta Local
        if not os.path.exists(fileCSVDirectory):            
            os.makedirs(fileCSVDirectory)
            os.chmod(fileCSVDirectory, 0777)
        CSVUtils.exportRecordsToCSV(os.path.join(fileCSVDirectory, fileName), data, headers)