'''
Created on 16/7/2015

@author: C16915
'''
import os
from common import ProjectUtils, DateUtils


class CMFitelUtils(object):
       
    @staticmethod   
    def insertCMFitelLogWarning(logger, loggerDev, status, message):   
        ProjectUtils.insertLogWarning(logger, loggerDev, "CMFITEL", "ALERTA", status, message)
    
    @staticmethod
    def insertCMFitelLogError(logger, sys_exc):
        ProjectUtils.insertErrorFileLog(logger, sys_exc)
    
    @staticmethod       
    def insertCMFitelLogInfo(logger, loggerDev, subproject, tipo, status, message):
        newMessage = "[%s][%s] %s" % (subproject, status, message)
        newMessageBD = "[%s] %s" % (subproject, message)
        ProjectUtils.insertLogInfo(logger, loggerDev, "CMFITEL", tipo, status, newMessageBD)        
        print newMessage  
    
    @staticmethod
    def getFileName(project, typeProj, startDateNumber, endDateNumber):
        BASE_NAME = 'FITELXX_YYY_immddaaaa_hhmmss_fmmddaaaa_hhmmss.csv'
        fileName = BASE_NAME
        #Proyecto        
        if project == 'SG':
            fileName = fileName.replace('XX', '09')
        elif project == 'CS':
            fileName = fileName.replace('XX', '12')
        elif project == 'CN':
            fileName = fileName.replace('XX', '13')
        #Tipo Proyecto
        if typeProj == 'KPI':
            fileName = fileName.replace('YYY', 'KPI')
        elif typeProj == 'CER':
            fileName = fileName.replace('YYY', 'CER')
        elif typeProj == 'ABI':
            fileName = fileName.replace('YYY', 'ABI')
        #Fechas
        fileName = fileName.replace('immddaaaa_hhmmss', (DateUtils.getDatewithHourSinceNumber(startDateNumber)).strftime('%m%d%Y_%H%M%S'))
        fileName = fileName.replace('fmmddaaaa_hhmmss', (DateUtils.getDatewithHourSinceNumber(endDateNumber)).strftime('%m%d%Y_%H%M%S'))
        
        return fileName
    
    @staticmethod
    def getDestineDirectory():     
        return ''   
    
    @staticmethod
    def getLocalFilesDirectory():
        return os.path.join(ProjectUtils.getFilesDirectory(), 'cmfitel')