'''
Created on 5/4/2016

@author: C16915 - John Portella
'''

import sys
from common import Logger, DateUtils, DateType
from cmfitel_repository import CMFitelRepository
from cmfitel_enums import Technology, DataType, SendType
from cmfitel_service import CMFitelService
from cmfitel_utils import CMFitelUtils

class CMFitelProcess(object):
    

    def __init__(self, currentDate, sendType, subproject, technology, dataType, uuid=None, isRecharge=False, endDate=None):
        
        #logger        
        self.logger     = (Logger("cmfitel", self.__class__.__name__)).getLogger()
        self.loggerDev  = (Logger("cmfitel", self.__class__.__name__, True)).getLogger()   
                
        #argumentos
        if dataType == DataType.kpi:
            self.__currentDate = DateUtils.convertDateUntilHourToNumber(currentDate)            
            if endDate is None:
                self.__nextDate = DateUtils.convertDateUntilHourToNumber(DateUtils.addTime(currentDate, DateType.hour, 1))
            else:
                self.__nextDate = DateUtils.convertDateUntilHourToNumber(endDate)  
        elif dataType == DataType.alarm:            
            self.__currentDate = DateUtils.convertDateUntilDayToNumber(currentDate)
            if endDate is None:
                self.__nextDate = DateUtils.convertDateUntilDayToNumber(DateUtils.addTime(currentDate, DateType.day, 1))
            else:
                self.__nextDate = DateUtils.convertDateUntilDayToNumber(endDate)                         
        self.__subproject = subproject
        self.__sendType = sendType
        self.__technology = technology
        self.__dataType = dataType
        self.__uuid = uuid
        self.__isRecharge = isRecharge                
        #inicializacion del service
        self.__cmfitelService = CMFitelService()        
        #inicializacion del repository
        self.__cmfitelRepository = CMFitelRepository()
    
    def getStatus(self):
        return self.__status
                            
    def run(self):        
        status = 'INICIO' #status inicial        
        startRunTime = DateUtils.now() #generar la hora de inicio                                
        
        try:  
            #CARGA DE INFORMACION
            kpiInf = None         
            if   self.__technology == Technology.t2ghw and self.__dataType == DataType.kpi:
                #obtener la data
                kpiInf = self.__cmfitelRepository.getKpis2GHW(self.__currentDate, self.__nextDate, self.__subproject.value)        
            elif self.__technology == Technology.t2ghw and self.__dataType == DataType.alarm:                
                kpiInf = self.__cmfitelRepository.getAlarms2GHW(self.__currentDate, self.__nextDate, self.__subproject.value)                                
            #obtener el nombre del archivo
            fileName = CMFitelUtils().getFileName(self.__subproject.value, self.__dataType.value, self.__currentDate, self.__nextDate)
            #verificar que no este vacio
            if len(kpiInf['data']) == 0:
                status = 'VACIO'
                self.__cmfitelRepository.putEmptyFiles(self.__subproject.value, self.__currentDate, self.__technology.value, self.__dataType.value, self.__sendType.value, self.__uuid)
            else:
                #TIPO DE ENVIO
                columns = self.__cmfitelService.changeColumnName(self.__dataType.value, self.__technology.value, [columns[0] for columns in kpiInf['description']] )
                if self.__sendType == SendType.remote:
                    #creacion del archivo ftp                
                    self.__cmfitelService.createAndSendCSV(self.__technology.value, fileName, kpiInf['data'], columns)                
                elif self.__sendType == SendType.local:
                    self.__cmfitelService.createLocalCSV(self.__technology.value, self.__uuid, fileName, kpiInf['data'], columns)            
                status = 'REALIZADO'    
            
            #En caso de que sea una recarga verificar que esta vez si tenga data para eliminarla de la tabla recargas
            if self.__isRecharge and status == 'REALIZADO':
                self.__cmfitelRepository.deleteEmptyFile(self.__subproject.value, self.__currentDate, self.__technology.value, self.__dataType.value, self.__sendType.value, self.__uuid)
        
        except Exception:            
            status = 'FALLIDO'
            CMFitelUtils.insertCMFitelLogError(self.loggerDev, sys.exc_info())                                    
        finally:            
            endRunTime = DateUtils.now() #log de finalizacion del proceso
            
            #status
            self.__status = status
            
            if status == 'FALLIDO':
                appStatus = "ERROR"
                message = "Comando:%s, Inicio:%s Fin:%s" % ((self.__sendType.value).lower() + " " + str(self.__startDate) , startRunTime.strftime('%d/%m/%Y %H:%M:%S'), endRunTime.strftime('%d/%m/%Y %H:%M:%S'))
            else:
                appStatus = "INFO"             
                if self.__isRecharge:
                    message = "[%s]File:%s, Inicio:%s Fin:%s" % ('RECARGA', fileName, startRunTime.strftime('%d/%m/%Y %H:%M:%S'), endRunTime.strftime('%d/%m/%Y %H:%M:%S'))
                else:
                    message = "File:%s, Inicio:%s Fin:%s" % (fileName, startRunTime.strftime('%d/%m/%Y %H:%M:%S'), endRunTime.strftime('%d/%m/%Y %H:%M:%S'))
                    
            CMFitelUtils.insertCMFitelLogInfo(self.logger, self.loggerDev, self.__subproject.value, appStatus, status, message)            