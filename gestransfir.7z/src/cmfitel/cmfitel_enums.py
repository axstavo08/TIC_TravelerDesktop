'''
Created on 16/7/2015

@author: C16915
'''

from enum import Enum

class Granularity(Enum):    
    
    hour          = 'HORA'
    day           = 'DIA'
    
    @classmethod        
    def granularitiesValue(cls):        
        return [(gran[1]).value for gran in cls.__members__.items()]
    
    @classmethod          
    def getEnum(cls, granName):
        return ([gran[1] for gran in cls.__members__.items() if (gran[1]).value == granName])[0]

class SendType(Enum):
    remote  =   'REMOTO'
    local   =   'LOCAL'   
    
    @classmethod        
    def sendTypeValues(cls):        
        return [(st[1]).value for st in cls.__members__.items()]
    
    @classmethod          
    def getEnum(cls, stName):
        return ([st[1] for st in cls.__members__.items() if (st[1]).value == stName])[0]

class ProcessType(Enum):
    load            = 'CARGA'
    reload          = 'RECARGA'
    
    @classmethod        
    def processTypeValues(cls):        
        return [(st[1]).value for st in cls.__members__.items()]
    
    @classmethod          
    def getEnum(cls, ptName):
        return ([pt[1] for pt in cls.__members__.items() if (pt[1]).value == ptName])[0]

class SubProject(Enum):
    cn  = 'CN'
    cs  = 'CS'
    sg  = 'SG'
    
    @classmethod          
    def getEnum(cls, spName):
        return ([sp[1] for sp in cls.__members__.items() if (sp[1]).value == spName])[0]

class Technology(Enum):
    t2ghw           = '2G_HW'
    t3ghw           = '3G_HW'    
    
    @classmethod          
    def getEnum(cls, spName):
        return ([sp[1] for sp in cls.__members__.items() if (sp[1]).value == spName])[0]
    
class DataType(Enum):
    alarm   = 'CER'
    kpi     = 'KPI'
    
    @classmethod        
    def dataTypeEnum(cls):        
        return [x[0] for x in cls.__members__.items()]
        
    @classmethod          
    def getEnum(cls, spName):
        return ([sp[1] for sp in cls.__members__.items() if (sp[1]).value == spName])[0]
    
    @classmethod  
    def getEnumByKey(cls, keyName):
        return ([sp[1] for sp in cls.__members__.items() if (sp[0]) == keyName])[0]
    