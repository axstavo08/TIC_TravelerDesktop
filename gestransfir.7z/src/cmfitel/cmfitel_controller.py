# encoding: utf-8
'''
Created on 7/5/2015

@author: C16915 - John Portella
'''

import sys
from datetime import timedelta, datetime 
from common import messages, Logger, ProjectUtils, DateUtils
from cmfitel_business import CMFitelBusiness
from cmfitel_enums import SendType, ProcessType, DataType
from cmfitel_utils import CMFitelUtils

class CMFitelController(object):
    
    def __init__(self, params = []):
        #logger                
        self.logger     = (Logger("cmfitel", self.__class__.__name__)).getLogger()
        self.loggerDev  = (Logger("cmfitel", self.__class__.__name__, True)).getLogger()      
        
        #parametros        
        startDate = params.startdate
        endDate = params.enddate
        sendType = (params.sendtype).upper()  if params.sendtype <> None else params.sendtype
        processType = (params.process).upper()  if params.process <> None else params.process
        localId = (params.uuid).upper()  if params.uuid <> None else params.uuid
        dataType = params.only 
                                                        
        #validar fechas                
        if startDate <> None:
            if not DateUtils.isValidDate(startDate, "%Y%m%d"):
                CMFitelUtils.insertCMFitelLogWarning(self.logger, self.loggerDev, "FINALIZADO", "Formato de fecha erróneo: " + startDate )
                ProjectUtils.printTerminalMessage("FINALIZADO", messages.NO_ACTION)                                               
                sys.exit()
            else:
                self.__startDate = DateUtils.getDateUntilDaySinceNumber(startDate)
        else:
            self.__startDate = (datetime.today() - timedelta(days=1))
            self.__startDate = self.__startDate.replace(hour=0,minute=0,second=0, microsecond=0)
        
        if endDate <> None:
            if not DateUtils.isValidDate(startDate, "%Y%m%d"):
                CMFitelUtils.insertCMFitelLogWarning(self.logger, self.loggerDev, "FINALIZADO", "Formato de fecha erróneo: " + endDate )
                ProjectUtils.printTerminalMessage("FINALIZADO", messages.NO_ACTION)                                               
                sys.exit()
            else:
                self.__endDate = DateUtils.getDateUntilDaySinceNumber(endDate) + timedelta(days=1)
        else:
            self.__endDate = self.__startDate + timedelta(days=1)
        
        #validar tipo de envio
        if sendType is None:            
            self.__sendType = SendType.remote
        else:
            if sendType not in SendType.sendTypeValues():
                CMFitelUtils.insertCMFitelLogWarning(self.logger, self.loggerDev, "FINALIZADO", "Tipo de envio no válido: " + sendType)
                ProjectUtils.printTerminalMessage("FINALIZADO", messages.NO_ACTION)                                               
                sys.exit()        
            else:                
                self.__sendType = SendType.getEnum(sendType)        
        #localID
        self.__localId = localId
        #validar tipo de carga
        if processType is None:
            self.__processType = ProcessType.load            
        else:
            if processType not in ProcessType.processTypeValues():
                CMFitelUtils.insertCMFitelLogWarning(self.logger, self.loggerDev, "FINALIZADO", "Tipo de proceso no válido: " + processType)
                ProjectUtils.printTerminalMessage("FINALIZADO", messages.NO_ACTION)                                               
                sys.exit()        
            else:                
                self.__processType = ProcessType.getEnum(processType)
        #validar dataType
        if dataType is not None:            
            if dataType not in DataType.dataTypeEnum():
                CMFitelUtils.insertCMFitelLogWarning(self.logger, self.loggerDev, "FINALIZADO", "Tipo de data no válido: " + dataType)
                ProjectUtils.printTerminalMessage("FINALIZADO", messages.NO_ACTION)                                               
                sys.exit()        
            else:                                
                self.__dataType = DataType.getEnumByKey(dataType)                            
        
        #Capa de negocio        
        self.__cmfitelBusiness = CMFitelBusiness(self.__processType, self.__sendType, self.__startDate, self.__endDate, self.__localId, self.__dataType)
        self.__cmfitelBusiness.runProcess()
        
    '''        
    def process(self):
        if self.__granularity == Granularity.hour:
            #self.__cmfitelBusiness.processHour()
            pass
        elif self.__granularity == Granularity.day:            
            self.__cmfitelBusiness.processDay()     
                
    def recharge(self):        
        if self.__granularity == Granularity.hour:
            self.__cmfitelBusiness.rechargeHour()
        elif self.__granularity == Granularity.day:
            self.__cmfitelBusiness.rechargeDay()
    '''        