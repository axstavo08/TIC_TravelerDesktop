'''
Created on 7/5/2015

@author: C16915 - John Portella
'''
import uuid
from common import DateUtils
from cmfitel_repository import CMFitelRepository
from cmfitel_process import CMFitelProcess
from cmfitel_enums import ProcessType, SubProject, Technology, DataType, SendType


class CMFitelBusiness(object):
    
    """CMFitelBusiness"""
    
    def __init__(self, processType, sendType, startDate, endDate, localId, dataType):                    
                
        self.__processType = processType
        self.__sendType = sendType
        self.__startDate = startDate
        self.__endDate = endDate
        self.__localId = localId
        self.__dataType = dataType
                                
        #inicializacion del repository        
        self.__cmfitelRepository = CMFitelRepository()
        
        #cantidades
        self.__errorReports = 0
        self.__emptyReports = 0
        
    def runProcess(self):
        #tipo de proceso
        if self.__processType == ProcessType.load:
            self.__LoadProcess()
        elif self.__processType == ProcessType.reload:
            self.__ReloadProcess()                
                
                    
    def __LoadProcess(self):
        """
        Proceso que carga todas las horas del rango de fecha. Se genera un reporte de KPI's por 
        hora y proyecto. Se genera un reporte de alarmas por dia y proyecto.
        """
        
        #Generar el ID local
        if self.__sendType == SendType.local:
            localID = (str(uuid.uuid1())).upper()            
        else:
            localID = None
        
        #KPIS
        totalKPIReports = 0
        totalAlarmReports = 0
            
        if self.__dataType == DataType.kpi:
            '''
            #KPIS
            for currentDate in DateUtils.datetime_range(self.__startDate, self.__endDate, {'hours':1}):
                #CENTRO NORTE 2G HUAWEI KPI        
                procCN2gHW = CMFitelProcess(currentDate, self.__sendType, SubProject.cn, Technology.t2ghw, DataType.kpi, localID)
                procCN2gHW.run()
                self.__SumStatus(procCN2gHW.getStatus())
                #CENTRO SUR 2G HUAWEI KPI
                procCS2gHW = CMFitelProcess(currentDate, self.__sendType, SubProject.cs, Technology.t2ghw, DataType.kpi, localID)
                procCS2gHW.run()
                self.__SumStatus(procCS2gHW.getStatus())   
                #SAN GABAN 2G HUAWEI KPI
                procSG2gHW = CMFitelProcess(currentDate, self.__sendType, SubProject.sg, Technology.t2ghw, DataType.kpi, localID)
                procSG2gHW.run()     
                self.__SumStatus(procSG2gHW.getStatus())
                #SUM TOTAL REPORTS
                totalKPIReports += 3
            
            errorKPIReports = self.__errorReports
            emptyKPIReports = self.__emptyReports   
            #MENSAJE FINAL
            if self.__sendType == SendType.local: 
                print "\nID_LOCAL: {}".format(localID)
            print "Cantidad de reportes KPIS:\t{} totales - {} faltantes - {} errores".format(totalKPIReports, emptyKPIReports, errorKPIReports)            
            '''
            #CENTRO NORTE 2G HUAWEI KPI        
            '''
            procCN2gHW = CMFitelProcess(self.__startDate, self.__sendType, SubProject.cn, Technology.t2ghw, DataType.kpi, localID, None, self.__endDate)
            procCN2gHW.run()
            self.__SumStatus(procCN2gHW.getStatus())
            '''            
            #CENTRO SUR 2G HUAWEI KPI
            '''
            procCS2gHW = CMFitelProcess(self.__startDate, self.__sendType, SubProject.cs, Technology.t2ghw, DataType.kpi, localID, None, self.__endDate)
            procCS2gHW.run()
            self.__SumStatus(procCS2gHW.getStatus())
            '''
            #SAN GABAN 2G HUAWEI KPI
            procSG2gHW = CMFitelProcess(self.__startDate, self.__sendType, SubProject.sg, Technology.t2ghw, DataType.kpi, localID, None, self.__endDate)
            procSG2gHW.run()     
            self.__SumStatus(procSG2gHW.getStatus())
            #SUM TOTAL REPORTS
            totalKPIReports += 1
            
            errorKPIReports = self.__errorReports
            emptyKPIReports = self.__emptyReports 
            #MENSAJE FINAL
            if self.__sendType == SendType.local: 
                print "\nID_LOCAL: {}".format(localID)
            print "Cantidad de reportes KPIS:\t{} totales - {} faltantes - {} errores".format(totalKPIReports, emptyKPIReports, errorKPIReports)
        elif self.__dataType == DataType.alarm:            
            #ALARMAS            
            #CENTRO NORTE ALARMA HISTORICA
            '''
            procCN2GHW = CMFitelProcess(self.__startDate, self.__sendType, SubProject.cn, Technology.t2ghw, DataType.alarm, localID, None, self.__endDate)
            procCN2GHW.run()
            self.__SumStatus(procCN2GHW.getStatus())
            '''
            #CENTRO SUR ALARMA HISTORICA
            '''
            procCS2GHW = CMFitelProcess(self.__startDate, self.__sendType, SubProject.cs, Technology.t2ghw, DataType.alarm, localID, None,self.__endDate)
            procCS2GHW.run()
            self.__SumStatus(procCS2GHW.getStatus())
            '''    
            #SAN GABAN ALARMA HISTORICA
            procSG2GHW = CMFitelProcess(self.__startDate, self.__sendType, SubProject.sg, Technology.t2ghw, DataType.alarm, localID, None,self.__endDate)
            procSG2GHW.run()
            self.__SumStatus(procSG2GHW.getStatus())
            #SUM TOTAL REPORTS
            totalAlarmReports += 1
            
            errorAlarmReports = self.__errorReports
            emptyAlarmReports = self.__emptyReports
            #MENSAJE FINAL
            if self.__sendType == SendType.local: 
                print "\nID_LOCAL: {}".format(localID)
            print "Cantidad de reportes Alarmas:\t{} totales - {} faltantes - {} errores".format(totalAlarmReports, emptyAlarmReports, errorAlarmReports)
        else:                        
            #KPIS
            for currentDate in DateUtils.datetime_range(self.__startDate, self.__endDate, {'hours':1}):
                #CENTRO NORTE 2G HUAWEI KPI        
                '''
                procCN2gHW = CMFitelProcess(currentDate, self.__sendType, SubProject.cn, Technology.t2ghw, DataType.kpi, localID)
                procCN2gHW.run()
                self.__SumStatus(procCN2gHW.getStatus())
                '''
                #CENTRO SUR 2G HUAWEI KPI
                '''
                procCS2gHW = CMFitelProcess(currentDate, self.__sendType, SubProject.cs, Technology.t2ghw, DataType.kpi, localID)
                procCS2gHW.run()
                self.__SumStatus(procCS2gHW.getStatus())
                '''   
                #SAN GABAN 2G HUAWEI KPI
                procSG2gHW = CMFitelProcess(currentDate, self.__sendType, SubProject.sg, Technology.t2ghw, DataType.kpi, localID)
                procSG2gHW.run()     
                self.__SumStatus(procSG2gHW.getStatus())
                #SUM TOTAL REPORTS
                totalKPIReports += 1
            
            errorKPIReports = self.__errorReports
            emptyKPIReports = self.__emptyReports
            
            self.__errorReports = 0
            self.__emptyReports = 0
            
            #ALARMAS
            for currentDate in DateUtils.datetime_range(self.__startDate, self.__endDate, {'days':1}):
                #CENTRO NORTE ALARMA HISTORICA
                '''
                procCN2GHW = CMFitelProcess(currentDate, self.__sendType, SubProject.cn, Technology.t2ghw, DataType.alarm, localID)
                procCN2GHW.run()
                self.__SumStatus(procCN2GHW.getStatus())
                '''
                #CENTRO SUR ALARMA HISTORICA
                '''
                procCS2GHW = CMFitelProcess(currentDate, self.__sendType, SubProject.cs, Technology.t2ghw, DataType.alarm, localID)
                procCS2GHW.run()
                self.__SumStatus(procCS2GHW.getStatus())
                '''    
                #SAN GABAN ALARMA HISTORICA
                procSG2GHW = CMFitelProcess(currentDate, self.__sendType, SubProject.sg, Technology.t2ghw, DataType.alarm, localID)
                procSG2GHW.run()
                self.__SumStatus(procSG2GHW.getStatus())
                #SUM TOTAL REPORTS
                totalAlarmReports += 1
            
            errorAlarmReports = self.__errorReports
            emptyAlarmReports = self.__emptyReports
            
            #MENSAJE FINAL
            if self.__sendType == SendType.local: 
                print "\nID_LOCAL: {}".format(localID)
            print "Cantidad de reportes KPIS:\t{} totales - {} faltantes - {} errores".format(totalKPIReports, emptyKPIReports, errorKPIReports)
            print "Cantidad de reportes Alarmas:\t{} totales - {} faltantes - {} errores".format(totalAlarmReports, emptyAlarmReports, errorAlarmReports)
                
           
    def __ReloadProcess(self):
        """
        Proceso que carga las horas faltantes
        """
        emptyDates = self.__cmfitelRepository.getEmptyFiles(self.__sendType.value,self.__localId)        
        for emptyDate in emptyDates:
            #values
            subproject = SubProject.getEnum(emptyDate['PROYECTO'])
            technology = Technology.getEnum(emptyDate['TECNOLOGIA'])
            sendType = SendType.getEnum(emptyDate['TIPO_ENVIO'])
            dataType = DataType.getEnum(emptyDate['TIPO'])
            localid = emptyDate['ID_LOCAL']
            currentDateInt = emptyDate['FECHA_INICIO']
            if dataType == DataType.kpi:
                currentDate = DateUtils.getDatewithHourSinceNumber(currentDateInt)
            elif dataType == DataType.alarm:
                currentDate = DateUtils.getDatewithDaySinceNumber(currentDateInt)
            
            #CARGA DE INFORMACION
            proc = CMFitelProcess(currentDate, sendType, subproject, technology, dataType, localid, True)
            proc.run()
            self.__SumStatus(proc.getStatus())
        
        errorReports = self.__errorReports
        emptyReports = self.__emptyReports
        #MENSAJE FINAL
        print "\nCantidad de reportes:\t{} totales - {} faltantes - {} errores".format(len(emptyDate), emptyReports, errorReports)
           
    def __SumStatus(self, status):
        if status == "VACIO":
            self.__emptyReports += 1
        elif status == "FALLIDO":
            self.__errorReports += 1    